﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace FlightLib
{
    public class BaseDatosCompañia
    {
        SQLiteConnection cnx;

        public BaseDatosCompañia()
        {
            string DataSource = "Data Source=compañias.db";
            cnx = new SQLiteConnection(DataSource);
        }

        public void CrearBaseDatos()
        {
            if (!System.IO.File.Exists("compañias.db"))
            {
                SQLiteConnection.CreateFile("compañias.db");
            }
        }

        public void CrearTabla()
        {
            string sql = "CREATE TABLE IF NOT EXISTS compañias (nombre varchar(100), telefono varchar(100), correo varchar(100), logo longblob)";
            SQLiteCommand command = new SQLiteCommand(sql, cnx);
            command.ExecuteNonQuery();
        }

        public void IniciarBaseDatos()
        {
            string DataSource = "Data Source=compañias.db";
            cnx = new SQLiteConnection(DataSource);
            cnx.Open();
        }

        public void CerrarBaseDatos()
        {
            cnx.Close();
        }

        public byte[] ImagenToBytes(Image img)
        {
            if (img == null) return null;

            using (MemoryStream ms = new MemoryStream())
            {
                img.Save(ms, img.RawFormat);
                return ms.ToArray();
            }
        }

        public int RegistrarCompañias(string nombre, string telefono, string correo, byte[] logo)
        {
            string registro = "INSERT INTO compañias (nombre, telefono, correo, logo) " +
                              "VALUES (@nombre, @telefono, @correo, @logo)";

            SQLiteCommand command = new SQLiteCommand(registro, cnx);
            
            command.Parameters.AddWithValue("@nombre", nombre);
            command.Parameters.AddWithValue("@telefono", telefono);
            command.Parameters.AddWithValue("@correo", correo);
            command.Parameters.Add("@logo", DbType.Binary).Value = logo;

            int hecho = command.ExecuteNonQuery();

            if (hecho == 1)
            {
                return 1;
            }
            else
            {
                return 0;
            }
            
        }

        public int EliminarCompañía(string nombre)
        {
            string sql = "DELETE FROM compañias WHERE nombre='" + nombre + "'";
            SQLiteCommand cmd = new SQLiteCommand(sql, cnx);
            int resultado = cmd.ExecuteNonQuery();
            if (resultado == 1)
            {
                return 1;
            }
            else
            {
                return 0;
            }

            
        }



        public void InicializarBD()
        {
            IniciarBaseDatos();
            CrearBaseDatos();
            CrearTabla();
        }

        public void FinalizarBD()
        {
            CerrarBaseDatos();
        }
    }
}
