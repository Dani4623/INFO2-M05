﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightLib
{
    public class Compañias
    {
        string nombre;
        string telefono;
        string email;
        byte[] logo;

        public Compañias(string nombre, int telefono, string email, byte[] logo)
        {
            this.nombre = nombre;
            this.telefono = Convert.ToString(telefono);
            this.email = email;
            this.logo = logo;
        }

        public void SetNombre(string nombre)
        {
            this.nombre = nombre;
        }
        public void SetTelefono(int telefono)
        {
            this.telefono = Convert.ToString(telefono);
        }
        public void SetEmail(string email)
        {
            this.email = email;
        }
        public void SetLogo(byte[] logo)
        {
            this.logo = logo;
        }
        public string GetNombre()
        {
            return this.nombre;
        }
        public string GetTelefono()
        {
            return this.telefono;
        }
        public string GetEmail()
        {
            return this.email;
        }
        public byte[] GetLogo()
        {
            return this.logo;
        }
    }
}
