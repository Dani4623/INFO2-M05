﻿using FlightLib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterfazGrafica
{
    public partial class DistanciasCompletas : Form
    {
        private FlightPlanList miLista;
        public DistanciasCompletas(FlightPlanList lista)
        {
            InitializeComponent();
            this.miLista = lista;
        }
        private void MostrarDistancias()
        {
            dataGridView1.Rows.Clear();
            dataGridView1.ColumnCount = miLista.GetNum() + 1;


            dataGridView1.Columns[0].Name = "Vuelo";

            for (int i = 0; i < miLista.GetNum(); i++)
            {
                dataGridView1.Columns[i + 1].Name = miLista.GetFlightPlan(i).GetId();
            }


            for (int i = 0; i < miLista.GetNum(); i++)
            {
                string[] fila = new string[miLista.GetNum() + 1];
                FlightPlan vuelo1 = miLista.GetFlightPlan(i);

                fila[0] = vuelo1.GetId();

                for (int j = 0; j < miLista.GetNum(); j++)
                {
                    if (i == j)
                    {
                        fila[j + 1] = "0";
                    }
                    else
                    {
                        FlightPlan vuelo2 = miLista.GetFlightPlan(j);
                        double distancia = vuelo1.Distancia(
                            vuelo2.GetCurrentPosition().GetX(),
                            vuelo2.GetCurrentPosition().GetY()
                        );
                        fila[j + 1] = $"{distancia:F2}";
                    }
                }

                dataGridView1.Rows.Add(fila);
            }
        }

        private void DistanciasCompletas_Load(object sender, EventArgs e)
        {
            MostrarDistancias();
        }
    }


}
