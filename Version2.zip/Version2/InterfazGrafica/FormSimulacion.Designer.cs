﻿namespace InterfazGrafica
{
    partial class FormSimulacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            miPanel = new Panel();
            btnMoverCiclo = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            Inicio = new Button();
            Final = new Button();
            MostrarDatosActuales = new Button();
            btnCambiarVelocidadesDeLosVuelos = new Button();
            btnReiniciar = new Button();
            deshacerBtn = new Button();
            btnVerificarConflicto = new Button();
            mostrarDistanciasTxt = new Button();
            mostrarVuelosBtn = new Button();
            exportarListaBtn = new Button();
            SuspendLayout();
            // 
            // miPanel
            // 
            miPanel.BackColor = SystemColors.GradientInactiveCaption;
            miPanel.Location = new Point(10, 11);
            miPanel.Margin = new Padding(2);
            miPanel.Name = "miPanel";
            miPanel.Size = new Size(1165, 758);
            miPanel.TabIndex = 0;
            // 
            // btnMoverCiclo
            // 
            btnMoverCiclo.Location = new Point(1274, 10);
            btnMoverCiclo.Margin = new Padding(2);
            btnMoverCiclo.Name = "btnMoverCiclo";
            btnMoverCiclo.Size = new Size(108, 30);
            btnMoverCiclo.TabIndex = 1;
            btnMoverCiclo.Text = "Mover Ciclo";
            btnMoverCiclo.UseVisualStyleBackColor = true;
            btnMoverCiclo.Click += btnMoverCiclo_Click;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // Inicio
            // 
            Inicio.Location = new Point(1274, 45);
            Inicio.Name = "Inicio";
            Inicio.Size = new Size(108, 70);
            Inicio.TabIndex = 2;
            Inicio.Text = "Empezar simulación automática";
            Inicio.UseVisualStyleBackColor = true;
            Inicio.Click += Inicio_Click;
            // 
            // Final
            // 
            Final.Location = new Point(1274, 123);
            Final.Name = "Final";
            Final.Size = new Size(108, 70);
            Final.TabIndex = 3;
            Final.Text = "Finalizar simulación automática";
            Final.UseVisualStyleBackColor = true;
            Final.Click += Final_Click;
            // 
            // MostrarDatosActuales
            // 
            MostrarDatosActuales.Location = new Point(1274, 200);
            MostrarDatosActuales.Name = "MostrarDatosActuales";
            MostrarDatosActuales.Size = new Size(108, 68);
            MostrarDatosActuales.TabIndex = 4;
            MostrarDatosActuales.Text = "Mostrar datos actuales";
            MostrarDatosActuales.UseVisualStyleBackColor = true;
            MostrarDatosActuales.Click += MostrarDatosActuales_Click;
            // 
            // btnCambiarVelocidadesDeLosVuelos
            // 
            btnCambiarVelocidadesDeLosVuelos.Location = new Point(1274, 350);
            btnCambiarVelocidadesDeLosVuelos.Margin = new Padding(2);
            btnCambiarVelocidadesDeLosVuelos.Name = "btnCambiarVelocidadesDeLosVuelos";
            btnCambiarVelocidadesDeLosVuelos.Size = new Size(108, 86);
            btnCambiarVelocidadesDeLosVuelos.TabIndex = 6;
            btnCambiarVelocidadesDeLosVuelos.Text = "Cambiar velocidades de los vuelos";
            btnCambiarVelocidadesDeLosVuelos.UseVisualStyleBackColor = true;
            btnCambiarVelocidadesDeLosVuelos.Click += btnCambiarVelocidadesDeLosVuelos_Click;
            // 
            // btnReiniciar
            // 
            btnReiniciar.Location = new Point(1274, 448);
            btnReiniciar.Margin = new Padding(2);
            btnReiniciar.Name = "btnReiniciar";
            btnReiniciar.Size = new Size(108, 27);
            btnReiniciar.TabIndex = 7;
            btnReiniciar.Text = "Reiniciar";
            btnReiniciar.UseVisualStyleBackColor = true;
            btnReiniciar.Click += btnReiniciar_Click;
            // 
            // deshacerBtn
            // 
            deshacerBtn.Location = new Point(1274, 488);
            deshacerBtn.Margin = new Padding(2);
            deshacerBtn.Name = "deshacerBtn";
            deshacerBtn.Size = new Size(108, 27);
            deshacerBtn.TabIndex = 8;
            deshacerBtn.Text = "Deshacer";
            deshacerBtn.UseVisualStyleBackColor = true;
            deshacerBtn.Click += deshacerBtn_Click;
            // 
            // btnVerificarConflicto
            // 
            btnVerificarConflicto.Location = new Point(1274, 274);
            btnVerificarConflicto.Name = "btnVerificarConflicto";
            btnVerificarConflicto.Size = new Size(108, 62);
            btnVerificarConflicto.TabIndex = 5;
            btnVerificarConflicto.Text = "Verificar Conflicto";
            btnVerificarConflicto.UseVisualStyleBackColor = true;
            // 
            // mostrarDistanciasTxt
            // 
            mostrarDistanciasTxt.Location = new Point(1274, 520);
            mostrarDistanciasTxt.Name = "mostrarDistanciasTxt";
            mostrarDistanciasTxt.Size = new Size(108, 62);
            mostrarDistanciasTxt.TabIndex = 9;
            mostrarDistanciasTxt.Text = "Mostrar Distancias";
            mostrarDistanciasTxt.UseVisualStyleBackColor = true;
            mostrarDistanciasTxt.Click += mostrarDistanciasTxt_Click;
            // 
            // mostrarVuelosBtn
            // 
            mostrarVuelosBtn.Location = new Point(1274, 588);
            mostrarVuelosBtn.Name = "mostrarVuelosBtn";
            mostrarVuelosBtn.Size = new Size(108, 62);
            mostrarVuelosBtn.TabIndex = 11;
            mostrarVuelosBtn.Text = "Mostrar Vuelos";
            mostrarVuelosBtn.UseVisualStyleBackColor = true;
            mostrarVuelosBtn.Click += mostrarVuelosBtn_Click;
            // 
            // exportarListaBtn
            // 
            exportarListaBtn.Location = new Point(1274, 656);
            exportarListaBtn.Name = "exportarListaBtn";
            exportarListaBtn.Size = new Size(108, 62);
            exportarListaBtn.TabIndex = 12;
            exportarListaBtn.Text = "Exportar lista vuelos";
            exportarListaBtn.UseVisualStyleBackColor = true;
            exportarListaBtn.Click += exportarListaBtn_Click;
            // 
            // FormSimulacion
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1408, 780);
            Controls.Add(exportarListaBtn);
            Controls.Add(mostrarVuelosBtn);
            Controls.Add(mostrarDistanciasTxt);
            Controls.Add(deshacerBtn);
            Controls.Add(btnReiniciar);
            Controls.Add(btnCambiarVelocidadesDeLosVuelos);
            Controls.Add(btnVerificarConflicto);
            Controls.Add(MostrarDatosActuales);
            Controls.Add(Final);
            Controls.Add(Inicio);
            Controls.Add(btnMoverCiclo);
            Controls.Add(miPanel);
            Margin = new Padding(2);
            Name = "FormSimulacion";
            Text = "Mostrar Vuelos";
            Load += FormSimulacion_Load;
            ResumeLayout(false);
        }

        #endregion

        private Panel miPanel;
        private Button btnMoverCiclo;
        private System.Windows.Forms.Timer timer1;
        private Button Inicio;
        private Button Final;
        private Button MostrarDatosActuales;
        private Button btnCambiarVelocidadesDeLosVuelos;
        private Button btnReiniciar;
        private Button deshacerBtn;
        private Button btnVerificarConflicto;
        private Button mostrarDistanciasTxt;
        private Button mostrarVuelosBtn;
        private Button exportarListaBtn;
    }
}