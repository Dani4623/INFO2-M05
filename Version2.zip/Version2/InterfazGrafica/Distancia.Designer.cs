﻿namespace InterfazGrafica
{
    partial class Distancia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            Vuelo1 = new TextBox();
            label2 = new Label();
            Vuelo2 = new TextBox();
            label3 = new Label();
            textBox3 = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(27, 192);
            label1.Name = "label1";
            label1.Size = new Size(167, 31);
            label1.TabIndex = 0;
            label1.Text = "Distancia entre";
            // 
            // Vuelo1
            // 
            Vuelo1.Location = new Point(218, 196);
            Vuelo1.Name = "Vuelo1";
            Vuelo1.Size = new Size(125, 27);
            Vuelo1.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(349, 192);
            label2.Name = "label2";
            label2.Size = new Size(25, 31);
            label2.TabIndex = 2;
            label2.Text = "y";
            // 
            // Vuelo2
            // 
            Vuelo2.Location = new Point(380, 196);
            Vuelo2.Name = "Vuelo2";
            Vuelo2.Size = new Size(125, 27);
            Vuelo2.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(511, 192);
            label3.Name = "label3";
            label3.Size = new Size(36, 31);
            label3.TabIndex = 4;
            label3.Text = "es";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(553, 196);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(125, 27);
            textBox3.TabIndex = 5;
            // 
            // Distancia
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(textBox3);
            Controls.Add(label3);
            Controls.Add(Vuelo2);
            Controls.Add(label2);
            Controls.Add(Vuelo1);
            Controls.Add(label1);
            Name = "Distancia";
            Text = "Distancia";
            Load += Distancia_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox Vuelo1;
        private Label label2;
        private TextBox Vuelo2;
        private Label label3;
        private TextBox textBox3;
    }
}