﻿using FlightLib;
using System;
using System.Windows.Forms;

namespace InterfazGrafica
{
    public partial class Principal : Form
    {
        private FlightPlanList listavuelos;
        private double distanciaSeguridad;
        private int tiempoCiclo;
        public Principal()
        {
            InitializeComponent();
        }

        private void cargarListaDeVuelosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DatosVuelos formDatos = new DatosVuelos();
            if (formDatos.ShowDialog() == DialogResult.OK)
            {
                this.listavuelos = formDatos.listaPlanesVuelo;

                MessageBox.Show("Vuelos cargados correctamente");
            }
        }

        private void distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Configuracion formConfig = new Configuracion();
            if (formConfig.ShowDialog() == DialogResult.OK)
            {
                // Usar los nuevos nombres de propiedades
                distanciaSeguridad = formConfig.DistanciaSeguridadValor;
                tiempoCiclo = (int)formConfig.TiempoCicloValor;
                MessageBox.Show("Configuración guardada");
            }
        }

        private void simulaciónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listavuelos == null || listavuelos.GetNum() == 0)
            {
                MessageBox.Show("Primero carga los datos de vuelos");
                return;
            }

            double tiempoMaximo = 120;

            for (int i = 0; i < listavuelos.GetNum(); i++)
            {
                for (int j = i + 1; j < listavuelos.GetNum(); j++)
                {
                    FlightPlan vueloA = listavuelos.GetFlightPlan(i);
                    FlightPlan vueloB = listavuelos.GetFlightPlan(j);

                    double distanciaActual = vueloA.Distancia(vueloB.GetCurrentPosition().GetX(), vueloB.GetCurrentPosition().GetY());
                    bool conflictoInmediato = distanciaActual < (2 * distanciaSeguridad);
                    bool conflictoFuturo = vueloA.EntraraEnConflicto(vueloB, distanciaSeguridad, tiempoMaximo);
                    double tiempoConflicto = vueloA.TiempoHastaConflicto(vueloB, distanciaSeguridad, tiempoMaximo);

                    if (conflictoInmediato)
                    {
                        DialogResult resultado = MessageBox.Show(
                            $"CONFLICTO INMEDIATO\n\n" +
                            $"Los aviones {vueloA.GetId()} y {vueloB.GetId()} ya están en conflicto.\n" +
                            $"Distancia actual: {distanciaActual:F1}\n" +
                            $"Umbral seguridad: {2 * distanciaSeguridad:F1}\n\n" +
                            $"¿Resolver automáticamente?",
                            "Conflicto Detectado",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Error
                        );

                        if (resultado == DialogResult.Yes)
                        {
                            ResolverConflictoInstantaneo(vueloA, vueloB, distanciaSeguridad, tiempoMaximo);
                        }
                    }
                    else if (conflictoFuturo && tiempoConflicto != 0)
                    {
                        DialogResult resultado = MessageBox.Show(
                            $"CONFLICTO FUTURO\n\n" +
                            $"Los aviones {vueloA.GetId()} y {vueloB.GetId()} entrarán en conflicto en {tiempoConflicto:F1} minutos.\n" +
                            $"Distancia seguridad: {distanciaSeguridad:F1}\n\n" +
                            $"¿Resolver automáticamente?",
                            "Conflicto Futuro Detectado",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Warning
                        );

                        if (resultado == DialogResult.Yes)
                        {
                            ResolverConflictoInstantaneo(vueloA, vueloB, distanciaSeguridad, tiempoMaximo);
                        }
                    }
                    // NUNCA mostrar mensaje "sin conflicto" aquí
                }
            }

            FormSimulacion formSimulacion = new FormSimulacion(tiempoCiclo, distanciaSeguridad);
            formSimulacion.SetPlanes(listavuelos);
            for (int i = 0; i < listavuelos.GetNum(); i++)
                formSimulacion.SetVelocidad(listavuelos.GetFlightPlan(i), listavuelos.GetFlightPlan(i).GetVelocidad());
            formSimulacion.Show();
        }


        private void Principal_Load(object sender, EventArgs e)
        {

        }

        private bool ResolverConflictoAutomatico(FlightPlan vuelo1, FlightPlan vuelo2, double distanciaSeguridad, double tiempoMaximo)
        {
            double velocidadOriginalVuelo1 = vuelo1.GetVelocidad();
            double velocidadOriginalVuelo2 = vuelo2.GetVelocidad();

            Console.WriteLine($"Velocidad original V1: {velocidadOriginalVuelo1}");
            Console.WriteLine($"Velocidad original V2: {velocidadOriginalVuelo2}");

            // Más factores de velocidad para mayor probabilidad de éxito
            double[] factoresVelocidad = { 0.5, 0.6, 0.7, 0.8, 0.9, 1.1, 1.2, 1.3, 1.5, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0 };

            // ESTRATEGIA 1: Vuelo 1 más lento
            foreach (double factor in factoresVelocidad)
            {
                if (factor < 1.0) // Solo hacer más lento
                {
                    vuelo1.SetVelocidad(velocidadOriginalVuelo1 * factor);
                    if (!vuelo1.EntraraEnConflicto(vuelo2, distanciaSeguridad, tiempoMaximo))
                    {
                        return true;
                    }
                }
            }

            // ESTRATEGIA 2: Vuelo 1 más rápido
            foreach (double factor in factoresVelocidad)
            {
                if (factor > 1.0) // Solo hacer más rápido
                {
                    vuelo1.SetVelocidad(velocidadOriginalVuelo1 * factor);
                    if (!vuelo1.EntraraEnConflicto(vuelo2, distanciaSeguridad, tiempoMaximo))
                    {
                        return true;
                    }
                }
            }

            // ESTRATEGIA 3: Vuelo 2 más lento
            vuelo1.SetVelocidad(velocidadOriginalVuelo1);
            foreach (double factor in factoresVelocidad)
            {
                if (factor < 1.0)
                {
                    vuelo2.SetVelocidad(velocidadOriginalVuelo2 * factor);
                    if (!vuelo1.EntraraEnConflicto(vuelo2, distanciaSeguridad, tiempoMaximo))
                    {
                        return true;
                    }
                }
            }

            // ESTRATEGIA 4: Vuelo 2 más rápido
            foreach (double factor in factoresVelocidad)
            {
                if (factor > 1.0)
                {
                    vuelo2.SetVelocidad(velocidadOriginalVuelo2 * factor);
                    if (!vuelo1.EntraraEnConflicto(vuelo2, distanciaSeguridad, tiempoMaximo))
                    {
                        return true;
                    }
                }
            }

            // Restaurar si no se pudo resolver
            vuelo1.SetVelocidad(velocidadOriginalVuelo1);
            vuelo2.SetVelocidad(velocidadOriginalVuelo2);

            Console.WriteLine("No se pudo resolver automáticamente");
            return false;
        }
        private bool ResolverConflictoInstantaneo(FlightPlan vuelo1, FlightPlan vuelo2, double distanciaSeguridad, double tiempoMaximo)
        {
            double v1Original = vuelo1.GetVelocidad();
            double v2Original = vuelo2.GetVelocidad();


            // Estrategias matemáticas instantáneas
            (double, double)[] estrategias = {
        (v1Original * 0.3, v2Original),      // V1 muy lento
        (v1Original * 0.5, v2Original),      // V1 lento
        (v1Original * 0.7, v2Original),      // V1 moderado
        (v1Original * 1.5, v2Original),      // V1 rápido
        (v1Original * 2.0, v2Original),      // V1 muy rápido
        (v1Original, v2Original * 0.3),      // V2 muy lento
        (v1Original, v2Original * 0.5),      // V2 lento
        (v1Original, v2Original * 0.7),      // V2 moderado
        (v1Original, v2Original * 1.5),      // V2 rápido
        (v1Original, v2Original * 2.0),      // V2 muy rápido
        (v1Original * 0.8, v2Original * 1.2), // Combinación 1
        (v1Original * 1.2, v2Original * 0.8), // Combinación 2
        (v1Original * 0.6, v2Original * 0.6), // Ambos lentos
        (v1Original * 1.4, v2Original * 1.4)  // Ambos rápidos
    };

            for (int i = 0; i < estrategias.Length; i++)
            {
                vuelo1.SetVelocidad(estrategias[i].Item1);
                vuelo2.SetVelocidad(estrategias[i].Item2);

                // Verificación MATEMÁTICA instantánea
                if (!vuelo1.EntraraEnConflicto(vuelo2, distanciaSeguridad, tiempoMaximo))
                {
                    MessageBox.Show(
                        $"Nuevas velocidades:\n" +
                        $"Vuelo 1: {estrategias[i].Item1:F1} (original: {v1Original:F1})\n" +
                        $"Vuelo 2: {estrategias[i].Item2:F1} (original: {v2Original:F1})",
                        "Resolución Exitosa",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                    return true;
                }
            }


            // Restaurar si no se pudo resolver
            vuelo1.SetVelocidad(v1Original);
            vuelo2.SetVelocidad(v2Original);

            MessageBox.Show(
                "No se pudo resolver automáticamente\n" +
                "Ajuste manualmente las rutas o velocidades",
                "No Se Pudo Resolver",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning
            );
            return false;
        }
        public FlightPlanList LeerVuelosDesdeFichero(string rutaFichero)
        {
            try
            {


                FlightPlanList lista = new FlightPlanList();

                List<string> lineas = new List<string>();
                StreamReader reader = new StreamReader(rutaFichero);
                string linea;


                while ((linea = reader.ReadLine()) != null)
                {
                    lineas.Add(linea);
                }
                reader.Close();


                for (int i = 0; i < lineas.Count; i++)
                {
                    string[] datos = lineas[i].Split(',');

                    if (datos.Length == 7)
                    {
                        FlightPlan vuelo = new FlightPlan(datos[0], datos[1], Convert.ToDouble(datos[2]), Convert.ToDouble(datos[3]), Convert.ToDouble(datos[4]), Convert.ToDouble(datos[5]), Convert.ToDouble(datos[6]));

                        lista.AddFlightPlan(vuelo);
                    }
                }

                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al leer el fichero: " + ex.Message);
            }
        }

        private void cargarDesdeFicheroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "Archivos de texto (*.txt)|*.txt";
                dialog.Title = "Seleccionar fichero de vuelos";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    listavuelos = LeerVuelosDesdeFichero(dialog.FileName);

                    Distancia2 formDistancia = new Distancia2();
                    if (formDistancia.ShowDialog() == DialogResult.OK)
                    {

                        distanciaSeguridad = formDistancia.Distancia1;
                        tiempoCiclo = formDistancia.Ciclo;

                        MessageBox.Show($"Se cargaron {listavuelos.GetNum()} vuelos\nDistancia seguridad: {distanciaSeguridad}\nTiempo de Ciclo: {tiempoCiclo}");
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en los datos: " + ex.Message);
            }
        }



        private void informaciónDeFicheroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"Información de los datos en el fichero de vuelos:\n\n - Los datos deben estar ordenados en ID, compañia, x inicial, y inicial,        x final, y final, velocidad.\n" +
    $" - Cada linea de la lista tiene que corresponder a un vuelo. \n - Los datos deben estar separados por comas (,)");
        }
    }
}