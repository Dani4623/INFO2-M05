﻿namespace InterfazGrafica
{
    partial class InicioSesion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InicioSesion));
            label1 = new Label();
            usuarioTxt = new TextBox();
            contraseñaTxt = new TextBox();
            label2 = new Label();
            iniciarSesionBtn = new Button();
            emailTxt = new TextBox();
            label3 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.SlateGray;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(275, 392);
            label1.Name = "label1";
            label1.Size = new Size(79, 28);
            label1.TabIndex = 0;
            label1.Text = "Usuario";
            // 
            // usuarioTxt
            // 
            usuarioTxt.BorderStyle = BorderStyle.FixedSingle;
            usuarioTxt.Location = new Point(243, 423);
            usuarioTxt.Name = "usuarioTxt";
            usuarioTxt.Size = new Size(149, 27);
            usuarioTxt.TabIndex = 1;
            // 
            // contraseñaTxt
            // 
            contraseñaTxt.BackColor = SystemColors.Window;
            contraseñaTxt.BorderStyle = BorderStyle.FixedSingle;
            contraseñaTxt.ForeColor = Color.Black;
            contraseñaTxt.Location = new Point(475, 423);
            contraseñaTxt.Name = "contraseñaTxt";
            contraseñaTxt.Size = new Size(149, 27);
            contraseñaTxt.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.SlateGray;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(492, 392);
            label2.Name = "label2";
            label2.Size = new Size(110, 28);
            label2.TabIndex = 2;
            label2.Text = "Contraseña";
            // 
            // iniciarSesionBtn
            // 
            iniciarSesionBtn.BackColor = Color.SlateGray;
            iniciarSesionBtn.BackgroundImageLayout = ImageLayout.Center;
            iniciarSesionBtn.ForeColor = Color.Transparent;
            iniciarSesionBtn.Location = new Point(475, 500);
            iniciarSesionBtn.Name = "iniciarSesionBtn";
            iniciarSesionBtn.Size = new Size(149, 29);
            iniciarSesionBtn.TabIndex = 4;
            iniciarSesionBtn.Text = "Iniciar Sesión";
            iniciarSesionBtn.UseVisualStyleBackColor = false;
            iniciarSesionBtn.Click += iniciarSesionBtn_Click;
            // 
            // emailTxt
            // 
            emailTxt.BackColor = SystemColors.Window;
            emailTxt.BorderStyle = BorderStyle.FixedSingle;
            emailTxt.ForeColor = Color.Black;
            emailTxt.Location = new Point(690, 423);
            emailTxt.Name = "emailTxt";
            emailTxt.Size = new Size(149, 27);
            emailTxt.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.SlateGray;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(732, 392);
            label3.Name = "label3";
            label3.Size = new Size(59, 28);
            label3.TabIndex = 5;
            label3.Text = "Email";
            // 
            // InicioSesion
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1118, 624);
            Controls.Add(emailTxt);
            Controls.Add(label3);
            Controls.Add(iniciarSesionBtn);
            Controls.Add(contraseñaTxt);
            Controls.Add(label2);
            Controls.Add(usuarioTxt);
            Controls.Add(label1);
            ForeColor = Color.White;
            Name = "InicioSesion";
            Text = "InicioSesion";
            Load += InicioSesion_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox usuarioTxt;
        private TextBox contraseñaTxt;
        private Label label2;
        private Button iniciarSesionBtn;
        private TextBox emailTxt;
        private Label label3;
    }
}