﻿
namespace InterfazGrafica
{
    partial class AddCompa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guardar = new Button();
            Cancelar = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtNombre = new TextBox();
            txtTelefono = new TextBox();
            txtEmail = new TextBox();
            comboBoxCompanies = new ComboBox();
            flowLayoutPanelImages = new FlowLayoutPanel();
            pictureBoxSelected = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBoxSelected).BeginInit();
            SuspendLayout();
            // 
            // Guardar
            // 
            Guardar.Location = new Point(112, 201);
            Guardar.Margin = new Padding(2);
            Guardar.Name = "Guardar";
            Guardar.Size = new Size(92, 29);
            Guardar.TabIndex = 0;
            Guardar.Text = "Guardar";
            Guardar.UseVisualStyleBackColor = true;
            Guardar.Click += Guardar_Click;
            // 
            // Cancelar
            // 
            Cancelar.Location = new Point(268, 200);
            Cancelar.Margin = new Padding(2);
            Cancelar.Name = "Cancelar";
            Cancelar.Size = new Size(81, 32);
            Cancelar.TabIndex = 1;
            Cancelar.Text = "Cancelar";
            Cancelar.UseVisualStyleBackColor = true;
            Cancelar.Click += Cancelar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(50, 54);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(64, 20);
            label1.TabIndex = 2;
            label1.Text = "Nombre";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(211, 54);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(67, 20);
            label2.TabIndex = 3;
            label2.Text = "Teléfono";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(384, 54);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(46, 20);
            label3.TabIndex = 4;
            label3.Text = "Email";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(20, 119);
            txtNombre.Margin = new Padding(2);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(125, 27);
            txtNombre.TabIndex = 5;
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(199, 119);
            txtTelefono.Margin = new Padding(2);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(125, 27);
            txtTelefono.TabIndex = 6;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(362, 119);
            txtEmail.Margin = new Padding(2);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(125, 27);
            txtEmail.TabIndex = 7;
            // 
            // comboBoxCompanies
            // 
            comboBoxCompanies.FormattingEnabled = true;
            comboBoxCompanies.Location = new Point(617, 48);
            comboBoxCompanies.Name = "comboBoxCompanies";
            comboBoxCompanies.Size = new Size(215, 28);
            comboBoxCompanies.TabIndex = 8;
            comboBoxCompanies.Text = "Logos de las compañais";
            comboBoxCompanies.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // flowLayoutPanelImages
            // 
            flowLayoutPanelImages.Location = new Point(640, 119);
            flowLayoutPanelImages.Name = "flowLayoutPanelImages";
            flowLayoutPanelImages.Size = new Size(250, 125);
            flowLayoutPanelImages.TabIndex = 9;
            // 
            // pictureBoxSelected
            // 
            pictureBoxSelected.Location = new Point(640, 119);
            pictureBoxSelected.Name = "pictureBoxSelected";
            pictureBoxSelected.Size = new Size(247, 125);
            pictureBoxSelected.TabIndex = 0;
            pictureBoxSelected.TabStop = false;
            // 
            // AddCompa
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1018, 387);
            Controls.Add(pictureBoxSelected);
            Controls.Add(flowLayoutPanelImages);
            Controls.Add(comboBoxCompanies);
            Controls.Add(txtEmail);
            Controls.Add(txtTelefono);
            Controls.Add(txtNombre);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(Cancelar);
            Controls.Add(Guardar);
            Margin = new Padding(2);
            Name = "AddCompa";
            Text = "Añade Compañia";
            Load += AddCompa_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBoxSelected).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }



        #endregion

        private Button Guardar;
        private Button Cancelar;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtNombre;
        private TextBox txtTelefono;
        private TextBox txtEmail;
        private ComboBox comboBoxCompanies;
        private FlowLayoutPanel flowLayoutPanelImages;
        private PictureBox pictureBoxSelected;
    }
}