﻿namespace InterfazGrafica
{
    partial class InfoAvion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            laebl3 = new Label();
            lasdf = new Label();
            asdf = new Label();
            asdfas = new Label();
            asf = new Label();
            label1 = new Label();
            lblId = new Label();
            lblCompañia = new Label();
            lblVelocidad = new Label();
            lblPosActual = new Label();
            lblPosDestino = new Label();
            lblEstado = new Label();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // laebl3
            // 
            laebl3.AutoSize = true;
            laebl3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            laebl3.Location = new Point(61, 71);
            laebl3.Margin = new Padding(2, 0, 2, 0);
            laebl3.Name = "laebl3";
            laebl3.Size = new Size(29, 20);
            laebl3.TabIndex = 0;
            laebl3.Text = "ID:";
            // 
            // lasdf
            // 
            lasdf.AutoSize = true;
            lasdf.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lasdf.Location = new Point(61, 158);
            lasdf.Margin = new Padding(2, 0, 2, 0);
            lasdf.Name = "lasdf";
            lasdf.Size = new Size(80, 20);
            lasdf.TabIndex = 1;
            lasdf.Text = "Velocidad:";
            // 
            // asdf
            // 
            asdf.AutoSize = true;
            asdf.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            asdf.Location = new Point(61, 204);
            asdf.Margin = new Padding(2, 0, 2, 0);
            asdf.Name = "asdf";
            asdf.Size = new Size(120, 20);
            asdf.TabIndex = 2;
            asdf.Text = "Posición Actual:";
            // 
            // asdfas
            // 
            asdfas.AutoSize = true;
            asdfas.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            asdfas.Location = new Point(61, 254);
            asdfas.Margin = new Padding(2, 0, 2, 0);
            asdfas.Name = "asdfas";
            asdfas.Size = new Size(129, 20);
            asdfas.TabIndex = 3;
            asdfas.Text = "Posición Destino:";
            // 
            // asf
            // 
            asf.AutoSize = true;
            asf.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            asf.Location = new Point(61, 306);
            asf.Margin = new Padding(2, 0, 2, 0);
            asf.Name = "asf";
            asf.Size = new Size(60, 20);
            asf.TabIndex = 4;
            asf.Text = "Estado:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(61, 112);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(83, 20);
            label1.TabIndex = 5;
            label1.Text = "Compañía:";
            // 
            // lblId
            // 
            lblId.AutoSize = true;
            lblId.Location = new Point(94, 71);
            lblId.Margin = new Padding(2, 0, 2, 0);
            lblId.Name = "lblId";
            lblId.Size = new Size(0, 20);
            lblId.TabIndex = 6;
            // 
            // lblCompañia
            // 
            lblCompañia.AutoSize = true;
            lblCompañia.Location = new Point(148, 112);
            lblCompañia.Margin = new Padding(2, 0, 2, 0);
            lblCompañia.Name = "lblCompañia";
            lblCompañia.Size = new Size(0, 20);
            lblCompañia.TabIndex = 7;
            // 
            // lblVelocidad
            // 
            lblVelocidad.AutoSize = true;
            lblVelocidad.Location = new Point(148, 158);
            lblVelocidad.Margin = new Padding(2, 0, 2, 0);
            lblVelocidad.Name = "lblVelocidad";
            lblVelocidad.Size = new Size(0, 20);
            lblVelocidad.TabIndex = 8;
            // 
            // lblPosActual
            // 
            lblPosActual.AutoSize = true;
            lblPosActual.Location = new Point(190, 204);
            lblPosActual.Margin = new Padding(2, 0, 2, 0);
            lblPosActual.Name = "lblPosActual";
            lblPosActual.Size = new Size(0, 20);
            lblPosActual.TabIndex = 9;
            // 
            // lblPosDestino
            // 
            lblPosDestino.AutoSize = true;
            lblPosDestino.Location = new Point(194, 254);
            lblPosDestino.Margin = new Padding(2, 0, 2, 0);
            lblPosDestino.Name = "lblPosDestino";
            lblPosDestino.Size = new Size(0, 20);
            lblPosDestino.TabIndex = 10;
            // 
            // lblEstado
            // 
            lblEstado.AutoSize = true;
            lblEstado.Location = new Point(125, 306);
            lblEstado.Margin = new Padding(2, 0, 2, 0);
            lblEstado.Name = "lblEstado";
            lblEstado.Size = new Size(0, 20);
            lblEstado.TabIndex = 11;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(457, 59);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(315, 292);
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            // 
            // InfoAvion
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(839, 430);
            Controls.Add(pictureBox1);
            Controls.Add(lblEstado);
            Controls.Add(lblPosDestino);
            Controls.Add(lblPosActual);
            Controls.Add(lblVelocidad);
            Controls.Add(lblCompañia);
            Controls.Add(lblId);
            Controls.Add(label1);
            Controls.Add(asf);
            Controls.Add(asdfas);
            Controls.Add(asdf);
            Controls.Add(lasdf);
            Controls.Add(laebl3);
            Margin = new Padding(2);
            Name = "InfoAvion";
            Text = "Información del Avión";
            Load += InfoAvion_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label laebl3;
        private Label lasdf;
        private Label asdf;
        private Label asdfas;
        private Label asf;
        private Label label1;
        private Label lblId;
        private Label lblCompañia;
        private Label lblVelocidad;
        private Label lblPosActual;
        private Label lblPosDestino;
        private Label lblEstado;
        private PictureBox pictureBox1;
    }
}