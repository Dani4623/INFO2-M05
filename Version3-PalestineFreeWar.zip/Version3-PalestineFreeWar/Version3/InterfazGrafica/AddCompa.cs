﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FlightLib;

namespace InterfazGrafica
{
    public partial class AddCompa : Form
    {
        BaseDatosCompañia BBDD;
        public string NombreCompania = "";
        public string TelefonoCompania = "";
        public string EmailCompania = "";
        public Image ImagenCompañia = null;

        private Dictionary<string, List<string>> companyImages = new Dictionary<string, List<string>>();
        public AddCompa()
        {
            InitializeComponent();
            companyImages["Iberia"] = new List<string> { "iberia1.jpg"};
            companyImages["Vueling"] = new List<string> { "vueling1.jpg" };
            companyImages["Air France"] = new List<string> { "airfrance1.png"};
            companyImages["KLM"] = new List<string> { "klm1.png"};
            companyImages["Ryanair"] = new List<string> { "ryanair1.png"};
            companyImages["Lufthansa"] = new List<string> { "lufthansa1.png"};
            companyImages["Emirates"] = new List<string> { "emirates1.png"};
            companyImages["Delta"] = new List<string> { "delta1.png"};
            companyImages["British Airways"] = new List<string> { "ba1.png"};

            // Llenar ComboBox con las compañías
            comboBoxCompanies.Items.AddRange(new object[] { "Iberia","Vueling", "Air France","KLM","Ryanair","Lufthansa","Emirates","Delta","British Airways" });
            comboBoxCompanies.SelectedIndexChanged += ComboBoxCompanies_SelectedIndexChanged;

        }
        private void ComboBoxCompanies_SelectedIndexChanged(object sender, EventArgs e)
        {
            flowLayoutPanelImages.Controls.Clear();

            string selectedCompany = comboBoxCompanies.SelectedItem.ToString();
            if (companyImages.ContainsKey(selectedCompany))
            {
                foreach (var imagePath in companyImages[selectedCompany])
                {
                    PictureBox pb = new PictureBox();
                    pb.Image = Image.FromFile(imagePath);
                    pb.SizeMode = PictureBoxSizeMode.StretchImage;
                    pb.Width = 100;
                    pb.Height = 100;
                    pb.Margin = new Padding(5);

                    // Evento click para seleccionar la imagen
                    pb.Click += (s, ev) =>
                    {
                        ImagenCompañia = pb.Image; // Guardar la imagen seleccionada
                                                   // Opcional: mostrar en un PictureBox grande
                        pictureBoxSelected.Image = ImagenCompañia;
                    };

                    flowLayoutPanelImages.Controls.Add(pb);
                }
            }
        }





        private void AddCompa_Load(object sender, EventArgs e)
        {
            BBDD = new BaseDatosCompañia();
            BBDD.InicializarBD();
        }

        private void Guardar_Click(object sender, EventArgs e)
        {
            NombreCompania = txtNombre.Text.Trim();
            TelefonoCompania = txtTelefono.Text.Trim();
            EmailCompania = txtEmail.Text.Trim();

            byte[] imageBytes = null;

            // Solo convertir si hay imagen seleccionada
            if (ImagenCompañia != null)
            {
                imageBytes = BBDD.ImagenToBytes(ImagenCompañia);
            }

            // Registrar la compañía, pasando null si no hay imagen
            int res = BBDD.RegistrarCompañias(NombreCompania, TelefonoCompania, EmailCompania, imageBytes);

            if (res == 1)
            {
                MessageBox.Show("Compañía registrada con éxito.");
            }
            else
            {
                MessageBox.Show("Error al registrar la compañía");
            }

            this.Close();
        }
        private void Cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
