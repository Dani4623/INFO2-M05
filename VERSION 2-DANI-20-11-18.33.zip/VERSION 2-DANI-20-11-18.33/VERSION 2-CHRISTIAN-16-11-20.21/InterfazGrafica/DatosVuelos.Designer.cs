﻿namespace InterfazGrafica
{
    partial class DatosVuelos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            PFVuelo1 = new TextBox();
            IDVuelo1 = new TextBox();
            VelocidadVuelo1 = new TextBox();
            PIVuelo1 = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label6 = new Label();
            btnAceptar = new Button();
            DatosEjemploBtn = new Button();
            Volver_Btn = new Button();
            label1 = new Label();
            companytxt = new TextBox();
            SuspendLayout();
            // 
            // PFVuelo1
            // 
            PFVuelo1.Location = new Point(275, 272);
            PFVuelo1.Margin = new Padding(2);
            PFVuelo1.Name = "PFVuelo1";
            PFVuelo1.Size = new Size(121, 27);
            PFVuelo1.TabIndex = 1;
            // 
            // IDVuelo1
            // 
            IDVuelo1.Location = new Point(275, 55);
            IDVuelo1.Margin = new Padding(2);
            IDVuelo1.Name = "IDVuelo1";
            IDVuelo1.Size = new Size(121, 27);
            IDVuelo1.TabIndex = 3;
            // 
            // VelocidadVuelo1
            // 
            VelocidadVuelo1.Location = new Point(275, 160);
            VelocidadVuelo1.Margin = new Padding(2);
            VelocidadVuelo1.Name = "VelocidadVuelo1";
            VelocidadVuelo1.Size = new Size(121, 27);
            VelocidadVuelo1.TabIndex = 4;
            // 
            // PIVuelo1
            // 
            PIVuelo1.Location = new Point(275, 211);
            PIVuelo1.Margin = new Padding(2);
            PIVuelo1.Name = "PIVuelo1";
            PIVuelo1.Size = new Size(121, 27);
            PIVuelo1.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(275, 189);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(140, 20);
            label2.TabIndex = 9;
            label2.Text = "Posición inicial (X,Y)";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(275, 250);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(130, 20);
            label3.TabIndex = 10;
            label3.Text = "Posición final (X,Y)";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(322, 33);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(24, 20);
            label4.TabIndex = 11;
            label4.Text = "ID";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(299, 138);
            label6.Margin = new Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new Size(75, 20);
            label6.TabIndex = 13;
            label6.Text = "Velocidad";
            // 
            // btnAceptar
            // 
            btnAceptar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAceptar.Location = new Point(275, 346);
            btnAceptar.Margin = new Padding(2);
            btnAceptar.Name = "btnAceptar";
            btnAceptar.Size = new Size(121, 27);
            btnAceptar.TabIndex = 14;
            btnAceptar.Text = "Aceptar";
            btnAceptar.UseVisualStyleBackColor = true;
            btnAceptar.Click += btnAceptar_Click;
            // 
            // DatosEjemploBtn
            // 
            DatosEjemploBtn.Location = new Point(35, 346);
            DatosEjemploBtn.Name = "DatosEjemploBtn";
            DatosEjemploBtn.Size = new Size(194, 27);
            DatosEjemploBtn.TabIndex = 15;
            DatosEjemploBtn.Text = "Datos de ejemplo";
            DatosEjemploBtn.UseVisualStyleBackColor = true;
            DatosEjemploBtn.Click += DatosEjemploBtn_Click;
            // 
            // Volver_Btn
            // 
            Volver_Btn.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Volver_Btn.Location = new Point(475, 345);
            Volver_Btn.Name = "Volver_Btn";
            Volver_Btn.Size = new Size(121, 29);
            Volver_Btn.TabIndex = 16;
            Volver_Btn.Text = "Volver";
            Volver_Btn.UseVisualStyleBackColor = true;
            Volver_Btn.Click += Volver_Btn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(297, 87);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(77, 20);
            label1.TabIndex = 18;
            label1.Text = "Compañía";
            label1.Click += label1_Click;
            // 
            // companytxt
            // 
            companytxt.Location = new Point(275, 109);
            companytxt.Margin = new Padding(2);
            companytxt.Name = "companytxt";
            companytxt.Size = new Size(121, 27);
            companytxt.TabIndex = 17;
            // 
            // DatosVuelos
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(683, 403);
            Controls.Add(label1);
            Controls.Add(companytxt);
            Controls.Add(Volver_Btn);
            Controls.Add(DatosEjemploBtn);
            Controls.Add(btnAceptar);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(PIVuelo1);
            Controls.Add(VelocidadVuelo1);
            Controls.Add(IDVuelo1);
            Controls.Add(PFVuelo1);
            Margin = new Padding(2);
            Name = "DatosVuelos";
            Text = "Form1";
            Load += DatosVuelos_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox PFVuelo1;
        private TextBox IDVuelo1;
        private TextBox VelocidadVuelo1;
        private TextBox PIVuelo1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label6;
        private Button btnAceptar;
        private Button DatosEjemploBtn;
        private Button Volver_Btn;
        private Label label1;
        private TextBox companytxt;
    }
}