﻿using System;
using System.Windows.Forms;
using FlightLib;

namespace InterfazGrafica
{
    public partial class DatosVuelos : Form
    {
        public FlightPlanList listaPlanesVuelo = new FlightPlanList();

        public DatosVuelos()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            try
            {
                string[] pi1 = PIVuelo1.Text.Split(',');
                string[] pf1 = PFVuelo1.Text.Split(',');

                FlightPlan vuelo = new FlightPlan(IDVuelo1.Text, companytxt.Text,Convert.ToDouble(pi1[0]), Convert.ToDouble(pi1[1]),
                    Convert.ToDouble(pf1[0]), Convert.ToDouble(pf1[1]), Convert.ToDouble(VelocidadVuelo1.Text));

                listaPlanesVuelo.AddFlightPlan(vuelo);
                PIVuelo1.Clear();
                PFVuelo1.Clear();
                IDVuelo1.Clear();
                VelocidadVuelo1.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en los datos. Formato correcto: x,y");
            }
        }

        private void DatosVuelos_Load(object sender, EventArgs e)
        {
        }

        private void DatosEjemploBtn_Click(object sender, EventArgs e)
        {
            IDVuelo1.Text = "IB123";
            VelocidadVuelo1.Text = "100";
            PIVuelo1.Text = "100,100";
            PFVuelo1.Text = "300,300";

        }

        private void Volver_Btn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}