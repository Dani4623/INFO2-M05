﻿namespace InterfazGrafica
{
    partial class DatosVuelos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            PFVuelo2 = new TextBox();
            PFVuelo1 = new TextBox();
            PIVuelo2 = new TextBox();
            IDVuelo1 = new TextBox();
            VelocidadVuelo1 = new TextBox();
            PIVuelo1 = new TextBox();
            VelocidadVuelo2 = new TextBox();
            IDVuelo2 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            btnAceptar = new Button();
            SuspendLayout();
            // 
            // PFVuelo2
            // 
            PFVuelo2.Location = new Point(442, 282);
            PFVuelo2.Margin = new Padding(2, 2, 2, 2);
            PFVuelo2.Name = "PFVuelo2";
            PFVuelo2.Size = new Size(121, 27);
            PFVuelo2.TabIndex = 0;
            // 
            // PFVuelo1
            // 
            PFVuelo1.Location = new Point(50, 282);
            PFVuelo1.Margin = new Padding(2, 2, 2, 2);
            PFVuelo1.Name = "PFVuelo1";
            PFVuelo1.Size = new Size(121, 27);
            PFVuelo1.TabIndex = 1;
            // 
            // PIVuelo2
            // 
            PIVuelo2.Location = new Point(442, 220);
            PIVuelo2.Margin = new Padding(2, 2, 2, 2);
            PIVuelo2.Name = "PIVuelo2";
            PIVuelo2.Size = new Size(121, 27);
            PIVuelo2.TabIndex = 2;
            // 
            // IDVuelo1
            // 
            IDVuelo1.Location = new Point(50, 78);
            IDVuelo1.Margin = new Padding(2, 2, 2, 2);
            IDVuelo1.Name = "IDVuelo1";
            IDVuelo1.Size = new Size(121, 27);
            IDVuelo1.TabIndex = 3;
            // 
            // VelocidadVuelo1
            // 
            VelocidadVuelo1.Location = new Point(50, 153);
            VelocidadVuelo1.Margin = new Padding(2, 2, 2, 2);
            VelocidadVuelo1.Name = "VelocidadVuelo1";
            VelocidadVuelo1.Size = new Size(121, 27);
            VelocidadVuelo1.TabIndex = 4;
            // 
            // PIVuelo1
            // 
            PIVuelo1.Location = new Point(50, 220);
            PIVuelo1.Margin = new Padding(2, 2, 2, 2);
            PIVuelo1.Name = "PIVuelo1";
            PIVuelo1.Size = new Size(121, 27);
            PIVuelo1.TabIndex = 5;
            // 
            // VelocidadVuelo2
            // 
            VelocidadVuelo2.Location = new Point(442, 153);
            VelocidadVuelo2.Margin = new Padding(2, 2, 2, 2);
            VelocidadVuelo2.Name = "VelocidadVuelo2";
            VelocidadVuelo2.Size = new Size(121, 27);
            VelocidadVuelo2.TabIndex = 6;
            // 
            // IDVuelo2
            // 
            IDVuelo2.Location = new Point(442, 78);
            IDVuelo2.Margin = new Padding(2, 2, 2, 2);
            IDVuelo2.Name = "IDVuelo2";
            IDVuelo2.Size = new Size(121, 27);
            IDVuelo2.TabIndex = 7;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(86, 31);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(59, 20);
            label1.TabIndex = 8;
            label1.Text = "Vuelo 1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(255, 222);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(140, 20);
            label2.TabIndex = 9;
            label2.Text = "Posición inicial (X,Y)";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(255, 287);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(130, 20);
            label3.TabIndex = 10;
            label3.Text = "Posición final (X,Y)";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(302, 83);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(24, 20);
            label4.TabIndex = 11;
            label4.Text = "ID";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(476, 31);
            label5.Margin = new Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new Size(59, 20);
            label5.TabIndex = 12;
            label5.Text = "Vuelo 2";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(279, 158);
            label6.Margin = new Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new Size(75, 20);
            label6.TabIndex = 13;
            label6.Text = "Velocidad";
            // 
            // btnAceptar
            // 
            btnAceptar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAceptar.Location = new Point(270, 24);
            btnAceptar.Margin = new Padding(2, 2, 2, 2);
            btnAceptar.Name = "btnAceptar";
            btnAceptar.Size = new Size(90, 27);
            btnAceptar.TabIndex = 14;
            btnAceptar.Text = "Aceptar";
            btnAceptar.UseVisualStyleBackColor = true;
            btnAceptar.Click += btnAceptar_Click;
            // 
            // DatosVuelos
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(640, 360);
            Controls.Add(btnAceptar);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(IDVuelo2);
            Controls.Add(VelocidadVuelo2);
            Controls.Add(PIVuelo1);
            Controls.Add(VelocidadVuelo1);
            Controls.Add(IDVuelo1);
            Controls.Add(PIVuelo2);
            Controls.Add(PFVuelo1);
            Controls.Add(PFVuelo2);
            Margin = new Padding(2, 2, 2, 2);
            Name = "DatosVuelos";
            Text = "Form1";
            this.Load += new System.EventHandler(this.DatosVuelos_Load);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox PFVuelo2;
        private TextBox PFVuelo1;
        private TextBox PIVuelo2;
        private TextBox IDVuelo1;
        private TextBox VelocidadVuelo1;
        private TextBox PIVuelo1;
        private TextBox VelocidadVuelo2;
        private TextBox IDVuelo2;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Button btnAceptar;
    }
}