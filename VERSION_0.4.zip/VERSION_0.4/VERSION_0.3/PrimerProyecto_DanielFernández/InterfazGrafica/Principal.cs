using FlightLib;
using System;
using System.Windows.Forms;

namespace InterfazGrafica
{
    public partial class Principal : Form
    {
        private FlightPlan Vuelo1;
        private FlightPlan Vuelo2;
        private double distanciaSeguridad;
        private int tiempoCiclo;
        public Principal()
        {
            InitializeComponent();
        }

        private void cargarListaDeVuelosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DatosVuelos formDatos = new DatosVuelos();
            if (formDatos.ShowDialog() == DialogResult.OK)
            {
                Vuelo1 = formDatos.Vuelo1;
                Vuelo2 = formDatos.Vuelo2;

                MessageBox.Show("Vuelos cargados correctamente");
            }
        }

        private void distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Configuracion formConfig = new Configuracion();
            if (formConfig.ShowDialog() == DialogResult.OK)
            {
                // Usar los nuevos nombres de propiedades
                distanciaSeguridad = formConfig.DistanciaSeguridadValor;
                tiempoCiclo = (int)formConfig.TiempoCicloValor;
                MessageBox.Show("Configuraci�n guardada");
            }
        }

        private void simulaci�nToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Vuelo1 == null || Vuelo2 == null)
            {
                MessageBox.Show("Primero carga los datos de vuelos");
                return;
            }

            // Crear lista y a�adir vuelos
            FlightPlanList lista = new FlightPlanList();
            lista.AddFlightPlan(Vuelo1);
            lista.AddFlightPlan(Vuelo2);

            // Pasar la lista y tiempoCiclo
            FormSimulacion formSimulacion = new FormSimulacion(lista, (int)tiempoCiclo);
            formSimulacion.Show();
        }

        private void Principal_Load(object sender, EventArgs e)
        {

        }
    }
}