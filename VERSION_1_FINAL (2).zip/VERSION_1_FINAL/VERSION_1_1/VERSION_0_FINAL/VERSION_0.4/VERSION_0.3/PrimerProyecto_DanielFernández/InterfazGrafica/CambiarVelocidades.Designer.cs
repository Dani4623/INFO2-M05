﻿namespace InterfazGrafica
{
    partial class CambiarVelocidades
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAceptar = new Button();
            label1 = new Label();
            Velocidad1 = new TextBox();
            Velocidad2 = new TextBox();
            label2 = new Label();
            SuspendLayout();
            // 
            // btnAceptar
            // 
            btnAceptar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAceptar.Location = new Point(348, 322);
            btnAceptar.Name = "btnAceptar";
            btnAceptar.Size = new Size(112, 34);
            btnAceptar.TabIndex = 0;
            btnAceptar.Text = "Aceptar";
            btnAceptar.UseVisualStyleBackColor = true;
            btnAceptar.Click += btnAceptar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(101, 125);
            label1.Name = "label1";
            label1.Size = new Size(154, 25);
            label1.TabIndex = 1;
            label1.Text = "Velocidad Vuelo 1";
            // 
            // Velocidad1
            // 
            Velocidad1.Location = new Point(101, 176);
            Velocidad1.Name = "Velocidad1";
            Velocidad1.Size = new Size(150, 31);
            Velocidad1.TabIndex = 2;
            // 
            // Velocidad2
            // 
            Velocidad2.Location = new Point(549, 176);
            Velocidad2.Name = "Velocidad2";
            Velocidad2.Size = new Size(150, 31);
            Velocidad2.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(549, 125);
            label2.Name = "label2";
            label2.Size = new Size(154, 25);
            label2.TabIndex = 4;
            label2.Text = "Velocidad Vuelo 2";
            // 
            // CambiarVelocidades
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label2);
            Controls.Add(Velocidad2);
            Controls.Add(Velocidad1);
            Controls.Add(label1);
            Controls.Add(btnAceptar);
            Name = "CambiarVelocidades";
            Text = "Form1";
            Load += CambiarVelocidades_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAceptar;
        private Label label1;
        private TextBox Velocidad1;
        private TextBox Velocidad2;
        private Label label2;
    }
}