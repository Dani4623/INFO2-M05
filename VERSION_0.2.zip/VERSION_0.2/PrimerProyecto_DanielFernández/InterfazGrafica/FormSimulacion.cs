﻿using FlightLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterfazGrafica
{
    public partial class FormSimulacion : Form
    {
        private FlightPlanList miLista;
        int tiempoCiclo;

        public FormSimulacion(FlightPlanList lista, int tiempo)
        {
            InitializeComponent();
            miLista = lista;
            tiempoCiclo = tiempo;
        }


        private void btnMoverCiclo_Click(object sender, EventArgs e)
        {
            miLista.Mover(tiempoCiclo);

            // Actualizar posición de Avion1
            Avion1.Location = new Point(
                (int)miLista.GetFlightPlan(0).GetCurrentPosition().GetX(),
                (int)miLista.GetFlightPlan(0).GetCurrentPosition().GetY()
            );

            // Actualizar posición de Avion2
            Avion2.Location = new Point(
                (int)miLista.GetFlightPlan(1).GetCurrentPosition().GetX(),
                (int)miLista.GetFlightPlan(1).GetCurrentPosition().GetY()
            );
        }

        private void FormSimulacion_Load(object sender, EventArgs e)
        {
            Avion1.Location = new Point((int)miLista.GetFlightPlan(0).GetCurrentPosition().GetX(), (int)miLista.GetFlightPlan(0).GetCurrentPosition().GetY());
            Avion2.Location = new Point((int)miLista.GetFlightPlan(1).GetCurrentPosition().GetX(), (int)miLista.GetFlightPlan(1).GetCurrentPosition().GetY());

        }

        private void Avion1_Click_1(object sender, EventArgs e)
        {
            InfoAvion formInfo = new InfoAvion(miLista.GetFlightPlan(0));
            formInfo.Show();
        }

        private void Avion2_Click(object sender, EventArgs e)
        {
            InfoAvion formInfo = new InfoAvion(miLista.GetFlightPlan(1));
            formInfo.Show();
        }
    }
}
