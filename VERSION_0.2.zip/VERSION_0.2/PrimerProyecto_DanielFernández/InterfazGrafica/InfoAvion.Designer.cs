﻿namespace InterfazGrafica
{
    partial class InfoAvion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblId = new Label();
            lblVelocidad = new Label();
            lblPosActual = new Label();
            lblPosDestino = new Label();
            lblEstado = new Label();
            SuspendLayout();
            // 
            // lblId
            // 
            lblId.AutoSize = true;
            lblId.Location = new Point(88, 63);
            lblId.Name = "lblId";
            lblId.Size = new Size(34, 25);
            lblId.TabIndex = 0;
            lblId.Text = "ID:";
            // 
            // lblVelocidad
            // 
            lblVelocidad.AutoSize = true;
            lblVelocidad.Location = new Point(88, 139);
            lblVelocidad.Name = "lblVelocidad";
            lblVelocidad.Size = new Size(93, 25);
            lblVelocidad.TabIndex = 1;
            lblVelocidad.Text = "Velocidad:";
            // 
            // lblPosActual
            // 
            lblPosActual.AutoSize = true;
            lblPosActual.Location = new Point(88, 213);
            lblPosActual.Name = "lblPosActual";
            lblPosActual.Size = new Size(135, 25);
            lblPosActual.TabIndex = 2;
            lblPosActual.Text = "Posición Actual:";
            // 
            // lblPosDestino
            // 
            lblPosDestino.AutoSize = true;
            lblPosDestino.Location = new Point(88, 291);
            lblPosDestino.Name = "lblPosDestino";
            lblPosDestino.Size = new Size(147, 25);
            lblPosDestino.TabIndex = 3;
            lblPosDestino.Text = "Posición Destino:";
            // 
            // lblEstado
            // 
            lblEstado.AutoSize = true;
            lblEstado.Location = new Point(88, 364);
            lblEstado.Name = "lblEstado";
            lblEstado.Size = new Size(70, 25);
            lblEstado.TabIndex = 4;
            lblEstado.Text = "Estado:";
            // 
            // InfoAvion
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblEstado);
            Controls.Add(lblPosDestino);
            Controls.Add(lblPosActual);
            Controls.Add(lblVelocidad);
            Controls.Add(lblId);
            Name = "InfoAvion";
            Text = "Información del Avión";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblId;
        private Label lblVelocidad;
        private Label lblPosActual;
        private Label lblPosDestino;
        private Label lblEstado;
    }
}