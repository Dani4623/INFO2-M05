﻿using FlightLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace InterfazGrafica
{
    public partial class FormSimulacion : Form
    {
        private bool conflictoActivo = false;
        private FlightPlanList miLista;
        private List<int> vuelosEnConflicto = new List<int>();
        int tiempoCiclo;
        private List<PictureBox> iconosAviones = new List<PictureBox>();
        private Stack<Point[]> posiciones = new Stack<Point[]>();
        bool tienenEstadoAnterior = false;
        private bool simulacionTerminada = false;
        private List<bool> vuelosVisibles = new List<bool>(); // Controla qué aviones mostrar

        private double distanciaSeguridad;
        private int diametroSeguridad;
        private bool mensajeListaVaciaMostrado = false;
        private CompanyManager companyManager;
        private List<string> cambiosRealizados = new List<string>();

        public void SetPlanes(FlightPlanList lista)
        {
            miLista = lista;
        }

        public FormSimulacion(int tiempo, double distSeguridad)
        {
            InitializeComponent();

            // ========== Conectar eventos de filtros ==========
            this.btnFiltrar.Click += new System.EventHandler(this.btnFiltrar_Click);
            this.btnLimpiarFiltros.Click += new System.EventHandler(this.btnLimpiarFiltros_Click);
            // =================================================

            tiempoCiclo = tiempo;
            distanciaSeguridad = distSeguridad;
            diametroSeguridad = Convert.ToInt32((distanciaSeguridad * 2));

            // Inicializar CompanyManager
            companyManager = new CompanyManager();

            miPanel.Paint += new PaintEventHandler(DibujarLineasRuta);
            miPanel.Paint += new PaintEventHandler(DibujarElementos);
            miPanel.Paint += new PaintEventHandler(DibujarCuadriculaRadar);

            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.miPanel.BackColor = System.Drawing.Color.Black;
            this.miPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.miPanel.ForeColor = System.Drawing.Color.FromArgb(0, 192, 192);
            System.Drawing.Color accentColor = System.Drawing.Color.FromArgb(0, 192, 192);

            this.Inicio.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(0, 192, 192);
            this.Inicio.FlatAppearance.BorderSize = 1;

            System.Drawing.Color buttonBackColor = System.Drawing.Color.FromArgb(45, 50, 60);
            System.Drawing.Color buttonForeColor = System.Drawing.Color.WhiteSmoke;

            // Incluir botones de filtros en el array
            System.Windows.Forms.Button[] allButtons = new System.Windows.Forms.Button[]
            {
                this.btnMoverCiclo,
                this.Inicio,
                this.Final,
                this.MostrarDatosActuales,
                this.btnCambiarVelocidadesDeLosVuelos,
                this.btnReiniciar,
                this.deshacerBtn,
                this.btnVerificarConflicto,
                this.mostrarDistanciasTxt,
                this.mostrarVuelosBtn,
                this.exportarListaBtn,
                this.informesBtn,
                this.btnCambiarTrayectoria,
                this.btnFiltrar,           // NUEVO: Botón de filtrar
                this.btnLimpiarFiltros     // NUEVO: Botón de limpiar filtros
            };

            foreach (System.Windows.Forms.Button btn in allButtons)
            {
                btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
                btn.BackColor = buttonBackColor;
                btn.ForeColor = buttonForeColor;
                btn.FlatAppearance.BorderColor = accentColor;
                btn.FlatAppearance.BorderSize = 1;
            }

            this.BackColor = System.Drawing.Color.WhiteSmoke;
        }

        private void DibujarCuadriculaRadar(object sender, PaintEventArgs e)
        {
            Color gridColor = Color.FromArgb(20, 0, 192, 192);
            using (Pen gridPen = new Pen(gridColor, 1))
            {
                int panelWidth = miPanel.Width;
                int panelHeight = miPanel.Height;
                const int step = 50;

                for (int x = 0; x < panelWidth; x += step)
                {
                    e.Graphics.DrawLine(gridPen, x, 0, x, panelHeight);
                }

                for (int y = 0; y < panelHeight; y += step)
                {
                    e.Graphics.DrawLine(gridPen, 0, y, panelWidth, y);
                }
            }
        }

        private void FormSimulacion_Load(object sender, EventArgs e)
        {
            if (!mensajeListaVaciaMostrado && (miLista == null || miLista.GetNum() == 0))
            {
                MessageBox.Show("No hay vuelos cargados en la simulación.", "Lista vacía", MessageBoxButtons.OK, MessageBoxIcon.Information);
                mensajeListaVaciaMostrado = true;
                return;
            }

            InicializarIconos();
            RegistrarInicioSimulacion();

            // Cargar aerolíneas al iniciar
            CargarAerolineas();
        }

        private void InicializarIconos()
        {
            iconosAviones.Clear();
            miPanel.Controls.Clear();

            // Inicializar lista de visibles (todos visibles al principio)
            vuelosVisibles.Clear();

            if (miLista == null || miLista.GetNum() == 0)
            {
                MessageBox.Show("No hay vuelos para mostrar", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            for (int i = 0; i < miLista.GetNum(); i++)
            {
                try
                {
                    FlightPlan vuelo = miLista.GetFlightPlan(i);
                    if (vuelo == null) continue;

                    PictureBox avion = new PictureBox();
                    avion.Width = 20;
                    avion.Height = 20;
                    avion.BackColor = Color.LightGreen;
                    avion.BorderStyle = BorderStyle.FixedSingle;
                    avion.Tag = i;

                    int x = Convert.ToInt32(vuelo.GetCurrentPosition().GetX());
                    int y = Convert.ToInt32(vuelo.GetCurrentPosition().GetY());

                    // Validar coordenadas
                    x = Math.Max(0, Math.Min(x, miPanel.Width - avion.Width));
                    y = Math.Max(0, Math.Min(y, miPanel.Height - avion.Height));

                    avion.Location = new Point(x, y);

                    System.Windows.Forms.Label lbl = new System.Windows.Forms.Label();
                    lbl.Text = vuelo.GetId() ?? $"Vuelo {i + 1}";
                    lbl.AutoSize = true;
                    lbl.BackColor = Color.Transparent;
                    lbl.ForeColor = Color.White;
                    lbl.Font = new Font("Arial", 8);
                    lbl.Location = new Point(x + 15, y - 15);

                    miPanel.Controls.Add(avion);
                    miPanel.Controls.Add(lbl);
                    iconosAviones.Add(avion);
                    avion.Click += Avion_Click;

                    // Todos visibles al inicio
                    vuelosVisibles.Add(true);
                }
                catch (Exception)
                {
                    // Continuar con el siguiente avión si hay error
                    vuelosVisibles.Add(true);
                }
            }

            GuardarEstadoInicial();
            miPanel.Invalidate();
        }

        private void GuardarEstadoInicial()
        {
            if (miLista == null || miLista.GetNum() == 0) return;

            Point[] estadoInicial = new Point[miLista.GetNum()];
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                FlightPlan vuelo = miLista.GetFlightPlan(i);
                if (vuelo != null)
                {
                    estadoInicial[i] = new Point(
                        Convert.ToInt32(vuelo.GetCurrentPosition().GetX()),
                        Convert.ToInt32(vuelo.GetCurrentPosition().GetY())
                    );
                }
            }

            posiciones.Clear();
            posiciones.Push(estadoInicial);
        }

        private void DibujarLineasRuta(object sender, PaintEventArgs e)
        {
            if (!mensajeListaVaciaMostrado && (miLista == null || miLista.GetNum() == 0))
            {
                return;
            }

            for (int i = 0; i < miLista.GetNum(); i++)
            {
                // Si hay filtro activo y este avión no se debe mostrar, saltar
                if (vuelosVisibles.Count > 0 && vuelosVisibles.Count > i && !vuelosVisibles[i])
                    continue;

                Point origen = new Point(
                    Convert.ToInt32(miLista.GetFlightPlan(i).GetInitialPosition().GetX()),
                    Convert.ToInt32(miLista.GetFlightPlan(i).GetInitialPosition().GetY())
                );
                Point destino = new Point(
                    Convert.ToInt32(miLista.GetFlightPlan(i).GetFinalPosition().GetX()),
                    Convert.ToInt32(miLista.GetFlightPlan(i).GetFinalPosition().GetY())
                );

                Color colorLinea = Color.FromArgb(0, 192, 192);
                bool enConflicto = vuelosEnConflicto.Contains(i);

                if (enConflicto)
                {
                    colorLinea = Color.Red;
                }

                using (Pen pen = new Pen(colorLinea, 2))
                {
                    pen.DashStyle = DashStyle.Dash;
                    e.Graphics.DrawLine(pen, origen, destino);
                    DibujarFlecha(e.Graphics, colorLinea, origen, destino, 0.33f);
                    DibujarFlecha(e.Graphics, colorLinea, origen, destino, 0.66f);
                }
            }
        }
        private void DibujarFlecha(Graphics g, Color color, Point origen, Point destino, float porcentaje)
        {
            // 1. Calcular la posición de la flecha
            int xCentro = origen.X + (int)((destino.X - origen.X) * porcentaje);
            int yCentro = origen.Y + (int)((destino.Y - origen.Y) * porcentaje);

            // 2. Crear un triángulo sólido (flecha grande)
            Point[] triangulo = new Point[3];

            // Calcular dirección hacia el destino
            float direccionX = destino.X - origen.X;
            float direccionY = destino.Y - origen.Y;

            // Normalizar la dirección (hacerla de longitud 1)
            float longitud = (float)Math.Sqrt(direccionX * direccionX + direccionY * direccionY);
            if (longitud > 0)
            {
                direccionX /= longitud;
                direccionY /= longitud;
            }

            // TAMAÑO DE LA FLECHA - AJUSTA ESTO PARA HACERLA MÁS GRANDE
            int tamañoFlecha = 15; // ¡Cambia este número si quieres más grande o más pequeña!

            // Punta de la flecha (apuntando hacia el destino)
            triangulo[0] = new Point(
                xCentro + (int)(tamañoFlecha * direccionX),
                yCentro + (int)(tamañoFlecha * direccionY)
            );

            // Base izquierda de la flecha
            triangulo[1] = new Point(
                xCentro + (int)(tamañoFlecha * 0.5 * -direccionY),
                yCentro + (int)(tamañoFlecha * 0.5 * direccionX)
            );

            // Base derecha de la flecha  
            triangulo[2] = new Point(
                xCentro - (int)(tamañoFlecha * 0.5 * -direccionY),
                yCentro - (int)(tamañoFlecha * 0.5 * direccionX)
            );

            // 3. DIBUJAR LA FLECHA RELLENA Y CON BORDE
            using (SolidBrush brush = new SolidBrush(color))
            {
                g.FillPolygon(brush, triangulo); // Relleno sólido
            }

            using (Pen penBorde = new Pen(Color.White, 1)) // Borde blanco para que se vea mejor
            {
                g.DrawPolygon(penBorde, triangulo); // Borde
            }
        }
        private void DibujarElementos(object sender, PaintEventArgs e)
        {
            if (!mensajeListaVaciaMostrado && (miLista == null || miLista.GetNum() == 0))
            {
                return;
            }

            for (int i = 0; i < miLista.GetNum(); i++)
            {
                // Si hay filtro activo y este avión no se debe mostrar, saltar
                if (vuelosVisibles.Count > 0 && vuelosVisibles.Count > i && !vuelosVisibles[i])
                    continue;

                int x = Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetX());
                int y = Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetY());

                Rectangle elipse = new Rectangle(
                    x - Convert.ToInt32(distanciaSeguridad),
                    y - Convert.ToInt32(distanciaSeguridad),
                    diametroSeguridad,
                    diametroSeguridad
                );

                bool enConflicto = vuelosEnConflicto.Contains(i);

                if (enConflicto)
                {
                    using (Brush brush = new SolidBrush(Color.FromArgb(100, 255, 0, 0)))
                    {
                        e.Graphics.FillEllipse(brush, elipse);
                    }

                    using (Pen pen = new Pen(Color.Red, 1))
                    {
                        e.Graphics.DrawEllipse(pen, elipse);
                    }
                }
                else
                {
                    using (Brush brush = new SolidBrush(Color.FromArgb(50, 0, 192, 192)))
                    {
                        e.Graphics.FillEllipse(brush, elipse);
                    }

                    using (Pen pen = new Pen(Color.FromArgb(0, 192, 192), 1))
                    {
                        e.Graphics.DrawEllipse(pen, elipse);
                    }
                }
            }
        }

        private void GuardarEstadoActual()
        {
            if (miLista == null || miLista.GetNum() == 0) return;

            Point[] listaPosiciones = new Point[miLista.GetNum()];
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                FlightPlan vuelo = miLista.GetFlightPlan(i);
                if (vuelo != null)
                {
                    listaPosiciones[i] = new Point(
                        Convert.ToInt32(vuelo.GetCurrentPosition().GetX()),
                        Convert.ToInt32(vuelo.GetCurrentPosition().GetY())
                    );
                }
            }
            posiciones.Push(listaPosiciones);
            tienenEstadoAnterior = true;
        }

        private void btnMoverCiclo_Click(object sender, EventArgs e)
        {
            if (miLista == null || miLista.GetNum() == 0)
            {
                MessageBox.Show("No hay vuelos para mover", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (simulacionTerminada)
            {
                MessageBox.Show("La simulación ya terminó. Usa 'Deshacer' o 'Reiniciar'.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                GuardarEstadoActual();
                miLista.Mover(tiempoCiclo);
                ActualizarIconos();
                VerificarConflictoTiempoReal();
                miPanel.Invalidate();
                RegistrarMovimientoCiclo();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al mover aviones: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void SetDistanciaSeguridad(double distancia)
        {
            distanciaSeguridad = distancia;
            diametroSeguridad = Convert.ToInt32((distancia * 2));
            miPanel.Invalidate();
        }

        private void Avion_Click(object sender, EventArgs e)
        {
            if (!mensajeListaVaciaMostrado && (miLista == null || miLista.GetNum() == 0))
            {
                MessageBox.Show("No hay vuelos cargados en la simulación.", "Lista vacía", MessageBoxButtons.OK, MessageBoxIcon.Information);
                mensajeListaVaciaMostrado = true;
                return;
            }

            PictureBox pb = (PictureBox)sender;
            int index = Convert.ToInt32(pb.Tag);

            // Solo mostrar info si el avión está visible
            if (index < vuelosVisibles.Count && vuelosVisibles[index])
            {
                InfoAvion info = new InfoAvion(miLista.GetFlightPlan(index));
                info.Show();
            }
        }

        int i = 0;
        bool inicio = false;
        bool final = false;

        private void Inicio_Click(object sender, EventArgs e)
        {
            if (simulacionTerminada)
            {
                MessageBox.Show("La simulación ya terminó. Usa 'Deshacer' o 'Reiniciar'.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            inicio = true;
            final = false;
            simulacionTerminada = false;
            timer1.Enabled = true;
            RegistrarInicioAutomatico();
        }

        private void Final_Click(object sender, EventArgs e)
        {
            if (miLista == null || miLista.GetNum() == 0) return;

            inicio = false;
            final = true;
            timer1.Enabled = false;

            // Preguntar confirmación antes de finalizar
            DialogResult resultado = MessageBox.Show(
                "¿Está seguro de que desea finalizar la simulación?\n\n" +
                "Todos los aviones se moverán a sus destinos finales.",
                "Confirmar finalización",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (resultado != DialogResult.Yes)
                return;

            // Registrar cambios de posición final
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                FlightPlan vuelo = miLista.GetFlightPlan(i);
                if (!vuelo.HasArrived())
                {
                    double xAnterior = vuelo.GetCurrentPosition().GetX();
                    double yAnterior = vuelo.GetCurrentPosition().GetY();
                    double xDestino = vuelo.GetFinalPosition().GetX();
                    double yDestino = vuelo.GetFinalPosition().GetY();

                    if (Math.Abs(xAnterior - xDestino) > 0.01 || Math.Abs(yAnterior - yDestino) > 0.01)
                    {
                        var contacto = ObtenerContactoCompania(vuelo.GetCompany());
                        string cambio = $"El avión {vuelo.GetId()} de {vuelo.GetCompany()} movido al destino: " +
                                       $"({xAnterior:F2}, {yAnterior:F2}) → ({xDestino:F2}, {yDestino:F2}). " +
                                       $"Contacto: Tel: {contacto.telefono}, Email: {contacto.email}";
                        AgregarCambio(cambio);
                    }

                    vuelo.SetPosition(xDestino, yDestino);
                }
            }

            // Guardar estado actual antes de mover al final
            GuardarEstadoActual();

            simulacionTerminada = true;
            ActualizarIconos();
            miPanel.Invalidate();

            // Registrar finalización
            AgregarCambio($"Simulación finalizada manualmente. Todos los aviones en destino.");

            MessageBox.Show("Simulación finalizada. Usa 'Deshacer' para volver atrás.",
                          "Finalizado",
                          MessageBoxButtons.OK,
                          MessageBoxIcon.Information);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!inicio || final)
            {
                timer1.Enabled = false;
                return;
            }
            else
            {
                timer1.Interval = 1000;

                try
                {
                    miLista.Mover(tiempoCiclo);
                    GuardarEstadoActual();
                    ActualizarIconos();
                    VerificarConflictoTiempoReal();
                    miPanel.Invalidate();

                    if (miLista.hanLlegadoTodos())
                    {
                        inicio = false;
                        final = true;
                        timer1.Enabled = false;
                        simulacionTerminada = true;

                        // Registrar llegada de todos los aviones
                        AgregarCambio($"Simulación automática completada. Todos los aviones han llegado a destino.");

                        MessageBox.Show("Todos los aviones han llegado a su destino. Usa 'Deshacer' para volver atrás.",
                                      "Simulación completada",
                                      MessageBoxButtons.OK,
                                      MessageBoxIcon.Information);
                    }
                }
                catch (Exception)
                {
                    timer1.Enabled = false;
                    MessageBox.Show("Error durante la simulación automática.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void ActualizarIconos()
        {
            if (miLista == null) return;

            int numVuelos = miLista.GetNum();
            if (numVuelos == 0) return;

            if (iconosAviones.Count != numVuelos)
            {
                InicializarIconos();
                return;
            }

            for (int i = 0; i < numVuelos; i++)
            {
                if (i < iconosAviones.Count)
                {
                    try
                    {
                        FlightPlan vuelo = miLista.GetFlightPlan(i);
                        if (vuelo != null)
                        {
                            // Cambiar color si llegó a destino
                            if (vuelo.HasArrived())
                            {
                                iconosAviones[i].BackColor = Color.Gray;
                            }
                            else
                            {
                                int x = Convert.ToInt32(vuelo.GetCurrentPosition().GetX());
                                int y = Convert.ToInt32(vuelo.GetCurrentPosition().GetY());
                                iconosAviones[i].Location = new Point(x, y);
                                iconosAviones[i].BackColor = Color.LightGreen;
                            }
                        }
                    }
                    catch (Exception)
                    {
                        // Si hay error, no mover este icono
                    }
                }
            }
        }

        private void MostrarDatosActuales_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            DatosActuales datosActuales = new DatosActuales(miLista);
            datosActuales.PonerDatos();
            datosActuales.ShowDialog();

            if (inicio && !final)
            {
                timer1.Enabled = true;
            }
        }

        private void VerificarConflictoTiempoReal()
        {
            int n = miLista.GetNum();
            if (n < 2)
            {
                vuelosEnConflicto.Clear();
                RestaurarColoresNormales();
                return;
            }

            conflictoActivo = false;
            vuelosEnConflicto.Clear();
            RestaurarColoresNormales();

            for (int i = 0; i < n; i++)
            {
                FlightPlan vueloA = miLista.GetFlightPlan(i);

                for (int j = i + 1; j < n; j++)
                {
                    FlightPlan vueloB = miLista.GetFlightPlan(j);
                    double distanciaCentros = vueloA.Distancia(
                        vueloB.GetCurrentPosition().GetX(),
                        vueloB.GetCurrentPosition().GetY()
                    );

                    if (distanciaCentros < 2 * distanciaSeguridad)
                    {
                        conflictoActivo = true;

                        // Registrar el conflicto
                        RegistrarConflictoDetectado(vueloA, vueloB, distanciaCentros);

                        if (!vuelosEnConflicto.Contains(i))
                            vuelosEnConflicto.Add(i);
                        if (!vuelosEnConflicto.Contains(j))
                            vuelosEnConflicto.Add(j);

                        if (i < iconosAviones.Count)
                            iconosAviones[i].BackColor = Color.Red;
                        if (j < iconosAviones.Count)
                            iconosAviones[j].BackColor = Color.Red;
                    }
                }
            }
        }

        private void RestaurarColoresNormales()
        {
            for (int i = 0; i < iconosAviones.Count; i++)
            {
                FlightPlan vuelo = miLista.GetFlightPlan(i);
                if (vuelo != null && vuelo.HasArrived())
                {
                    iconosAviones[i].BackColor = Color.Gray;
                }
                else
                {
                    iconosAviones[i].BackColor = Color.LightGreen;
                }
            }
        }

        public void SetVelocidad(FlightPlan plan, double v)
        {
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                if (plan.GetId() == miLista.GetFlightPlan(i).GetId())
                {
                    double velocidadAnterior = miLista.GetFlightPlan(i).GetVelocidad();
                    miLista.GetFlightPlan(i).SetVelocidad(v);

                    // Registrar cambio de velocidad
                    if (Math.Abs(velocidadAnterior - v) > 0.01)
                    {
                        var contacto = ObtenerContactoCompania(plan.GetCompany());
                        string cambio = $"Velocidad cambiada para {plan.GetId()} ({plan.GetCompany()}): " +
                                       $"{velocidadAnterior:F2} → {v:F2}. " +
                                       $"Contacto: Tel: {contacto.telefono}, Email: {contacto.email}";
                        AgregarCambio(cambio);
                    }

                    break;
                }
            }
        }

        private void btnCambiarVelocidadesDeLosVuelos_Click(object sender, EventArgs e)
        {
            CambiarVelocidades Cambiar = new CambiarVelocidades(miLista);
            Cambiar.ShowDialog();

            FlightPlanList velocidadescambiadas = Cambiar.cambioVelocidad;
            for (int i = 0; i < velocidadescambiadas.GetNum(); i++)
            {
                var vueloOriginal = miLista.GetFlightPlan(i);
                var vueloModificado = velocidadescambiadas.GetFlightPlan(i);

                if (vueloModificado.GetId() == vueloOriginal.GetId())
                {
                    double velocidadAnterior = vueloOriginal.GetVelocidad();
                    double velocidadNueva = vueloModificado.GetVelocidad();

                    if (Math.Abs(velocidadAnterior - velocidadNueva) > 0.01)
                    {
                        miLista.GetFlightPlan(i).SetVelocidad(velocidadNueva);

                        // Registrar el cambio
                        var contacto = ObtenerContactoCompania(vueloOriginal.GetCompany());
                        string cambio = $"El avión {vueloOriginal.GetId()} de {vueloOriginal.GetCompany()} " +
                                      $"cambió velocidad de {velocidadAnterior:F2} a {velocidadNueva:F2}. " +
                                      $"Contacto: Tel: {contacto.telefono}, Email: {contacto.email}";
                        AgregarCambio(cambio);
                    }
                }
            }
        }

        private void btnReiniciar_Click(object sender, EventArgs e)
        {
            if (miLista == null || miLista.GetNum() == 0) return;

            // Preguntar confirmación antes de reiniciar
            DialogResult resultado = MessageBox.Show(
                "¿Está seguro de que desea reiniciar la simulación?\n\n" +
                "Todos los aviones volverán a sus posiciones iniciales y se perderá el progreso actual.",
                "Confirmar reinicio",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (resultado != DialogResult.Yes)
                return;

            // Registrar reinicio
            AgregarCambio("Simulación reiniciada a posiciones iniciales.");

            for (int i = 0; i < miLista.GetNum(); i++)
            {
                var vuelo = miLista.GetFlightPlan(i);
                double xAnterior = vuelo.GetCurrentPosition().GetX();
                double yAnterior = vuelo.GetCurrentPosition().GetY();
                double xInicial = vuelo.GetInitialPosition().GetX();
                double yInicial = vuelo.GetInitialPosition().GetY();

                if (Math.Abs(xAnterior - xInicial) > 0.01 || Math.Abs(yAnterior - yInicial) > 0.01)
                {
                    var contacto = ObtenerContactoCompania(vuelo.GetCompany());
                    string cambio = $"Avión {vuelo.GetId()} ({vuelo.GetCompany()}) reiniciado: " +
                                   $"({xAnterior:F2}, {yAnterior:F2}) → ({xInicial:F2}, {yInicial:F2}). " +
                                   $"Contacto: Tel: {contacto.telefono}, Email: {contacto.email}";
                    AgregarCambio(cambio);
                }

                miLista.GetFlightPlan(i).SetPosition(xInicial, yInicial);
            }

            inicio = false;
            final = false;
            simulacionTerminada = false;
            conflictoActivo = false;
            vuelosEnConflicto.Clear();

            // Limpiar el stack y guardar estado inicial
            posiciones.Clear();
            GuardarEstadoInicial();

            // Restablecer visibilidad de todos
            for (int i = 0; i < vuelosVisibles.Count; i++)
            {
                vuelosVisibles[i] = true;
            }

            ActualizarVisibilidadIconos();
            RestaurarColoresNormales();
            miPanel.Invalidate();

            MessageBox.Show("Simulación reiniciada exitosamente.",
                          "Reinicio completado",
                          MessageBoxButtons.OK,
                          MessageBoxIcon.Information);
        }

        private void deshacerBtn_Click(object sender, EventArgs e)
        {
            if (miLista == null || miLista.GetNum() == 0) return;

            if (posiciones.Count == 0)
            {
                MessageBox.Show("Ya estás en la posición inicial. No se puede deshacer más.");
                return;
            }

            // Preguntar confirmación antes de deshacer
            DialogResult resultado = MessageBox.Show(
                "¿Está seguro de que desea deshacer la última acción?\n\n" +
                "Los aviones volverán a su estado anterior.",
                "Confirmar deshacer",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (resultado != DialogResult.Yes)
                return;

            Point[] estadoAnterior = posiciones.Pop();

            // Registrar los cambios de posición
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                var vuelo = miLista.GetFlightPlan(i);
                double xAnterior = vuelo.GetCurrentPosition().GetX();
                double yAnterior = vuelo.GetCurrentPosition().GetY();

                miLista.GetFlightPlan(i).SetPosition(estadoAnterior[i].X, estadoAnterior[i].Y);

                double xNuevo = vuelo.GetCurrentPosition().GetX();
                double yNuevo = vuelo.GetCurrentPosition().GetY();

                if (Math.Abs(xAnterior - xNuevo) > 0.01 || Math.Abs(yAnterior - yNuevo) > 0.01)
                {
                    var contacto = ObtenerContactoCompania(vuelo.GetCompany());
                    string cambio = $"Acción deshecha para {vuelo.GetId()} ({vuelo.GetCompany()}): " +
                                   $"({xAnterior:F2}, {yAnterior:F2}) → ({xNuevo:F2}, {yNuevo:F2}). " +
                                   $"Contacto: Tel: {contacto.telefono}, Email: {contacto.email}";
                    AgregarCambio(cambio);
                }
            }

            // Si se deshace desde el estado final, reactivar la simulación
            if (simulacionTerminada)
            {
                simulacionTerminada = false;
                inicio = false;
                final = false;
                RestaurarColoresNormales();
            }

            ActualizarIconos();
            VerificarConflictoTiempoReal();
            miPanel.Invalidate();

            if (posiciones.Count == 0)
            {
                MessageBox.Show("Estado inicial restaurado exitosamente.",
                              "Restauración completada",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Acción deshecha exitosamente.",
                              "Deshacer completado",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Information);
            }
        }

        private void mostrarDistanciasTxt_Click(object sender, EventArgs e)
        {
            DistanciasCompletas formDistancias = new DistanciasCompletas(miLista);
            formDistancias.ShowDialog();
        }

        private void mostrarVuelosBtn_Click(object sender, EventArgs e)
        {
            ListaVuelos listaVuelos = new ListaVuelos(miLista);
            listaVuelos.ShowDialog();
        }

        public int numeroArchivosGuardado = 0;

        private void exportarListaBtn_Click(object sender, EventArgs e)
        {
            if (miLista == null || miLista.GetNum() == 0)
            {
                MessageBox.Show("No hay vuelos para exportar.", "Lista vacía", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Ruta dentro de la carpeta del proyecto
            string proyectoPath = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\"));

            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.Filter = "Archivos de texto (*.txt)|*.txt";
            saveDialog.Title = "Guardar lista de vuelos";
            saveDialog.FileName = $"vuelos_{DateTime.Now:yyyyMMdd_HHmmss}.txt";

            // Establecer la ruta inicial en la carpeta del proyecto
            saveDialog.InitialDirectory = proyectoPath;

            if (saveDialog.ShowDialog() == DialogResult.OK)
            {
                // Preguntar confirmación antes de guardar
                DialogResult confirmacion = MessageBox.Show(
                    $"¿Está seguro de que desea guardar la lista de vuelos en:\n{saveDialog.FileName}?\n\n" +
                    $"Se guardarán {miLista.GetNum()} vuelos.",
                    "Confirmar guardado",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (confirmacion != DialogResult.Yes)
                    return;

                try
                {
                    using (StreamWriter archivo = new StreamWriter(saveDialog.FileName))
                    {
                        // Usar CultureInfo.InvariantCulture para asegurar punto como separador decimal
                        System.Globalization.CultureInfo culture = System.Globalization.CultureInfo.InvariantCulture;

                        for (int i = 0; i < miLista.GetNum(); i++)
                        {
                            FlightPlan vuelo = miLista.GetFlightPlan(i);

                            // Formatear números con punto decimal usando CultureInfo.InvariantCulture
                            string linea = string.Format(culture,
                                "{0},{1},{2:F2},{3:F2},{4:F2},{5:F2},{6:F2}",
                                vuelo.GetId(),
                                vuelo.GetCompany(),
                                vuelo.GetCurrentPosition().GetX(),
                                vuelo.GetCurrentPosition().GetY(),
                                vuelo.GetFinalPosition().GetX(),
                                vuelo.GetFinalPosition().GetY(),
                                vuelo.GetVelocidad());

                            archivo.WriteLine(linea);
                        }
                    }

                    // Mostrar ruta relativa al proyecto
                    string rutaRelativa = Path.GetRelativePath(proyectoPath, saveDialog.FileName);

                    // Mostrar mensaje de confirmación con detalles
                    string mensajeConfirmacion = $"✅ Archivo guardado exitosamente\n\n" +
                                                $"📁 Ubicación: {rutaRelativa}\n" +
                                                $"📊 Vuelos guardados: {miLista.GetNum()}\n" +
                                                $"📄 Tipo: Archivo de texto (.txt)\n" +
                                                $"⏰ Fecha: {DateTime.Now:dd/MM/yyyy HH:mm:ss}";

                    MessageBox.Show(mensajeConfirmacion,
                                  "✅ Guardado exitoso",
                                  MessageBoxButtons.OK,
                                  MessageBoxIcon.Information);

                    numeroArchivosGuardado++;

                    // Registrar exportación
                    AgregarCambio($"Lista de vuelos exportada exitosamente a: {rutaRelativa} ({miLista.GetNum()} vuelos)");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"❌ Error al guardar el archivo:\n{ex.Message}",
                                  "Error de guardado",
                                  MessageBoxButtons.OK,
                                  MessageBoxIcon.Error);
                }
            }
        }

        private void btnVerificarConflicto_Click(object sender, EventArgs e)
        {
            // Verificar conflicto manualmente
            VerificarConflictoTiempoReal();

            if (conflictoActivo)
            {
                MessageBox.Show($"Se detectaron {vuelosEnConflicto.Count} aviones en conflicto.",
                              "Conflicto detectado",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Warning);
            }
            else
            {
                MessageBox.Show("No se detectaron conflictos entre los aviones.",
                              "Sin conflictos",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Information);
            }
        }

        // ============================ MÉTODOS PARA FILTRADO REAL ==========

        private void btnFiltrar_Click(object sender, EventArgs e)
        {
            if (miLista == null || miLista.GetNum() == 0) return;

            string buscarID = txtFiltroID.Text.Trim().ToUpper();
            string aerolinea = cmbFiltroAerolinea.SelectedItem?.ToString();
            bool soloConflictos = chkMostrarSoloConflictos.Checked;
            bool soloEnVuelo = chkMostrarSoloEnRuta.Checked;

            // Determinar qué aviones mostrar
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                FlightPlan vuelo = miLista.GetFlightPlan(i);
                if (vuelo == null)
                {
                    if (i < vuelosVisibles.Count)
                        vuelosVisibles[i] = false;
                    continue;
                }

                bool mostrar = true;

                // Filtro por ID
                if (!string.IsNullOrEmpty(buscarID))
                {
                    if (!vuelo.GetId().ToUpper().Contains(buscarID))
                        mostrar = false;
                }

                // Filtro por aerolínea
                if (aerolinea != null && aerolinea != "Todas")
                {
                    if (vuelo.GetCompany() != aerolinea)
                        mostrar = false;
                }

                // Filtro por conflictos
                if (soloConflictos)
                {
                    if (!vuelosEnConflicto.Contains(i))
                        mostrar = false;
                }

                // Filtro por estado
                if (soloEnVuelo)
                {
                    if (vuelo.HasArrived())
                        mostrar = false;
                }

                // Aplicar filtro
                if (i < vuelosVisibles.Count)
                {
                    vuelosVisibles[i] = mostrar;
                }
                else
                {
                    vuelosVisibles.Add(mostrar);
                }
            }

            // Actualizar visibilidad de iconos
            ActualizarVisibilidadIconos();

            // Forzar redibujado (esto ocultará círculos y trayectorias)
            miPanel.Invalidate();
        }

        private void btnLimpiarFiltros_Click(object sender, EventArgs e)
        {
            // Limpiar controles
            txtFiltroID.Clear();
            if (cmbFiltroAerolinea.Items.Count > 0)
                cmbFiltroAerolinea.SelectedIndex = 0;
            chkMostrarSoloConflictos.Checked = false;
            chkMostrarSoloEnRuta.Checked = false;

            // Mostrar todos
            MostrarTodosLosAviones();

            MessageBox.Show("Mostrando todos los vuelos.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void MostrarTodosLosAviones()
        {
            // Hacer todos visibles
            for (int i = 0; i < vuelosVisibles.Count; i++)
            {
                vuelosVisibles[i] = true;
            }

            // Mostrar todos los iconos
            foreach (PictureBox avion in iconosAviones)
            {
                avion.Visible = true;
            }

            // Forzar redibujado
            miPanel.Invalidate();
        }

        private void CargarAerolineas()
        {
            if (miLista == null || miLista.GetNum() == 0) return;

            cmbFiltroAerolinea.Items.Clear();
            cmbFiltroAerolinea.Items.Add("Todas");

            List<string> aerolineas = new List<string>();

            for (int i = 0; i < miLista.GetNum(); i++)
            {
                FlightPlan vuelo = miLista.GetFlightPlan(i);
                if (vuelo != null)
                {
                    string aero = vuelo.GetCompany();
                    if (!string.IsNullOrEmpty(aero) && !aerolineas.Contains(aero))
                        aerolineas.Add(aero);
                }
            }

            aerolineas.Sort();
            foreach (string aero in aerolineas)
                cmbFiltroAerolinea.Items.Add(aero);

            if (cmbFiltroAerolinea.Items.Count > 0)
                cmbFiltroAerolinea.SelectedIndex = 0;
        }

        private void ActualizarVisibilidadIconos()
        {
            if (iconosAviones.Count != vuelosVisibles.Count) return;

            for (int i = 0; i < iconosAviones.Count; i++)
            {
                iconosAviones[i].Visible = vuelosVisibles[i];
            }
        }

        // ============================ MÉTODOS PARA INFORMES ============================

        private void AgregarCambio(string cambio)
        {
            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            cambiosRealizados.Add($"[{timestamp}] {cambio}");
        }

        private (string telefono, string email) ObtenerContactoCompania(string nombreCompania)
        {
            try
            {
                Compañias compania = companyManager.GetCompany(nombreCompania);
                if (compania != null)
                {
                    return (compania.GetTelefono(), compania.GetEmail());
                }
            }
            catch (Exception)
            {
                // Si hay error, devolver valores por defecto
            }

            return ("No disponible", "No disponible");
        }

        private void RegistrarInicioSimulacion()
        {
            if (miLista == null || miLista.GetNum() == 0) return;

            AgregarCambio("=== INICIO DE SIMULACIÓN ===");
            AgregarCambio($"Parámetros: Distancia seguridad={distanciaSeguridad:F2}, Tiempo ciclo={tiempoCiclo}min");
            AgregarCambio($"Número de vuelos: {miLista.GetNum()}");

            // Registrar información de cada vuelo
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                var vuelo = miLista.GetFlightPlan(i);
                if (vuelo != null)
                {
                    var contacto = ObtenerContactoCompania(vuelo.GetCompany());
                    AgregarCambio($"Vuelo {i + 1}: {vuelo.GetId()} ({vuelo.GetCompany()}) - " +
                                 $"Origen: ({vuelo.GetInitialPosition().GetX():F2}, {vuelo.GetInitialPosition().GetY():F2}), " +
                                 $"Destino: ({vuelo.GetFinalPosition().GetX():F2}, {vuelo.GetFinalPosition().GetY():F2}), " +
                                 $"Velocidad: {vuelo.GetVelocidad():F2}, " +
                                 $"Contacto: {contacto.telefono}/{contacto.email}");
                }
            }
        }

        private void RegistrarMovimientoCiclo()
        {
            AgregarCambio($"Movimiento de ciclo ejecutado ({tiempoCiclo} minutos)");
        }

        private void RegistrarInicioAutomatico()
        {
            AgregarCambio("Simulación automática iniciada");
        }

        private void RegistrarConflictoDetectado(FlightPlan vueloA, FlightPlan vueloB, double distancia)
        {
            var contactoA = ObtenerContactoCompania(vueloA.GetCompany());
            var contactoB = ObtenerContactoCompania(vueloB.GetCompany());

            string conflicto = $"CONFLICTO DETECTADO: {vueloA.GetId()} ({vueloA.GetCompany()}) y " +
                             $"{vueloB.GetId()} ({vueloB.GetCompany()}) a distancia {distancia:F2}. " +
                             $"Contactos: {contactoA.telefono}/{contactoA.email} y {contactoB.telefono}/{contactoB.email}";

            AgregarCambio(conflicto);
        }

        // ============================ EVENTO DEL BOTÓN INFORMES ============================

        private void informesBtn_Click(object sender, EventArgs e)
        {
            if (cambiosRealizados.Count == 0)
            {
                MessageBox.Show("No se han realizado cambios en la simulación.", "Sin cambios",
                               MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Ruta dentro de la carpeta del proyecto
            string proyectoPath = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\"));

            // Crear nombre del archivo con la fecha actual
            string nombreArchivo = $"informe_{DateTime.Now:yyyyMMdd_HHmmss}.txt";
            string rutaCompleta = Path.Combine(proyectoPath, nombreArchivo);

            try
            {
                using (StreamWriter archivo = new StreamWriter(rutaCompleta, false, Encoding.UTF8))
                {
                    // Encabezado del informe
                    archivo.WriteLine("=".PadRight(80, '='));
                    archivo.WriteLine($"INFORME DE SIMULACIÓN DE VUELOS");
                    archivo.WriteLine($"Generado: {DateTime.Now:dd/MM/yyyy HH:mm:ss}");
                    archivo.WriteLine($"Archivo: {nombreArchivo}");
                    archivo.WriteLine("=".PadRight(80, '='));
                    archivo.WriteLine();

                    // 1. RESUMEN GENERAL
                    archivo.WriteLine("1. RESUMEN GENERAL");
                    archivo.WriteLine("-".PadRight(50, '-'));
                    archivo.WriteLine($"• Fecha de generación: {DateTime.Now:dd/MM/yyyy HH:mm:ss}");
                    archivo.WriteLine($"• Total de cambios registrados: {cambiosRealizados.Count}");
                    archivo.WriteLine($"• Vuelos en simulación: {miLista.GetNum()}");
                    archivo.WriteLine($"• Distancia de seguridad: {distanciaSeguridad:F2}");
                    archivo.WriteLine($"• Tiempo por ciclo: {tiempoCiclo} minutos");
                    archivo.WriteLine($"• Estado: {(simulacionTerminada ? "TERMINADA" : "EN CURSO")}");
                    archivo.WriteLine();

                    // 2. LISTA DE VUELOS
                    archivo.WriteLine("2. LISTA DE VUELOS");
                    archivo.WriteLine("-".PadRight(50, '-'));
                    for (int i = 0; i < miLista.GetNum(); i++)
                    {
                        var vuelo = miLista.GetFlightPlan(i);
                        if (vuelo != null)
                        {
                            var contacto = ObtenerContactoCompania(vuelo.GetCompany());
                            string estado = vuelo.HasArrived() ? "LLEGADO" : "EN RUTA";

                            archivo.WriteLine($"{i + 1:00}. {vuelo.GetId()} - {vuelo.GetCompany()}");
                            archivo.WriteLine($"   Estado: {estado}");
                            archivo.WriteLine($"   Posición: ({vuelo.GetCurrentPosition().GetX():F2}, {vuelo.GetCurrentPosition().GetY():F2})");
                            archivo.WriteLine($"   Destino: ({vuelo.GetFinalPosition().GetX():F2}, {vuelo.GetFinalPosition().GetY():F2})");
                            archivo.WriteLine($"   Velocidad: {vuelo.GetVelocidad():F2}");
                            archivo.WriteLine($"   Contacto: {contacto.telefono} / {contacto.email}");
                            archivo.WriteLine();
                        }
                    }

                    // 3. HISTORIAL DE CAMBIOS
                    archivo.WriteLine("3. HISTORIAL DE CAMBIOS");
                    archivo.WriteLine("-".PadRight(50, '-'));
                    for (int i = 0; i < cambiosRealizados.Count; i++)
                    {
                        archivo.WriteLine($"{i + 1:000}. {cambiosRealizados[i]}");
                    }
                    archivo.WriteLine();

                    // 4. ESTADÍSTICAS
                    archivo.WriteLine("4. ESTADÍSTICAS");
                    archivo.WriteLine("-".PadRight(50, '-'));

                    // Contar tipos de cambios
                    int cambiosVelocidad = cambiosRealizados.Count(c =>
                        c.Contains("velocidad", StringComparison.OrdinalIgnoreCase) ||
                        c.Contains("cambió velocidad", StringComparison.OrdinalIgnoreCase));

                    int cambiosPosicion = cambiosRealizados.Count(c =>
                        c.Contains("movido", StringComparison.OrdinalIgnoreCase) ||
                        c.Contains("reiniciado", StringComparison.OrdinalIgnoreCase) ||
                        c.Contains("deshecha", StringComparison.OrdinalIgnoreCase) ||
                        (c.Contains("→") && c.Contains("Contacto:")));

                    int conflictos = cambiosRealizados.Count(c =>
                        c.Contains("CONFLICTO", StringComparison.OrdinalIgnoreCase));

                    int otros = cambiosRealizados.Count - cambiosVelocidad - cambiosPosicion - conflictos;

                    archivo.WriteLine($"• Cambios de velocidad: {cambiosVelocidad}");
                    archivo.WriteLine($"• Cambios de posición: {cambiosPosicion}");
                    archivo.WriteLine($"• Conflictos detectados: {conflictos}");
                    archivo.WriteLine($"• Otros eventos: {otros}");
                    archivo.WriteLine($"• Total: {cambiosRealizados.Count}");
                    archivo.WriteLine();

                    // 5. VUELOS LLEGADOS
                    archivo.WriteLine("5. ESTADO DE VUELOS");
                    archivo.WriteLine("-".PadRight(50, '-'));
                    int vuelosLlegados = 0;
                    for (int i = 0; i < miLista.GetNum(); i++)
                    {
                        if (miLista.GetFlightPlan(i).HasArrived())
                            vuelosLlegados++;
                    }
                    archivo.WriteLine($"• Llegados a destino: {vuelosLlegados}/{miLista.GetNum()}");
                    archivo.WriteLine($"• En ruta: {miLista.GetNum() - vuelosLlegados}/{miLista.GetNum()}");
                    archivo.WriteLine($"• Porcentaje completado: {(vuelosLlegados * 100.0 / miLista.GetNum()):F1}%");
                    archivo.WriteLine();

                    // 6. CONTACTOS
                    archivo.WriteLine("6. CONTACTOS DE COMPAÑÍAS");
                    archivo.WriteLine("-".PadRight(50, '-'));
                    var companiasUnicas = new HashSet<string>();
                    for (int i = 0; i < miLista.GetNum(); i++)
                    {
                        companiasUnicas.Add(miLista.GetFlightPlan(i).GetCompany());
                    }

                    foreach (var compania in companiasUnicas)
                    {
                        var contacto = ObtenerContactoCompania(compania);
                        archivo.WriteLine($"• {compania}:");
                        archivo.WriteLine($"  Teléfono: {contacto.telefono}");
                        archivo.WriteLine($"  Email: {contacto.email}");
                    }
                    archivo.WriteLine();

                    // 7. FILTROS ACTIVOS
                    archivo.WriteLine("7. FILTROS APLICADOS");
                    archivo.WriteLine("-".PadRight(50, '-'));
                    string buscarID = txtFiltroID.Text.Trim();
                    string aerolinea = cmbFiltroAerolinea.SelectedItem?.ToString();
                    bool soloConflictos = chkMostrarSoloConflictos.Checked;
                    bool soloEnVuelo = chkMostrarSoloEnRuta.Checked;

                    int visibles = vuelosVisibles.Count(v => v);

                    archivo.WriteLine($"• Buscar por ID: {(string.IsNullOrEmpty(buscarID) ? "NO" : buscarID)}");
                    archivo.WriteLine($"• Aerolínea: {(aerolinea == "Todas" || string.IsNullOrEmpty(aerolinea) ? "TODAS" : aerolinea)}");
                    archivo.WriteLine($"• Solo conflictos: {(soloConflictos ? "SÍ" : "NO")}");
                    archivo.WriteLine($"• Solo en vuelo: {(soloEnVuelo ? "SÍ" : "NO")}");
                    archivo.WriteLine($"• Vuelos visibles: {visibles}/{miLista.GetNum()}");
                    archivo.WriteLine();

                    // Pie del informe
                    archivo.WriteLine("=".PadRight(80, '='));
                    archivo.WriteLine("FIN DEL INFORME");
                    archivo.WriteLine($"Generado automáticamente el {DateTime.Now:dd/MM/yyyy a las HH:mm:ss}");
                    archivo.WriteLine($"Archivo guardado en: {rutaCompleta}");
                    archivo.WriteLine("=".PadRight(80, '='));
                }

                // Mostrar mensaje de confirmación
                string rutaRelativa = Path.GetRelativePath(proyectoPath, rutaCompleta);
                string mensajeConfirmacion = $"✅ INFORME GENERADO\n\n" +
                                            $"📁 Archivo: {nombreArchivo}\n" +
                                            $"📁 Ruta: {rutaRelativa}\n" +
                                            $"📊 Cambios: {cambiosRealizados.Count}\n" +
                                            $"✈️ Vuelos: {miLista.GetNum()}\n" +
                                            $"⏰ Fecha: {DateTime.Now:dd/MM/yyyy HH:mm:ss}";

                MessageBox.Show(mensajeConfirmacion,
                              "✅ Informe generado",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Information);

                // Registrar la generación del informe
                AgregarCambio($"Informe generado: {nombreArchivo} ({cambiosRealizados.Count} cambios, {miLista.GetNum()} vuelos)");

                // Abrir el archivo generado automáticamente
                try
                {
                    System.Diagnostics.Process.Start("notepad.exe", rutaCompleta);
                }
                catch
                {
                    // Si no se puede abrir con notepad, mostrar mensaje
                    MessageBox.Show($"El informe se guardó en:\n{rutaCompleta}\n\nPuedes abrirlo manualmente.",
                                  "Informe guardado",
                                  MessageBoxButtons.OK,
                                  MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"❌ Error al generar el informe:\n{ex.Message}",
                              "Error",
                              MessageBoxButtons.OK,
                              MessageBoxIcon.Error);
            }
        }







        private void FormSimulacion_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Preguntar confirmación antes de cerrar si hay simulación en curso
            if (inicio || !simulacionTerminada)
            {
                DialogResult resultado = MessageBox.Show(
                    "¿Está seguro de que desea cerrar la simulación?\n\n" +
                    "Se perderá el progreso no guardado.",
                    "Confirmar cierre",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (resultado != DialogResult.Yes)
                {
                    e.Cancel = true;
                }
                else
                {
                    // Registrar cierre de simulación
                    AgregarCambio("Simulación cerrada por el usuario.");
                }
            }
        }

        private void btnCambiarTrayectoria_Click(object sender, EventArgs e)
        {
            if (miLista == null || miLista.GetNum() == 0)
            {
                MessageBox.Show("No hay vuelos en la simulación.", "Error",
                               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 1. Pedir ID del vuelo
            using (PedirID formId = new PedirID())
            {
                if (formId.ShowDialog() == DialogResult.OK)
                {
                    string idVuelo = formId.IdVuelo;

                    // 2. Buscar el vuelo
                    FlightPlan vuelo = null;
                    for (int i = 0; i < miLista.GetNum(); i++)
                    {
                        if (miLista.GetFlightPlan(i).GetId() == idVuelo)
                        {
                            vuelo = miLista.GetFlightPlan(i);
                            break;
                        }
                    }

                    if (vuelo == null)
                    {
                        MessageBox.Show($"Vuelo '{idVuelo}' no encontrado.", "Error",
                                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // 3. Mostrar formulario para cambiar destino
                    using (CambiarDestino formDestino = new CambiarDestino(vuelo))
                    {
                        if (formDestino.ShowDialog() == DialogResult.OK)
                        {
                            // 4. Confirmar cambio
                            DialogResult confirmar = MessageBox.Show(
                                $"¿Cambiar destino del vuelo {idVuelo} a ({formDestino.NuevaX:F2}, {formDestino.NuevaY:F2})?",
                                "Confirmar cambio",
                                MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question);

                            if (confirmar == DialogResult.Yes)
                            {
                                // Guardar estado antes de cambiar
                                GuardarEstadoActual();

                                // Cambiar destino
                                vuelo.finalPosition = new Position(formDestino.NuevaX, formDestino.NuevaY);

                                // Actualizar
                                VerificarConflictoTiempoReal();
                                miPanel.Invalidate();

                                MessageBox.Show("Trayectoria actualizada correctamente.", "Éxito",
                                               MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                }
            }
        }
    }
}