﻿namespace InterfazGrafica
{
    partial class Principal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            opcionesToolStripMenuItem = new ToolStripMenuItem();
            cargarListaDeVuelosToolStripMenuItem = new ToolStripMenuItem();
            distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem = new ToolStripMenuItem();
            simulaciónToolStripMenuItem = new ToolStripMenuItem();
            cargarDesdeFicheroToolStripMenuItem = new ToolStripMenuItem();
            informaciónDeFicheroToolStripMenuItem = new ToolStripMenuItem();
            compañiasToolStripMenuItem = new ToolStripMenuItem();
            mostrarTodasLasCompañíasToolStripMenuItem = new ToolStripMenuItem();
            añadirNuevaCompañíaToolStripMenuItem = new ToolStripMenuItem();
            eliminarCompañíaToolStripMenuItem = new ToolStripMenuItem();
            toolStripSeparator1 = new ToolStripSeparator();
            generarInformeDeCambiosToolStripMenuItem = new ToolStripMenuItem();
            mensajeríaToolStripMenuItem = new ToolStripMenuItem();
            funcionalidadesExtraToolStripMenuItem = new ToolStripMenuItem();
            lblTituloCompanias = new Label();
            listBox1 = new ListBox();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(24, 24);
            menuStrip1.Items.AddRange(new ToolStripItem[] { opcionesToolStripMenuItem, compañiasToolStripMenuItem, mensajeríaToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(5, 2, 0, 2);
            menuStrip1.Size = new Size(640, 28);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            menuStrip1.ItemClicked += menuStrip1_ItemClicked;
            // 
            // opcionesToolStripMenuItem
            // 
            opcionesToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { cargarListaDeVuelosToolStripMenuItem, distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem, simulaciónToolStripMenuItem, cargarDesdeFicheroToolStripMenuItem });
            opcionesToolStripMenuItem.Name = "opcionesToolStripMenuItem";
            opcionesToolStripMenuItem.Size = new Size(85, 24);
            opcionesToolStripMenuItem.Text = "Opciones";
            // 
            // cargarListaDeVuelosToolStripMenuItem
            // 
            cargarListaDeVuelosToolStripMenuItem.Name = "cargarListaDeVuelosToolStripMenuItem";
            cargarListaDeVuelosToolStripMenuItem.Size = new Size(370, 26);
            cargarListaDeVuelosToolStripMenuItem.Text = "Cargar lista de vuelos";
            cargarListaDeVuelosToolStripMenuItem.Click += cargarListaDeVuelosToolStripMenuItem_Click;
            // 
            // distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem
            // 
            distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem.Name = "distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem";
            distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem.Size = new Size(370, 26);
            distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem.Text = "Distancia de Seguridad y Tiempo de Ciclo";
            distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem.Click += distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem_Click;
            // 
            // simulaciónToolStripMenuItem
            // 
            simulaciónToolStripMenuItem.Name = "simulaciónToolStripMenuItem";
            simulaciónToolStripMenuItem.Size = new Size(370, 26);
            simulaciónToolStripMenuItem.Text = "Simulación";
            simulaciónToolStripMenuItem.Click += simulaciónToolStripMenuItem_Click;
            // 
            // cargarDesdeFicheroToolStripMenuItem
            // 
            cargarDesdeFicheroToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { informaciónDeFicheroToolStripMenuItem });
            cargarDesdeFicheroToolStripMenuItem.Name = "cargarDesdeFicheroToolStripMenuItem";
            cargarDesdeFicheroToolStripMenuItem.Size = new Size(370, 26);
            cargarDesdeFicheroToolStripMenuItem.Text = "Cargar desde Fichero";
            cargarDesdeFicheroToolStripMenuItem.Click += cargarDesdeFicheroToolStripMenuItem_Click;
            // 
            // informaciónDeFicheroToolStripMenuItem
            // 
            informaciónDeFicheroToolStripMenuItem.Name = "informaciónDeFicheroToolStripMenuItem";
            informaciónDeFicheroToolStripMenuItem.Size = new Size(243, 26);
            informaciónDeFicheroToolStripMenuItem.Text = "Información de fichero";
            informaciónDeFicheroToolStripMenuItem.Click += informaciónDeFicheroToolStripMenuItem_Click;
            // 
            // compañiasToolStripMenuItem
            // 
            compañiasToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { mostrarTodasLasCompañíasToolStripMenuItem, añadirNuevaCompañíaToolStripMenuItem, eliminarCompañíaToolStripMenuItem, toolStripSeparator1, generarInformeDeCambiosToolStripMenuItem });
            compañiasToolStripMenuItem.Name = "compañiasToolStripMenuItem";
            compañiasToolStripMenuItem.Size = new Size(97, 24);
            compañiasToolStripMenuItem.Text = "Compañias";
            // 
            // mostrarTodasLasCompañíasToolStripMenuItem
            // 
            mostrarTodasLasCompañíasToolStripMenuItem.Name = "mostrarTodasLasCompañíasToolStripMenuItem";
            mostrarTodasLasCompañíasToolStripMenuItem.Size = new Size(289, 26);
            mostrarTodasLasCompañíasToolStripMenuItem.Text = "Mostrar Todas Las Compañías";
            mostrarTodasLasCompañíasToolStripMenuItem.Click += mostrarTodasLasCompañíasToolStripMenuItem_Click;
            // 
            // añadirNuevaCompañíaToolStripMenuItem
            // 
            añadirNuevaCompañíaToolStripMenuItem.Name = "añadirNuevaCompañíaToolStripMenuItem";
            añadirNuevaCompañíaToolStripMenuItem.Size = new Size(289, 26);
            añadirNuevaCompañíaToolStripMenuItem.Text = "Añadir nueva compañía";
            añadirNuevaCompañíaToolStripMenuItem.Click += añadirNuevaCompaniaToolStripMenuItem_Click;
            // 
            // eliminarCompañíaToolStripMenuItem
            // 
            eliminarCompañíaToolStripMenuItem.Name = "eliminarCompañíaToolStripMenuItem";
            eliminarCompañíaToolStripMenuItem.Size = new Size(289, 26);
            eliminarCompañíaToolStripMenuItem.Text = "Eliminar compañía";
            eliminarCompañíaToolStripMenuItem.Click += eliminarCompañíaToolStripMenuItem_Click;
            // 
            // toolStripSeparator1
            // 
            toolStripSeparator1.Name = "toolStripSeparator1";
            toolStripSeparator1.Size = new Size(286, 6);
            // 
            // generarInformeDeCambiosToolStripMenuItem
            // 
            generarInformeDeCambiosToolStripMenuItem.Name = "generarInformeDeCambiosToolStripMenuItem";
            generarInformeDeCambiosToolStripMenuItem.Size = new Size(289, 26);
            generarInformeDeCambiosToolStripMenuItem.Text = "Generar informe de cambios";
            generarInformeDeCambiosToolStripMenuItem.Click += generarInformeDeCambiosToolStripMenuItem_Click;
            // 
            // mensajeríaToolStripMenuItem
            // 
            mensajeríaToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { funcionalidadesExtraToolStripMenuItem });
            mensajeríaToolStripMenuItem.Name = "mensajeríaToolStripMenuItem";
            mensajeríaToolStripMenuItem.Size = new Size(108, 24);
            mensajeríaToolStripMenuItem.Text = "Instrucciones";
            // 
            // funcionalidadesExtraToolStripMenuItem
            // 
            funcionalidadesExtraToolStripMenuItem.Name = "funcionalidadesExtraToolStripMenuItem";
            funcionalidadesExtraToolStripMenuItem.Size = new Size(236, 26);
            funcionalidadesExtraToolStripMenuItem.Text = "Funcionalidades extra";
            funcionalidadesExtraToolStripMenuItem.Click += funcionalidadesExtraToolStripMenuItem_Click;
            // 
            // lblTituloCompanias
            // 
            lblTituloCompanias.AutoSize = true;
            lblTituloCompanias.BackColor = Color.Transparent;
            lblTituloCompanias.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTituloCompanias.ForeColor = Color.WhiteSmoke;
            lblTituloCompanias.Location = new Point(29, 45);
            lblTituloCompanias.Name = "lblTituloCompanias";
            lblTituloCompanias.Size = new Size(181, 20);
            lblTituloCompanias.TabIndex = 1;
            lblTituloCompanias.Text = "GESTOR DE COMPAÑÍAS";
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.Location = new Point(29, 86);
            listBox1.Name = "listBox1";
            listBox1.SelectionMode = SelectionMode.MultiExtended;
            listBox1.Size = new Size(280, 124);
            listBox1.TabIndex = 2;
            // 
            // Principal
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SlateGray;
            ClientSize = new Size(640, 360);
            Controls.Add(listBox1);
            Controls.Add(lblTituloCompanias);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Margin = new Padding(2);
            Name = "Principal";
            Text = "Principal";
            Load += Principal_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem opcionesToolStripMenuItem;
        private ToolStripMenuItem cargarListaDeVuelosToolStripMenuItem;
        private ToolStripMenuItem distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem;
        private ToolStripMenuItem simulaciónToolStripMenuItem;
        private ToolStripMenuItem cargarDesdeFicheroToolStripMenuItem;
        private ToolStripMenuItem informaciónDeFicheroToolStripMenuItem;
        private ToolStripMenuItem compañiasToolStripMenuItem;
        private ToolStripMenuItem mostrarTodasLasCompañíasToolStripMenuItem;
        private ToolStripMenuItem añadirNuevaCompañíaToolStripMenuItem;
        private ToolStripMenuItem eliminarCompañíaToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem generarInformeDeCambiosToolStripMenuItem;
        private ToolStripMenuItem mensajeríaToolStripMenuItem;
        private ToolStripMenuItem funcionalidadesExtraToolStripMenuItem;
        private Label lblTituloCompanias;
        private ListBox listBox1;
    }
}
