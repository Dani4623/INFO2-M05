﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AxWMPLib;
using WMPLib;


namespace InterfazGrafica
{
    public partial class VideoExplicacion : Form
    {

        private AxWMPLib.AxWindowsMediaPlayer player;

        public VideoExplicacion()
        {
            InitializeComponent();
            player = new AxWindowsMediaPlayer();

            // MUY IMPORTANTE
            ((ISupportInitialize)player).BeginInit();

            player.Enabled = true;
            player.Dock = DockStyle.Fill;

            ((ISupportInitialize)player).EndInit();

            this.Controls.Add(player);
            
        }

        private void VideoExplicacion_Load(object sender, EventArgs e)
        {
            player.URL = "video.mp4";
            player.Ctlcontrols.play();
        }

        private void reproducirBtn_Click(object sender, EventArgs e)
        {
            player.Ctlcontrols.play();
        }

        private void pausaBtn_Click(object sender, EventArgs e)
        {
            player.Ctlcontrols.pause();
        }
    }
}
