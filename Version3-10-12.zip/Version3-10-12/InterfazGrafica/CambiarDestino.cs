﻿using FlightLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterfazGrafica
{
    public partial class CambiarDestino : Form
    {
        public double NuevaX { get; private set; }
        public double NuevaY { get; private set; }

        private FlightPlan vuelo;
        public CambiarDestino(FlightPlan vuelo)
        {
            InitializeComponent();
            this.vuelo = vuelo;
            this.StartPosition = FormStartPosition.CenterParent;

            // Mostrar datos actuales
            lblVuelo.Text = $"Vuelo: {vuelo.GetId()}";
            lblActualX.Text = $"Destino actual X: {vuelo.GetFinalPosition().GetX():F2}";
            lblActualY.Text = $"Destino actual Y: {vuelo.GetFinalPosition().GetY():F2}";

            // Poner valores actuales como predeterminados
            txtNuevaX.Text = vuelo.GetFinalPosition().GetX().ToString("F2");
            txtNuevaY.Text = vuelo.GetFinalPosition().GetY().ToString("F2");
        }

        private bool ValidarCampos()
        {
            if (!double.TryParse(txtNuevaX.Text, out double x))
            {
                MessageBox.Show("Coordenada X inválida.", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (!double.TryParse(txtNuevaY.Text, out double y))
            {
                MessageBox.Show("Coordenada Y inválida.", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void btnAceptar_Click_1(object sender, EventArgs e)
        {
            if (ValidarCampos())
            {
                NuevaX = double.Parse(txtNuevaX.Text);
                NuevaY = double.Parse(txtNuevaY.Text);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
