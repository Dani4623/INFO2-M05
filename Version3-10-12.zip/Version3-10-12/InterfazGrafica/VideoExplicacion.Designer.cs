﻿namespace InterfazGrafica
{
    partial class VideoExplicacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            reproducirBtn = new Button();
            pausaBtn = new Button();
            panel1 = new Panel();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // reproducirBtn
            // 
            reproducirBtn.BackColor = Color.FromArgb(45, 50, 60);
            reproducirBtn.FlatAppearance.BorderColor = Color.FromArgb(0, 192, 192);
            reproducirBtn.FlatStyle = FlatStyle.Flat;
            reproducirBtn.ForeColor = Color.WhiteSmoke;
            reproducirBtn.Location = new Point(495, 31);
            reproducirBtn.Name = "reproducirBtn";
            reproducirBtn.Size = new Size(176, 66);
            reproducirBtn.TabIndex = 1;
            reproducirBtn.Text = "Reproducir";
            reproducirBtn.UseVisualStyleBackColor = false;
            reproducirBtn.Click += reproducirBtn_Click;
            // 
            // pausaBtn
            // 
            pausaBtn.BackColor = Color.FromArgb(45, 50, 60);
            pausaBtn.FlatAppearance.BorderColor = Color.FromArgb(0, 192, 192);
            pausaBtn.FlatStyle = FlatStyle.Flat;
            pausaBtn.ForeColor = Color.WhiteSmoke;
            pausaBtn.Location = new Point(236, 31);
            pausaBtn.Name = "pausaBtn";
            pausaBtn.Size = new Size(169, 66);
            pausaBtn.TabIndex = 3;
            pausaBtn.Text = "Pausa";
            pausaBtn.UseVisualStyleBackColor = false;
            pausaBtn.Click += pausaBtn_Click;
            // 
            // panel1
            // 
            panel1.Controls.Add(reproducirBtn);
            panel1.Controls.Add(pausaBtn);
            panel1.Location = new Point(2, 583);
            panel1.Name = "panel1";
            panel1.Size = new Size(900, 125);
            panel1.TabIndex = 4;
            // 
            // VideoExplicacion
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(900, 708);
            Controls.Add(panel1);
            Name = "VideoExplicacion";
            Text = "VideoExplicacion";
            Load += VideoExplicacion_Load;
            panel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private Button reproducirBtn;
        private Button pausaBtn;
        private Panel panel1;
        
    }
}