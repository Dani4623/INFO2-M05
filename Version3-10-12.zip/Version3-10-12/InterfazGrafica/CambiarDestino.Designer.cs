﻿namespace InterfazGrafica
{
    partial class CambiarDestino
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblVuelo = new Label();
            lblX = new Label();
            lblActualX = new Label();
            lblActualY = new Label();
            label5 = new Label();
            lblY = new Label();
            txtNuevaX = new TextBox();
            txtNuevaY = new TextBox();
            btnAceptar = new Button();
            btnCancelar = new Button();
            SuspendLayout();
            // 
            // lblVuelo
            // 
            lblVuelo.AutoSize = true;
            lblVuelo.Location = new Point(134, 81);
            lblVuelo.Name = "lblVuelo";
            lblVuelo.Size = new Size(59, 25);
            lblVuelo.TabIndex = 0;
            lblVuelo.Text = "label1";
            // 
            // lblX
            // 
            lblX.AutoSize = true;
            lblX.Location = new Point(415, 180);
            lblX.Name = "lblX";
            lblX.Size = new Size(148, 25);
            lblX.TabIndex = 1;
            lblX.Text = "Nuevo destino X:";
            // 
            // lblActualX
            // 
            lblActualX.AutoSize = true;
            lblActualX.Location = new Point(134, 180);
            lblActualX.Name = "lblActualX";
            lblActualX.Size = new Size(59, 25);
            lblActualX.TabIndex = 2;
            lblActualX.Text = "label3";
            // 
            // lblActualY
            // 
            lblActualY.AutoSize = true;
            lblActualY.Location = new Point(134, 251);
            lblActualY.Name = "lblActualY";
            lblActualY.Size = new Size(59, 25);
            lblActualY.TabIndex = 3;
            lblActualY.Text = "label4";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(134, 332);
            label5.Name = "label5";
            label5.Size = new Size(0, 25);
            label5.TabIndex = 4;
            // 
            // lblY
            // 
            lblY.AutoSize = true;
            lblY.Location = new Point(415, 251);
            lblY.Name = "lblY";
            lblY.Size = new Size(147, 25);
            lblY.TabIndex = 5;
            lblY.Text = "Nuevo destino Y:";
            // 
            // txtNuevaX
            // 
            txtNuevaX.Location = new Point(569, 177);
            txtNuevaX.Name = "txtNuevaX";
            txtNuevaX.Size = new Size(150, 31);
            txtNuevaX.TabIndex = 6;
            // 
            // txtNuevaY
            // 
            txtNuevaY.Location = new Point(569, 248);
            txtNuevaY.Name = "txtNuevaY";
            txtNuevaY.Size = new Size(150, 31);
            txtNuevaY.TabIndex = 7;
            // 
            // btnAceptar
            // 
            btnAceptar.Location = new Point(237, 347);
            btnAceptar.Name = "btnAceptar";
            btnAceptar.Size = new Size(112, 34);
            btnAceptar.TabIndex = 8;
            btnAceptar.Text = "Aceptar";
            btnAceptar.UseVisualStyleBackColor = true;
            btnAceptar.Click += btnAceptar_Click_1;
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(463, 347);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(112, 34);
            btnCancelar.TabIndex = 9;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // CambiarDestino
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCancelar);
            Controls.Add(btnAceptar);
            Controls.Add(txtNuevaY);
            Controls.Add(txtNuevaX);
            Controls.Add(lblY);
            Controls.Add(label5);
            Controls.Add(lblActualY);
            Controls.Add(lblActualX);
            Controls.Add(lblX);
            Controls.Add(lblVuelo);
            Name = "CambiarDestino";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblVuelo;
        private Label lblX;
        private Label lblActualX;
        private Label lblActualY;
        private Label label5;
        private Label lblY;
        private TextBox txtNuevaX;
        private TextBox txtNuevaY;
        private Button btnAceptar;
        private Button btnCancelar;
    }
}