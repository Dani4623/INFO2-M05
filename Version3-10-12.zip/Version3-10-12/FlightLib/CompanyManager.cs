﻿using FlightLib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Drawing;

namespace InterfazGrafica
{
    public class CompanyManager
    {
        private List<Compañias> compañias;
        private string archivo = "companias.txt";  // Archivo para guardar
        BaseDatosCompañia BBDD = new BaseDatosCompañia();
        public CompanyManager()
        {
            compañias = new List<Compañias>();
            CargarCompanias();  // Cargar desde archivo al iniciar
        }

        private void CargarCompanias()
        {
            // Limpiar lista actual
            compañias.Clear();

            // Verificar si existe el archivo
            if (!File.Exists(archivo))
            {
                // Si no existe, crear compañías por defecto
                CrearCompaniasPorDefecto();
                GuardarCompanias();  // Guardar las por defecto
                return;
            }

            try
            {
                // Leer todas las líneas del archivo
                string[] lineas = File.ReadAllLines(archivo);

                foreach (string linea in lineas)
                {
                    // Cada línea: Nombre,Telefono,Email
                    string[] partes = linea.Split(',');

                    if (partes.Length == 3)
                    {
                        string nombre = partes[0];
                        int telefono = Convert.ToInt32(partes[1]);
                        string email = partes[2];
                        byte[] logo = Convert.FromBase64String(partes[3]);
                        Compañias nueva = new Compañias(nombre,telefono,email,logo);
                        compañias.Add(nueva);
                    }
                }
            }
            catch (Exception)
            {
                // Si hay error, crear por defecto
                CrearCompaniasPorDefecto();
            }
        }

        private void CrearCompaniasPorDefecto()
        {
            byte[] imgIberia = BBDD.ImagenToBytes(Image.FromFile("iberia1.jpg"));
            byte[] imgRyanair = BBDD.ImagenToBytes(Image.FromFile("ryanair1.png"));
            byte[] imgVueling = BBDD.ImagenToBytes(Image.FromFile("vueling1.jpg"));
            byte[] imgAirFrance = BBDD.ImagenToBytes(Image.FromFile("airfrance1.png"));
            byte[] imgLufthansa = BBDD.ImagenToBytes(Image.FromFile("lufthansa1.png"));
            byte[] imgBritish = BBDD.ImagenToBytes(Image.FromFile("ba1.png"));
            byte[] imgDelta = BBDD.ImagenToBytes(Image.FromFile("delta1.png"));
            byte[] imgKLM = BBDD.ImagenToBytes(Image.FromFile("klm1.png"));

            
            compañias.Add(new Compañias("Iberia", 912345678, "iberia@example.com", imgIberia));
            compañias.Add(new Compañias("Ryanair", 934567890, "ryanair@example.com", imgRyanair));
            compañias.Add(new Compañias("Vueling", 956789012, "vueling@example.com", imgVueling));
            compañias.Add(new Compañias("Air France", 918765432, "airfrance@example.com", imgAirFrance));
            compañias.Add(new Compañias("Lufthansa",911223344, "lufthansa@example.com", imgLufthansa));
            compañias.Add(new Compañias("British Airways", 900112233, "british@example.com", imgBritish));
            compañias.Add(new Compañias("Delta", 900223344, "delta@example.com", imgDelta));
            compañias.Add(new Compañias("KLM", 900334455, "klm@example.com", imgKLM));
        }

        private void GuardarCompanias()
        {
            try
            {
                List<string> lineas = new List<string>();

                foreach (Compañias c in compañias)
                {
                    // Guardar como: Nombre,Telefono,Email
                    string linea = c.GetNombre() + "," + c.GetTelefono() + "," + c.GetEmail();
                    lineas.Add(linea);
                }

                // Guardar en archivo
                File.WriteAllLines(archivo, lineas);
            }
            catch (Exception)
            {
                // No hacer nada si falla
            }
        }

        public List<Compañias> GetAllCompanies()
        {
            return compañias;
        }

        public Compañias GetCompany(string name)
        {
            foreach (Compañias c in compañias)
            {
                if (c.GetNombre() == name)
                {
                    return c;
                }
            }
            // Si no existe, devolver compañía vacía
            return new Compañias(name, 0, "No registrado",null);
        }

        public void AddCompany(Compañias company)
        {
            compañias.Add(company);
            GuardarCompanias();  // ¡GUARDAR DESPUÉS DE AÑADIR!
        }

        public bool RemoveCompany(string name)
        {
            for (int i = 0; i < compañias.Count; i++)
            {
                if (compañias[i].GetNombre() == name)
                {
                    compañias.RemoveAt(i);
                    GuardarCompanias();  // ¡GUARDAR DESPUÉS DE ELIMINAR!
                    return true;
                }
            }
            return false;
        }
    }
}