﻿using System;
using System.Collections.Generic;
using System.IO;

namespace InterfazGrafica
{
    public class CompanyManager
    {
        private List<Company> companies;
        private string archivo = "companias.txt";  // Archivo para guardar

        public CompanyManager()
        {
            companies = new List<Company>();
            CargarCompanias();  // Cargar desde archivo al iniciar
        }

        private void CargarCompanias()
        {
            // Limpiar lista actual
            companies.Clear();

            // Verificar si existe el archivo
            if (!File.Exists(archivo))
            {
                // Si no existe, crear compañías por defecto
                CrearCompaniasPorDefecto();
                GuardarCompanias();  // Guardar las por defecto
                return;
            }

            try
            {
                // Leer todas las líneas del archivo
                string[] lineas = File.ReadAllLines(archivo);

                foreach (string linea in lineas)
                {
                    // Cada línea: Nombre,Telefono,Email
                    string[] partes = linea.Split(',');

                    if (partes.Length == 3)
                    {
                        Company nueva = new Company();
                        nueva.Name = partes[0];
                        nueva.Telephone = partes[1];
                        nueva.Email = partes[2];

                        companies.Add(nueva);
                    }
                }
            }
            catch (Exception)
            {
                // Si hay error, crear por defecto
                CrearCompaniasPorDefecto();
            }
        }

        private void CrearCompaniasPorDefecto()
        {
            companies.Add(new Company("Iberia", "912345678", "iberia@example.com"));
            companies.Add(new Company("Ryanair", "934567890", "ryanair@example.com"));
            companies.Add(new Company("Vueling", "956789012", "vueling@example.com"));
            companies.Add(new Company("Air France", "918765432", "airfrance@example.com"));
            companies.Add(new Company("Lufthansa", "911223344", "lufthansa@example.com"));
        }

        private void GuardarCompanias()
        {
            try
            {
                List<string> lineas = new List<string>();

                foreach (Company c in companies)
                {
                    // Guardar como: Nombre,Telefono,Email
                    string linea = c.Name + "," + c.Telephone + "," + c.Email;
                    lineas.Add(linea);
                }

                // Guardar en archivo
                File.WriteAllLines(archivo, lineas);
            }
            catch (Exception)
            {
                // No hacer nada si falla
            }
        }

        public List<Company> GetAllCompanies()
        {
            return companies;
        }

        public Company GetCompany(string name)
        {
            foreach (Company c in companies)
            {
                if (c.Name == name)
                {
                    return c;
                }
            }
            // Si no existe, devolver compañía vacía
            return new Company(name, "No registrado", "No registrado");
        }

        public void AddCompany(Company company)
        {
            companies.Add(company);
            GuardarCompanias();  // ¡GUARDAR DESPUÉS DE AÑADIR!
        }

        public bool RemoveCompany(string name)
        {
            for (int i = 0; i < companies.Count; i++)
            {
                if (companies[i].Name == name)
                {
                    companies.RemoveAt(i);
                    GuardarCompanias();  // ¡GUARDAR DESPUÉS DE ELIMINAR!
                    return true;
                }
            }
            return false;
        }
    }
}