﻿namespace InterfazGrafica
{
    partial class Distancia2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtDistancia = new TextBox();
            btnAceptar = new Button();
            txtCiclo = new TextBox();
            label2 = new Label();
            btnEjemplo = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Location = new Point(68, 39);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(204, 25);
            label1.TabIndex = 0;
            label1.Text = "Distancia de Seguridad";
            // 
            // txtDistancia
            // 
            txtDistancia.Location = new Point(91, 121);
            txtDistancia.Margin = new Padding(4);
            txtDistancia.Name = "txtDistancia";
            txtDistancia.Size = new Size(155, 31);
            txtDistancia.TabIndex = 1;
            // 
            // btnAceptar
            // 
            btnAceptar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAceptar.Location = new Point(254, 249);
            btnAceptar.Margin = new Padding(4);
            btnAceptar.Name = "btnAceptar";
            btnAceptar.Size = new Size(118, 36);
            btnAceptar.TabIndex = 2;
            btnAceptar.Text = "Aceptar";
            btnAceptar.UseVisualStyleBackColor = true;
            btnAceptar.Click += btnAceptar_Click;
            // 
            // txtCiclo
            // 
            txtCiclo.Location = new Point(381, 121);
            txtCiclo.Margin = new Padding(4);
            txtCiclo.Name = "txtCiclo";
            txtCiclo.Size = new Size(155, 31);
            txtCiclo.TabIndex = 3;
            // 
            // label2
            // 
            label2.Location = new Point(391, 39);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(204, 25);
            label2.TabIndex = 4;
            label2.Text = "Tiempo de Ciclo";
            // 
            // btnEjemplo
            // 
            btnEjemplo.Location = new Point(217, 202);
            btnEjemplo.Name = "btnEjemplo";
            btnEjemplo.Size = new Size(194, 40);
            btnEjemplo.TabIndex = 5;
            btnEjemplo.Text = "Datos de Ejemplo";
            btnEjemplo.UseVisualStyleBackColor = true;
            btnEjemplo.Click += btnEjemplo_Click;
            // 
            // Distancia2
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(654, 316);
            Controls.Add(btnEjemplo);
            Controls.Add(label2);
            Controls.Add(txtCiclo);
            Controls.Add(btnAceptar);
            Controls.Add(txtDistancia);
            Controls.Add(label1);
            Margin = new Padding(4);
            Name = "Distancia2";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtDistancia;
        private Button btnAceptar;
        private TextBox txtCiclo;
        private Label label2;
        private Button btnEjemplo;
    }
}