﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterfazGrafica
{
    public partial class AddCompa : Form
    {


        public string NombreCompania = "";
        public string TelefonoCompania = "";
        public string EmailCompania = "";

        public AddCompa()
        {
            InitializeComponent();
        }


        private void AddCompa_Load(object sender, EventArgs e)
        {

        }

        private void Guardar_Click(object sender, EventArgs e)
        {
            NombreCompania = txtNombre.Text;
            TelefonoCompania = txtTelefono.Text;
            EmailCompania = txtEmail.Text;
            this.Close();
        }

        private void Cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
