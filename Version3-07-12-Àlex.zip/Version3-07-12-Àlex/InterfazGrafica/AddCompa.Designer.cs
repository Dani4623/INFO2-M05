﻿
namespace InterfazGrafica
{
    partial class AddCompa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guardar = new Button();
            Cancelar = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtNombre = new TextBox();
            txtTelefono = new TextBox();
            txtEmail = new TextBox();
            SuspendLayout();
            // 
            // Guardar
            // 
            Guardar.Location = new Point(182, 322);
            Guardar.Name = "Guardar";
            Guardar.Size = new Size(150, 46);
            Guardar.TabIndex = 0;
            Guardar.Text = "Guardar";
            Guardar.UseVisualStyleBackColor = true;
            Guardar.Click += Guardar_Click;
            // 
            // Cancelar
            // 
            Cancelar.Location = new Point(435, 320);
            Cancelar.Name = "Cancelar";
            Cancelar.Size = new Size(132, 51);
            Cancelar.TabIndex = 1;
            Cancelar.Text = "Cancelar";
            Cancelar.UseVisualStyleBackColor = true;
            Cancelar.Click += Cancelar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(82, 86);
            label1.Name = "label1";
            label1.Size = new Size(102, 32);
            label1.TabIndex = 2;
            label1.Text = "Nombre";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(343, 86);
            label2.Name = "label2";
            label2.Size = new Size(107, 32);
            label2.TabIndex = 3;
            label2.Text = "Teléfono";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(624, 86);
            label3.Name = "label3";
            label3.Size = new Size(71, 32);
            label3.TabIndex = 4;
            label3.Text = "Email";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(33, 191);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(200, 39);
            txtNombre.TabIndex = 5;
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(323, 191);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(200, 39);
            txtTelefono.TabIndex = 6;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(588, 191);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(200, 39);
            txtEmail.TabIndex = 7;
            // 
            // AddCompa
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtEmail);
            Controls.Add(txtTelefono);
            Controls.Add(txtNombre);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(Cancelar);
            Controls.Add(Guardar);
            Name = "AddCompa";
            Text = "Añade Compañia";
            Load += AddCompa_Load;
            ResumeLayout(false);
            PerformLayout();
        }



        #endregion

        private Button Guardar;
        private Button Cancelar;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtNombre;
        private TextBox txtTelefono;
        private TextBox txtEmail;
    }
}