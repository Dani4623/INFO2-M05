﻿using FlightLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace InterfazGrafica
{
    public partial class FormSimulacion : Form
    {
        private bool conflictoActivo = false;
        private FlightPlanList miLista;
        private List<int> vuelosEnConflicto = new List<int>();
        int tiempoCiclo;
        private List<PictureBox> iconosAviones = new List<PictureBox>();
        private Stack<Point[]> posiciones = new Stack<Point[]>(); 
        bool tienenEstadoAnterior = false;
        private bool simulacionTerminada = false; 

        private double distanciaSeguridad;
        private int diametroSeguridad;
        private bool mensajeListaVaciaMostrado = false;

        public void SetPlanes(FlightPlanList lista)
        {
            miLista = lista;
        }

        public FormSimulacion(int tiempo, double distSeguridad)
        {
            InitializeComponent();

            tiempoCiclo = tiempo;
            distanciaSeguridad = distSeguridad;
            diametroSeguridad = Convert.ToInt32((distanciaSeguridad * 2));

            miPanel.Paint += new PaintEventHandler(DibujarLineasRuta);
            miPanel.Paint += new PaintEventHandler(DibujarElementos);
            miPanel.Paint += new PaintEventHandler(DibujarCuadriculaRadar);

            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.miPanel.BackColor = System.Drawing.Color.Black;
            this.miPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.miPanel.ForeColor = System.Drawing.Color.FromArgb(0, 192, 192);
            System.Drawing.Color accentColor = System.Drawing.Color.FromArgb(0, 192, 192);

            this.Inicio.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(0, 192, 192);
            this.Inicio.FlatAppearance.BorderSize = 1;

            System.Drawing.Color buttonBackColor = System.Drawing.Color.FromArgb(45, 50, 60);
            System.Drawing.Color buttonForeColor = System.Drawing.Color.WhiteSmoke;

            System.Windows.Forms.Button[] allButtons = new System.Windows.Forms.Button[]
            {
                this.btnMoverCiclo,
                this.Inicio,
                this.Final,
                this.MostrarDatosActuales,
                this.btnCambiarVelocidadesDeLosVuelos,
                this.btnReiniciar,
                this.deshacerBtn,
                this.btnVerificarConflicto,
                this.mostrarDistanciasTxt,
                this.mostrarVuelosBtn,
                this.exportarListaBtn
            };

            foreach (System.Windows.Forms.Button btn in allButtons)
            {
                btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
                btn.BackColor = buttonBackColor;
                btn.ForeColor = buttonForeColor;
                btn.FlatAppearance.BorderColor = accentColor;
                btn.FlatAppearance.BorderSize = 1;
            }

            this.BackColor = System.Drawing.Color.WhiteSmoke;
        }

        private void DibujarCuadriculaRadar(object sender, PaintEventArgs e)
        {
            Color gridColor = Color.FromArgb(20, 0, 192, 192);
            using (Pen gridPen = new Pen(gridColor, 1))
            {
                int panelWidth = miPanel.Width;
                int panelHeight = miPanel.Height;
                const int step = 50;

                for (int x = 0; x < panelWidth; x += step)
                {
                    e.Graphics.DrawLine(gridPen, x, 0, x, panelHeight);
                }

                for (int y = 0; y < panelHeight; y += step)
                {
                    e.Graphics.DrawLine(gridPen, 0, y, panelWidth, y);
                }
            }
        }

        private void FormSimulacion_Load(object sender, EventArgs e)
        {
            if (!mensajeListaVaciaMostrado && (miLista == null || miLista.GetNum() == 0))
            {
                MessageBox.Show("No hay vuelos cargados en la simulación.", "Lista vacía", MessageBoxButtons.OK, MessageBoxIcon.Information);
                mensajeListaVaciaMostrado = true;
                return;
            }

            InicializarIconos();
        }

        private void InicializarIconos()
        {
            iconosAviones.Clear();
            miPanel.Controls.Clear();

            if (miLista == null || miLista.GetNum() == 0)
            {
                MessageBox.Show("No hay vuelos para mostrar", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            for (int i = 0; i < miLista.GetNum(); i++)
            {
                try
                {
                    FlightPlan vuelo = miLista.GetFlightPlan(i);
                    if (vuelo == null) continue;

                    PictureBox avion = new PictureBox();
                    avion.Width = 20;
                    avion.Height = 20;
                    avion.BackColor = Color.LightGreen;
                    avion.BorderStyle = BorderStyle.FixedSingle;
                    avion.Tag = i;

                    int x = Convert.ToInt32(vuelo.GetCurrentPosition().GetX());
                    int y = Convert.ToInt32(vuelo.GetCurrentPosition().GetY());

                    // Validar coordenadas
                    x = Math.Max(0, Math.Min(x, miPanel.Width - avion.Width));
                    y = Math.Max(0, Math.Min(y, miPanel.Height - avion.Height));

                    avion.Location = new Point(x, y);

                    System.Windows.Forms.Label lbl = new System.Windows.Forms.Label();
                    lbl.Text = vuelo.GetId() ?? $"Vuelo {i + 1}";
                    lbl.AutoSize = true;
                    lbl.BackColor = Color.Transparent;
                    lbl.ForeColor = Color.White;
                    lbl.Font = new Font("Arial", 8);
                    lbl.Location = new Point(x + 15, y - 15);

                    miPanel.Controls.Add(avion);
                    miPanel.Controls.Add(lbl);
                    iconosAviones.Add(avion);
                    avion.Click += Avion_Click;
                }
                catch (Exception)
                {
                    // Continuar con el siguiente avión si hay error
                }
            }

            GuardarEstadoInicial();
            miPanel.Invalidate();
        }

        private void GuardarEstadoInicial()
        {
            if (miLista == null || miLista.GetNum() == 0) return;

            Point[] estadoInicial = new Point[miLista.GetNum()];
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                FlightPlan vuelo = miLista.GetFlightPlan(i);
                if (vuelo != null)
                {
                    estadoInicial[i] = new Point(
                        Convert.ToInt32(vuelo.GetCurrentPosition().GetX()),
                        Convert.ToInt32(vuelo.GetCurrentPosition().GetY())
                    );
                }
            }

            posiciones.Clear();
            posiciones.Push(estadoInicial);
        }

        private void DibujarLineasRuta(object sender, PaintEventArgs e)
        {
            if (!mensajeListaVaciaMostrado && (miLista == null || miLista.GetNum() == 0))
            {
                return;
            }

            for (int i = 0; i < miLista.GetNum(); i++)
            {
                Point origen = new Point(
                    Convert.ToInt32(miLista.GetFlightPlan(i).GetInitialPosition().GetX()),
                    Convert.ToInt32(miLista.GetFlightPlan(i).GetInitialPosition().GetY())
                );
                Point destino = new Point(
                    Convert.ToInt32(miLista.GetFlightPlan(i).GetFinalPosition().GetX()),
                    Convert.ToInt32(miLista.GetFlightPlan(i).GetFinalPosition().GetY())
                );

                Color colorLinea = Color.FromArgb(0, 192, 192);
                bool enConflicto = vuelosEnConflicto.Contains(i);

                if (enConflicto)
                {
                    colorLinea = Color.Red;
                }

                using (Pen pen = new Pen(colorLinea, 2))
                {
                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                    e.Graphics.DrawLine(pen, origen, destino);
                }
            }
        }

        private void DibujarElementos(object sender, PaintEventArgs e)
        {
            if (!mensajeListaVaciaMostrado && (miLista == null || miLista.GetNum() == 0))
            {
                return;
            }

            for (int i = 0; i < miLista.GetNum(); i++)
            {
                int x = Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetX());
                int y = Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetY());

                Rectangle elipse = new Rectangle(
                    x - Convert.ToInt32(distanciaSeguridad),
                    y - Convert.ToInt32(distanciaSeguridad),
                    diametroSeguridad,
                    diametroSeguridad
                );

                bool enConflicto = vuelosEnConflicto.Contains(i);

                if (enConflicto)
                {
                    using (Brush brush = new SolidBrush(Color.FromArgb(100, 255, 0, 0)))
                    {
                        e.Graphics.FillEllipse(brush, elipse);
                    }

                    using (Pen pen = new Pen(Color.Red, 1))
                    {
                        e.Graphics.DrawEllipse(pen, elipse);
                    }
                }
                else
                {
                    using (Brush brush = new SolidBrush(Color.FromArgb(50, 0, 192, 192)))
                    {
                        e.Graphics.FillEllipse(brush, elipse);
                    }

                    using (Pen pen = new Pen(Color.FromArgb(0, 192, 192), 1))
                    {
                        e.Graphics.DrawEllipse(pen, elipse);
                    }
                }
            }
        }

        private void GuardarEstadoActual()
        {
            if (miLista == null || miLista.GetNum() == 0) return;

            Point[] listaPosiciones = new Point[miLista.GetNum()];
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                FlightPlan vuelo = miLista.GetFlightPlan(i);
                if (vuelo != null)
                {
                    listaPosiciones[i] = new Point(
                        Convert.ToInt32(vuelo.GetCurrentPosition().GetX()),
                        Convert.ToInt32(vuelo.GetCurrentPosition().GetY())
                    );
                }
            }
            posiciones.Push(listaPosiciones);
            tienenEstadoAnterior = true;
        }

        private void btnMoverCiclo_Click(object sender, EventArgs e)
        {
            if (miLista == null || miLista.GetNum() == 0)
            {
                MessageBox.Show("No hay vuelos para mover", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (simulacionTerminada)
            {
                MessageBox.Show("La simulación ya terminó. Usa 'Deshacer' o 'Reiniciar'.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                GuardarEstadoActual();
                miLista.Mover(tiempoCiclo);
                ActualizarIconos();
                VerificarConflictoTiempoReal();
                miPanel.Invalidate();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al mover aviones: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void SetDistanciaSeguridad(double distancia)
        {
            distanciaSeguridad = distancia;
            diametroSeguridad = Convert.ToInt32((distancia * 2));
            miPanel.Invalidate();
        }

        private void Avion_Click(object sender, EventArgs e)
        {
            if (!mensajeListaVaciaMostrado && (miLista == null || miLista.GetNum() == 0))
            {
                MessageBox.Show("No hay vuelos cargados en la simulación.", "Lista vacía", MessageBoxButtons.OK, MessageBoxIcon.Information);
                mensajeListaVaciaMostrado = true;
                return;
            }

            PictureBox pb = (PictureBox)sender;
            int index = Convert.ToInt32(pb.Tag);

            InfoAvion info = new InfoAvion(miLista.GetFlightPlan(index));
            info.Show();
        }

        int i = 0;
        bool inicio = false;
        bool final = false;

        private void Inicio_Click(object sender, EventArgs e)
        {
            if (simulacionTerminada)
            {
                MessageBox.Show("La simulación ya terminó. Usa 'Deshacer' o 'Reiniciar'.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            inicio = true;
            final = false;
            simulacionTerminada = false;
            timer1.Enabled = true;
        }

        private void Final_Click(object sender, EventArgs e)
        {
            if (miLista == null || miLista.GetNum() == 0) return;

            inicio = false;
            final = true;
            timer1.Enabled = false;

            // Guardar estado actual antes de mover al final
            GuardarEstadoActual();

            // Mover cada avión hasta su destino
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                FlightPlan vuelo = miLista.GetFlightPlan(i);
                if (!vuelo.HasArrived())
                {
                    vuelo.SetPosition(
                        vuelo.GetFinalPosition().GetX(),
                        vuelo.GetFinalPosition().GetY()
                    );
                }
            }

            simulacionTerminada = true;
            ActualizarIconos();
            miPanel.Invalidate();

            MessageBox.Show("Simulación finalizada. Usa 'Deshacer' para volver atrás.", "Finalizado", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!inicio || final)
            {
                timer1.Enabled = false;
                return;
            }
            else
            {
                timer1.Interval = 1000;

                try
                {
                    miLista.Mover(tiempoCiclo);
                    GuardarEstadoActual();
                    ActualizarIconos();
                    VerificarConflictoTiempoReal();
                    miPanel.Invalidate();

                    if (miLista.hanLlegadoTodos())
                    {
                        inicio = false;
                        final = true;
                        timer1.Enabled = false;
                        simulacionTerminada = true;

                        MessageBox.Show("Todos los aviones han llegado a su destino. Usa 'Deshacer' para volver atrás.", "Simulación completada", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception)
                {
                    timer1.Enabled = false;
                    MessageBox.Show("Error durante la simulación automática.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void ActualizarIconos()
        {
            if (miLista == null) return;

            int numVuelos = miLista.GetNum();
            if (numVuelos == 0) return;

            if (iconosAviones.Count != numVuelos)
            {
                InicializarIconos();
                return;
            }

            for (int i = 0; i < numVuelos; i++)
            {
                if (i < iconosAviones.Count)
                {
                    try
                    {
                        FlightPlan vuelo = miLista.GetFlightPlan(i);
                        if (vuelo != null)
                        {
                            // Cambiar color si llegó a destino
                            if (vuelo.HasArrived())
                            {
                                iconosAviones[i].BackColor = Color.Gray;
                            }
                            else
                            {
                                int x = Convert.ToInt32(vuelo.GetCurrentPosition().GetX());
                                int y = Convert.ToInt32(vuelo.GetCurrentPosition().GetY());
                                iconosAviones[i].Location = new Point(x, y);
                            }
                        }
                    }
                    catch (Exception)
                    {
                        // Si hay error, no mover este icono
                    }
                }
            }
        }

        private void MostrarDatosActuales_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            DatosActuales datosActuales = new DatosActuales(miLista);
            datosActuales.PonerDatos();
            datosActuales.ShowDialog();

            if (inicio && !final)
            {
                timer1.Enabled = true;
            }
        }

        private void VerificarConflictoTiempoReal()
        {
            int n = miLista.GetNum();
            if (n < 2)
            {
                vuelosEnConflicto.Clear();
                RestaurarColoresNormales();
                return;
            }

            conflictoActivo = false;
            vuelosEnConflicto.Clear();
            RestaurarColoresNormales();

            for (int i = 0; i < n; i++)
            {
                FlightPlan vueloA = miLista.GetFlightPlan(i);

                for (int j = i + 1; j < n; j++)
                {
                    FlightPlan vueloB = miLista.GetFlightPlan(j);
                    double distanciaCentros = vueloA.Distancia(
                        vueloB.GetCurrentPosition().GetX(),
                        vueloB.GetCurrentPosition().GetY()
                    );

                    if (distanciaCentros < 2 * distanciaSeguridad)
                    {
                        conflictoActivo = true;

                        if (!vuelosEnConflicto.Contains(i))
                            vuelosEnConflicto.Add(i);
                        if (!vuelosEnConflicto.Contains(j))
                            vuelosEnConflicto.Add(j);

                        if (i < iconosAviones.Count)
                            iconosAviones[i].BackColor = Color.Red;
                        if (j < iconosAviones.Count)
                            iconosAviones[j].BackColor = Color.Red;
                    }
                }
            }
        }

        private void RestaurarColoresNormales()
        {
            for (int i = 0; i < iconosAviones.Count; i++)
            {
                FlightPlan vuelo = miLista.GetFlightPlan(i);
                if (vuelo != null && vuelo.HasArrived())
                {
                    iconosAviones[i].BackColor = Color.Gray;
                }
                else
                {
                    iconosAviones[i].BackColor = Color.LightGreen;
                }
            }
        }

        public void SetVelocidad(FlightPlan plan, double v)
        {
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                if (plan.GetId() == miLista.GetFlightPlan(i).GetId())
                {
                    miLista.GetFlightPlan(i).SetVelocidad(v);
                    break;
                }
            }
        }

        private void btnCambiarVelocidadesDeLosVuelos_Click(object sender, EventArgs e)
        {
            CambiarVelocidades Cambiar = new CambiarVelocidades(miLista);
            Cambiar.ShowDialog();

            FlightPlanList velocidadescambiadas = Cambiar.cambioVelocidad;
            for (int i = 0; i < velocidadescambiadas.GetNum(); i++)
            {
                if (velocidadescambiadas.GetFlightPlan(i).GetId() == miLista.GetFlightPlan(i).GetId())
                {
                    miLista.GetFlightPlan(i).SetVelocidad(velocidadescambiadas.GetFlightPlan(i).GetVelocidad());
                }
            }
        }

        private void btnReiniciar_Click(object sender, EventArgs e)
        {
            if (miLista == null || miLista.GetNum() == 0) return;

            for (int i = 0; i < miLista.GetNum(); i++)
            {
                miLista.GetFlightPlan(i).SetPosition(
                    miLista.GetFlightPlan(i).GetInitialPosition().GetX(),
                    miLista.GetFlightPlan(i).GetInitialPosition().GetY()
                );
            }

            inicio = false;
            final = false;
            simulacionTerminada = false;
            conflictoActivo = false;
            vuelosEnConflicto.Clear();

            // Limpiar el stack y guardar estado inicial
            posiciones.Clear();
            GuardarEstadoInicial();

            RestaurarColoresNormales();
            miPanel.Invalidate();

            MessageBox.Show("Simulación reiniciada.", "Reinicio", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void deshacerBtn_Click(object sender, EventArgs e)
        {
            if (miLista == null || miLista.GetNum() == 0) return;

            if (posiciones.Count == 0)
            {
                MessageBox.Show("Ya estás en la posición inicial. No se puede deshacer más.");
                return;
            }

            Point[] estadoAnterior = posiciones.Pop();

            for (int i = 0; i < miLista.GetNum(); i++)
            {
                miLista.GetFlightPlan(i).SetPosition(estadoAnterior[i].X, estadoAnterior[i].Y);
            }

            // Si se deshace desde el estado final, reactivar la simulación
            if (simulacionTerminada)
            {
                simulacionTerminada = false;
                inicio = false;
                final = false;
                RestaurarColoresNormales();
            }

            ActualizarIconos();
            VerificarConflictoTiempoReal();
            miPanel.Invalidate();

            if (posiciones.Count == 0)
            {
                MessageBox.Show("Estado inicial restaurado.");
            }
        }

        private void mostrarDistanciasTxt_Click(object sender, EventArgs e)
        {
            DistanciasCompletas formDistancias = new DistanciasCompletas(miLista);
            formDistancias.ShowDialog();
        }

        private void mostrarVuelosBtn_Click(object sender, EventArgs e)
        {
            ListaVuelos listaVuelos = new ListaVuelos(miLista);
            listaVuelos.ShowDialog();
        }

        public int numeroArchivosGuardado = 0;

        private void exportarListaBtn_Click(object sender, EventArgs e)
        {
            // Ruta dentro de la carpeta del proyecto
            string proyectoPath = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\"));

            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.Filter = "Archivos de texto (*.txt)|*.txt";
            saveDialog.Title = "Guardar vuelos";
            saveDialog.FileName = $"vuelos_{DateTime.Now:yyyyMMdd_HHmmss}.txt";

            // Establecer la ruta inicial en la carpeta del proyecto
            saveDialog.InitialDirectory = proyectoPath;

            if (saveDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (StreamWriter archivo = new StreamWriter(saveDialog.FileName))
                    {
                        for (int i = 0; i < miLista.GetNum(); i++)
                        {
                            FlightPlan vuelo = miLista.GetFlightPlan(i);
                            archivo.WriteLine($"{vuelo.GetId()},{vuelo.GetCompany()},{vuelo.GetCurrentPosition().GetX():F2},{vuelo.GetCurrentPosition().GetY():F2},{vuelo.GetFinalPosition().GetX():F2},{vuelo.GetFinalPosition().GetY():F2},{vuelo.GetVelocidad():F2}");
                        }
                    }

                    // Mostrar ruta relativa al proyecto
                    string rutaRelativa = Path.GetRelativePath(proyectoPath, saveDialog.FileName);
                    MessageBox.Show($"Archivo guardado en:\n{rutaRelativa}", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    numeroArchivosGuardado++;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al guardar: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnVerificarConflicto_Click(object sender, EventArgs e) { }
        private void FormSimulacion_FormClosing(object sender, FormClosingEventArgs e) { }
    }
}