﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace InterfazGrafica
{
    public class Company
    {
        public string Name;
        public string Telephone;
        public string Email;

        public Company()
        {
            Name = "";
            Telephone = "";
            Email = "";
        }

        public Company(string name, string telephone, string email)
        {
            Name = name;
            Telephone = telephone;
            Email = email;
        }
    }
}
