﻿using System;
using System.Data;
using System.Data.SQLite;

namespace FlightLib
{
    public class UserDatabase
    {
        SQLiteConnection cnx;

        public UserDatabase()
        {
            string DataSource = "Data Source=usuarios.db";
            cnx = new SQLiteConnection(DataSource);
        }

        private void CrearBaseDatos()
        {
            if (!System.IO.File.Exists("usuarios.db"))
            {
                SQLiteConnection.CreateFile("usuarios.db");
            }
        }

        private void CrearTabla()
        {
            string sql = "CREATE TABLE IF NOT EXISTS usuarios (usuario varchar, contraseña usuario)";
            SQLiteCommand command = new SQLiteCommand(sql, cnx);
            command.ExecuteNonQuery();
        }

        private void IniciarBaseDatos()
        {
            string DataSource = "Data Source=usuarios.db";
            cnx = new SQLiteConnection(DataSource);
            cnx.Open();
        }

        private void CerrarBaseDatos()
        {
            cnx.Close();
        }

        public (bool contraseñaIncorrecta, bool usuarioNoExiste, int num) BuscarUsuarios(string usuario, string contraseña)
        {
            DataTable usuarios = new DataTable();
            string sql = "SELECT * FROM usuarios WHERE usuario = '" + usuario + "'";
            SQLiteDataAdapter adp = new SQLiteDataAdapter(sql, cnx);
            adp.Fill(usuarios);

            int num = usuarios.Rows.Count;
            bool contraseñaIncorrecta = false;
            bool usuarioNoExiste = false;

            if (num == 0)
            {
                usuarioNoExiste = true;
                return (contraseñaIncorrecta, usuarioNoExiste, num);
            }

            string passBD = Convert.ToString(usuarios.Rows[0][1]);
            if (passBD != contraseña)
            {
                contraseñaIncorrecta = true;
                return (contraseñaIncorrecta, usuarioNoExiste, num);
            }

            return (contraseñaIncorrecta, usuarioNoExiste, num);
        }

        public int RegistrarUsuario(string usuario, string contraseña)
        {
            string registro = "INSERT INTO usuarios VALUES ('" + usuario + "','" + contraseña + "')";
            SQLiteCommand command = new SQLiteCommand(registro, cnx);
            int hecho = command.ExecuteNonQuery();
            if (hecho == 1)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

        public void InicializarBD()
        {
            IniciarBaseDatos();
            CrearBaseDatos();
            CrearTabla();
        }

        public void FinalizarBD()
        {
            CerrarBaseDatos();
        }
    }
}