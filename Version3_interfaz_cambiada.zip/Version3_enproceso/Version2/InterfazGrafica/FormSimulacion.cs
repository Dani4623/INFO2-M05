﻿using FlightLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterfazGrafica
{
    public partial class FormSimulacion : Form
    {
        private bool conflictoActivo = false;
        private FlightPlanList miLista;
        private List<int> vuelosEnConflicto = new List<int>();
        int tiempoCiclo;
        private List<PictureBox> iconosAviones = new List<PictureBox>();
        private Stack<Point[]> posiciones = new Stack<Point[]>();
        bool tienenEstadoAnterior = false;

        private double distanciaSeguridad;
        private int diametroSeguridad;
        private bool mensajeListaVaciaMostrado = false;

        public void SetPlanes(FlightPlanList lista)
        {
            miLista = lista;
        }

        public FormSimulacion(int tiempo, double distSeguridad)
        {
            InitializeComponent();

            tiempoCiclo = tiempo;
            distanciaSeguridad = distSeguridad;
            diametroSeguridad = Convert.ToInt32((distanciaSeguridad * 2));

            miPanel.Paint += new PaintEventHandler(DibujarLineasRuta);
            miPanel.Paint += new PaintEventHandler(DibujarElementos);
            miPanel.Paint += new PaintEventHandler(DibujarCuadriculaRadar);

            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.miPanel.BackColor = System.Drawing.Color.Black; // Fondo negro
            this.miPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.miPanel.ForeColor = System.Drawing.Color.FromArgb(0, 192, 192);
            System.Drawing.Color accentColor = System.Drawing.Color.FromArgb(0, 192, 192);
            // Acento y borde
            this.Inicio.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(0, 192, 192); // Cyan brillante
            this.Inicio.FlatAppearance.BorderSize = 1;
          
            System.Drawing.Color buttonBackColor = System.Drawing.Color.FromArgb(45, 50, 60); // Gris Oscuro para el fondo
            System.Drawing.Color buttonForeColor = System.Drawing.Color.WhiteSmoke; // Blanco/Gris Claro para el tex
            System.Windows.Forms.Button[] allButtons = new System.Windows.Forms.Button[]
            {
                this.btnMoverCiclo,
                this.Inicio,
                this.Final,
                this.MostrarDatosActuales,
                this.btnCambiarVelocidadesDeLosVuelos,
                this.btnReiniciar,
                this.deshacerBtn,
                this.btnVerificarConflicto,
                this.mostrarDistanciasTxt,
                this.mostrarVuelosBtn,
                this.exportarListaBtn
            };

            // Aplicar el estilo Flat y el esquema de color a cada botón
            foreach (System.Windows.Forms.Button btn in allButtons)
            {
                btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
                btn.BackColor = buttonBackColor;
                btn.ForeColor = buttonForeColor;
                btn.FlatAppearance.BorderColor = accentColor;
                btn.FlatAppearance.BorderSize = 1;
            }

            // CORRECCIÓN CLAVE: Asegurarse de que el fondo del Formulario sea CLARO
            this.BackColor = System.Drawing.Color.WhiteSmoke;
        }
        private void DibujarCuadriculaRadar(object sender, PaintEventArgs e)
        {
            // Color de las líneas de cuadrícula: Cyan muy tenue (baja opacidad)
            // El valor Alpha (transparencia) 20 asegura que no sea "estridente"
            Color gridColor = Color.FromArgb(20, 0, 192, 192);
            using (Pen gridPen = new Pen(gridColor, 1))
            {
                int panelWidth = miPanel.Width;
                int panelHeight = miPanel.Height;

                // Distancia entre las líneas de la cuadrícula (ej. cada 50 unidades de pantalla)
                const int step = 50;

                // 1. Dibujar líneas verticales
                for (int x = 0; x < panelWidth; x += step)
                {
                    e.Graphics.DrawLine(gridPen, x, 0, x, panelHeight);
                }

                // 2. Dibujar líneas horizontales
                for (int y = 0; y < panelHeight; y += step)
                {
                    e.Graphics.DrawLine(gridPen, 0, y, panelWidth, y);
                }

                // Opcional: Dibujar un recuadro de borde más fuerte (ejemplo, en el centro)
                // Puedes añadir aquí un borde si lo deseas más definido, o dejarlo solo con la cuadrícula sutil.
            }
        }
        private void FormSimulacion_Load(object sender, EventArgs e)
        {
            if (!mensajeListaVaciaMostrado && (miLista == null || miLista.GetNum() == 0))
            {
                MessageBox.Show("No hay vuelos cargados en la simulación.", "Lista vacía", MessageBoxButtons.OK, MessageBoxIcon.Information);
                mensajeListaVaciaMostrado = true;
                return;
            }

            InicializarIconos();
        }

        private void InicializarIconos()
        {
            iconosAviones.Clear();
            miPanel.Controls.Clear();

            for (int i = 0; i < miLista.GetNum(); i++)
            {
                PictureBox avion = new PictureBox();
                avion.Width = 20;
                avion.Height = 20;
                avion.BackColor = System.Drawing.Color.FromArgb(0, 192, 192);
                avion.BorderStyle = BorderStyle.FixedSingle;
                avion.Tag = i;

                int x = Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetX());
                int y = Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetY());
                avion.Location = new Point(x, y);

                System.Windows.Forms.Label lbl = new System.Windows.Forms.Label();
                lbl.Text = miLista.GetFlightPlan(i).GetId().ToString();
                lbl.AutoSize = true;
                lbl.BackColor = Color.Transparent;
                lbl.ForeColor = Color.WhiteSmoke;
                lbl.Font = new Font("Arial", 7);

                lbl.Location = new Point(x + 15, y - 15);

                miPanel.Controls.Add(avion);
                miPanel.Controls.Add(lbl);
                iconosAviones.Add(avion);
                avion.Click += Avion_Click;
            }
            Point[] estadoInicial = new Point[miLista.GetNum()];
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                estadoInicial[i] = new Point(
                    Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetX()),
                    Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetY())
                );
            }
            posiciones.Clear(); 
            posiciones.Push(estadoInicial);
            miPanel.Invalidate();
        }

        private void DibujarLineasRuta(object sender, PaintEventArgs e)
        {
            if (!mensajeListaVaciaMostrado && (miLista == null || miLista.GetNum() == 0))
            {
                MessageBox.Show("No hay vuelos cargados en la simulación.", "Lista vacía", MessageBoxButtons.OK, MessageBoxIcon.Information);
                mensajeListaVaciaMostrado = true;
                return;
            }

            for (int i = 0; i < miLista.GetNum(); i++)
            {
                Point origen = new Point(Convert.ToInt32(miLista.GetFlightPlan(i).GetInitialPosition().GetX()), Convert.ToInt32(miLista.GetFlightPlan(i).GetInitialPosition().GetY()));
                Point destino = new Point(Convert.ToInt32(miLista.GetFlightPlan(i).GetFinalPosition().GetX()), Convert.ToInt32(miLista.GetFlightPlan(i).GetFinalPosition().GetY()));

                Color colorLinea = System.Drawing.Color.FromArgb(0, 192, 192);
                bool enConflicto = false;
                for (int k = 0; k < vuelosEnConflicto.Count; k++)
                {
                    if (vuelosEnConflicto[k] == i)
                    {
                        enConflicto = true;
                        break;
                    }
                }
                if (enConflicto)
                {
                    colorLinea = Color.Red;
                }
                using (Pen pen = new Pen(colorLinea, 2))
                {
                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                    e.Graphics.DrawLine(pen, origen, destino);
                }
            }

        }
        private void DibujarElementos(object sender, PaintEventArgs e)
        {
            if (!mensajeListaVaciaMostrado && (miLista == null || miLista.GetNum() == 0))
            {
                MessageBox.Show("No hay vuelos cargados en la simulación.", "Lista vacía", MessageBoxButtons.OK, MessageBoxIcon.Information);

                mensajeListaVaciaMostrado = true;
                return;
            }
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                int x = Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetX());
                int y = Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetY());

                Rectangle elipse = new Rectangle(x - Convert.ToInt32(distanciaSeguridad), y - Convert.ToInt32(distanciaSeguridad), diametroSeguridad, diametroSeguridad);

                bool enConflicto = false;
                for (int k = 0; k < vuelosEnConflicto.Count; k++)
                {
                    if (vuelosEnConflicto[k] == i)
                    {
                        enConflicto = true;
                        break;
                    }
                }
                if (enConflicto)
                {
                    using (Brush brush = new SolidBrush(Color.FromArgb(100, 255, 0, 0)))
                    {
                        e.Graphics.FillEllipse(brush, elipse);
                    }

                    using (Pen pen = new Pen(Color.Red, 1))
                    {
                        e.Graphics.DrawEllipse(pen, elipse);
                    }
                }
                else
                {
                    using (Brush brush = new SolidBrush(Color.FromArgb(50, 0, 192, 192)))
                    {
                        e.Graphics.FillEllipse(brush, elipse);
                    }
                    using (Pen pen = new Pen(System.Drawing.Color.FromArgb(0, 192, 192), 1))
                    {
                        e.Graphics.DrawEllipse(pen, elipse);
                    }
                }
            }
        }
        private void GuardarEstadoActual()
        {
            Point[] listaPosiciones = new Point[miLista.GetNum()];
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                listaPosiciones[i] = new Point(Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetX()), Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetY()));
            }
            posiciones.Push(listaPosiciones);
            tienenEstadoAnterior = true;
        }

        private void btnMoverCiclo_Click(object sender, EventArgs e)
        {
            if (miLista == null || miLista.GetNum() == 0) return;

          
            GuardarEstadoActual();

            miLista.Mover(tiempoCiclo);

            ActualizarIconos();
            VerificarConflictoTiempoReal();
            miPanel.Invalidate();
        }


        public void SetDistanciaSeguridad(double distancia)
        {
            distanciaSeguridad = distancia;
            diametroSeguridad = Convert.ToInt32((distancia * 2));
            miPanel.Invalidate();
        }



        private void Avion_Click(object sender, EventArgs e)
        {
            if (!mensajeListaVaciaMostrado && (miLista == null || miLista.GetNum() == 0))
            {
                MessageBox.Show("No hay vuelos cargados en la simulación.", "Lista vacía", MessageBoxButtons.OK, MessageBoxIcon.Information);
                mensajeListaVaciaMostrado = true;
                return;
            }
            PictureBox pb = (PictureBox)sender;
            int index = Convert.ToInt32(pb.Tag);

            InfoAvion info = new InfoAvion(miLista.GetFlightPlan(index));
            info.Show();
        }



        int i = 0;
        bool inicio = false;
        bool final = false;

        private void Inicio_Click(object sender, EventArgs e)
        {
            inicio = true;
            final = false;
            i = 0;
            timer1.Enabled = true;
        }


        private void Final_Click(object sender, EventArgs e)
        {
            inicio = false;
            final = true;
            timer1.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!inicio || final)
            {
                timer1.Enabled = false;
                return;
            }
            else
            {
                timer1.Interval = 1000;
                miLista.Mover(tiempoCiclo);
                GuardarEstadoActual();

                ActualizarIconos();

                VerificarConflictoTiempoReal();

                miPanel.Invalidate();

                if (miLista.hanLlegadoTodos())
                {
                    inicio = false;
                    final = true;
                    timer1.Enabled = false;
                }
            }

        }
        private void ActualizarIconos()
        {
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                iconosAviones[i].Location = new Point(Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetX()), Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetY()));
            }
        }

        private void MostrarDatosActuales_Click(object sender, EventArgs e)
        {

            timer1.Enabled = false;

            DatosActuales datosActuales = new DatosActuales(miLista);
            datosActuales.PonerDatos();
            datosActuales.ShowDialog();

            timer1.Enabled = true;

        }
        private void VerificarConflictoTiempoReal()
        {
            int n = miLista.GetNum();
            if (n < 2)
            {
                vuelosEnConflicto.Clear();
                RestaurarColoresNormales();
               
                return;
            }

            conflictoActivo = false;
            List<string> mensajesConflicto = new List<string>();
            vuelosEnConflicto.Clear();
            RestaurarColoresNormales();

            for (int i = 0; i < n; i++)
            {
                FlightPlan vueloA = miLista.GetFlightPlan(i);

                for (int j = i + 1; j < n; j++)
                {
                    FlightPlan vueloB = miLista.GetFlightPlan(j);
                    double distanciaCentros = vueloA.Distancia(vueloB.GetCurrentPosition().GetX(), vueloB.GetCurrentPosition().GetY());

                    if (distanciaCentros < 2 * distanciaSeguridad)
                    {
                        conflictoActivo = true;
                        mensajesConflicto.Add($"⚠️ {vueloA.GetId()} ↔ {vueloB.GetId()} (Distancia: {distanciaCentros:F2})");

                        bool yaExiste1 = false;
                        bool yaExiste2 = false;

                        for (int k = 0; k < vuelosEnConflicto.Count; k++)
                        {
                            if (vuelosEnConflicto[k] == i) yaExiste1 = true;
                            if (vuelosEnConflicto[i] == j) yaExiste2 = true;
                        }

                        if (!yaExiste1) vuelosEnConflicto.Add(i);
                        if (!yaExiste2) vuelosEnConflicto.Add(j);
                        iconosAviones[i].BackColor = Color.Red;
                        iconosAviones[j].BackColor = Color.Red;
                    }
                }
            }


            
        }
        private void RestaurarColoresNormales()
        {
            for (int i = 0; i < iconosAviones.Count; i++)
            {
                iconosAviones[i].BackColor = Color.LightGreen;
            }
        }
        public void SetVelocidad(FlightPlan plan, double v)
        {
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                if (plan.GetId() == miLista.GetFlightPlan(i).GetId())
                {
                    miLista.GetFlightPlan(i).SetVelocidad(v);
                    break;
                }
            }
        }
        private void btnCambiarVelocidadesDeLosVuelos_Click(object sender, EventArgs e)
        {
            FlightPlanList velocidadescambiadas;
            CambiarVelocidades Cambiar = new CambiarVelocidades(miLista);
            Cambiar.ShowDialog();
            velocidadescambiadas = Cambiar.cambioVelocidad;
            for (int i = 0; i < velocidadescambiadas.GetNum(); i++)
            {
                if (velocidadescambiadas.GetFlightPlan(i).GetId() == miLista.GetFlightPlan(i).GetId())
                {
                    miLista.GetFlightPlan(i).SetVelocidad(velocidadescambiadas.GetFlightPlan(i).GetVelocidad());
                }
            }

        }

        private void btnReiniciar_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                miLista.GetFlightPlan(i).SetPosition(miLista.GetFlightPlan(i).GetInitialPosition().GetX(), miLista.GetFlightPlan(i).GetInitialPosition().GetY());
            }

            inicio = false;
            final = false;
            conflictoActivo = false;
            vuelosEnConflicto.Clear();
            RestaurarColoresNormales();
            miPanel.Invalidate();

        }

        private void deshacerBtn_Click(object sender, EventArgs e)
        {
            if (miLista == null || miLista.GetNum() == 0) return;

            if (posiciones.Count == 0)
            {
                MessageBox.Show("Ya estás en la posición inicial. No se puede deshacer más.");
                return;
            }

            Point[] estadoAnterior = posiciones.Pop();

            for (int i = 0; i < miLista.GetNum(); i++)
            {
                miLista.GetFlightPlan(i).SetPosition(estadoAnterior[i].X, estadoAnterior[i].Y);
            }

            ActualizarIconos();
            VerificarConflictoTiempoReal();
            miPanel.Invalidate();
        }

        private void mostrarDistanciasTxt_Click(object sender, EventArgs e)
        {
            DistanciasCompletas formDistancias = new DistanciasCompletas(miLista);
            formDistancias.ShowDialog();
        }

        private void mostrarVuelosBtn_Click(object sender, EventArgs e)
        {
            ListaVuelos listaVuelos = new ListaVuelos(miLista);
            listaVuelos.ShowDialog();
        }
        public int numeroArchivosGuardado = 0;
        private void exportarListaBtn_Click(object sender, EventArgs e)
        {
            string nombreArchivo = $"vuelos{numeroArchivosGuardado}.txt";
            StreamWriter archivo = new StreamWriter(nombreArchivo);
            int num = 0;
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                FlightPlan vuelo = miLista.GetFlightPlan(i);
                string id = vuelo.GetId();
                double posix = vuelo.GetCurrentPosition().GetX();
                double posiy = vuelo.GetCurrentPosition().GetY();
                double posfx = vuelo.GetFinalPosition().GetX();
                double posfy = vuelo.GetFinalPosition().GetY();
                double velocidad = vuelo.GetVelocidad();
                archivo.WriteLine("{0},{1},{2},{3},{4},{5}",id,posix,posiy,posfx,posfy,velocidad);
                num++;
            }
            archivo.Close();
            if (num == miLista.GetNum())
            {
                MessageBox.Show("Archivo guardado con éxito.");
                numeroArchivosGuardado++;
            }
            else
            {
                MessageBox.Show("El archivo no se pudo guardar con éxito.");
            }
        }
    }
}