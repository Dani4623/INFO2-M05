﻿using FlightLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterfazGrafica
{
    public partial class DatosActuales : Form
    {

        private FlightPlanList miLista;
        public DatosActuales(FlightPlanList lista)
        {
            InitializeComponent();
            this.miLista = lista;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(20, 25, 35); // Fondo muy oscuro
            this.dataGridView1.GridColor = System.Drawing.Color.FromArgb(60, 65, 75); // Líneas de cuadrícula sutiles
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.EnableHeadersVisualStyles = false; // ¡Importante para aplicar estilos personalizados!

            // 2. Estilo de Encabezados (Columnas)
            DataGridViewCellStyle headerStyle = new DataGridViewCellStyle();
            headerStyle.BackColor = System.Drawing.Color.FromArgb(45, 50, 60); // Fondo oscuro
            headerStyle.ForeColor = System.Drawing.Color.Cyan; // Texto de acento
            this.dataGridView1.ColumnHeadersDefaultCellStyle = headerStyle;

            // 3. Estilo de Celdas
            DataGridViewCellStyle cellStyle = new DataGridViewCellStyle();
            cellStyle.BackColor = System.Drawing.Color.FromArgb(28, 32, 42); // Fondo de celda
            cellStyle.ForeColor = System.Drawing.Color.WhiteSmoke; // Texto de celda
            this.dataGridView1.DefaultCellStyle = cellStyle;

            // Opcional: AlternatingRowsDefaultCellStyle para mejorar la lectura (Zebra-striping)
            DataGridViewCellStyle altCellStyle = new DataGridViewCellStyle();
            altCellStyle.BackColor = System.Drawing.Color.FromArgb(35, 40, 50); // Ligeramente diferente
            altCellStyle.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = altCellStyle;
        }

        public void PonerDatos()
        {
            dataGridView1.Rows.Clear();
            dataGridView1.ColumnCount = 4;
            dataGridView1.Columns[0].Name = "ID";
            dataGridView1.Columns[1].Name = "Velocidad";
            dataGridView1.Columns[2].Name = "Posición X actual";
            dataGridView1.Columns[3].Name = "Posición Y actual";

            for (int i = 0; i < miLista.GetNum(); i++)
            {
                FlightPlan plan = miLista.GetFlightPlan(i);
                string id = plan.GetId();
                double velocidad = plan.GetVelocidad();
                double px = plan.GetCurrentPosition().GetX();
                double py = plan.GetCurrentPosition().GetY();

                dataGridView1.Rows.Add(id, velocidad, px, py);
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }

            string idSeleccionado = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[0].Value);


            FlightPlan planSeleccionado = null;
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                if (miLista.GetFlightPlan(i).GetId() == idSeleccionado)
                {
                    planSeleccionado = miLista.GetFlightPlan(i);
                    break;
                }
            }

            if (planSeleccionado != null)
            {
                Distancia ventana = new Distancia(planSeleccionado, miLista);
                ventana.ShowDialog();
            }
        }

        private void DatosActuales_Load(object sender, EventArgs e)
        {

        }
    }
}
