﻿using FlightLib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterfazGrafica
{
    public partial class ListaVuelos : Form
    {
        FlightPlanList miLista;
        public ListaVuelos(FlightPlanList lista)
        {
            this.miLista = lista;
            InitializeComponent();
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(20, 25, 35); // Fondo muy oscuro
            this.dataGridView1.GridColor = System.Drawing.Color.FromArgb(60, 65, 75); // Líneas de cuadrícula sutiles
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.EnableHeadersVisualStyles = false; // ¡Esencial para aplicar estilos!

            // 2. Estilo de Encabezados (Columnas)
            // Define un estilo para los encabezados. (Necesitarás crear un DataGridViewCellStyle)
            System.Windows.Forms.DataGridViewCellStyle headerStyle = new System.Windows.Forms.DataGridViewCellStyle();
            headerStyle.BackColor = System.Drawing.Color.FromArgb(45, 50, 60); // Fondo de encabezado
            headerStyle.ForeColor = System.Drawing.Color.Cyan; // Texto de encabezado de acento
            this.dataGridView1.ColumnHeadersDefaultCellStyle = headerStyle;

            // 3. Estilo de Celdas
            // Define un estilo para las celdas de datos.
            System.Windows.Forms.DataGridViewCellStyle cellStyle = new System.Windows.Forms.DataGridViewCellStyle();
            cellStyle.BackColor = System.Drawing.Color.FromArgb(28, 32, 42); // Fondo de celda
            cellStyle.ForeColor = System.Drawing.Color.WhiteSmoke; // Texto de celda
            this.dataGridView1.DefaultCellStyle = cellStyle;
        }
        private void MostrarDatosVuelos()
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();

            dataGridView1.ColumnCount = 6;
            dataGridView1.Columns[0].Name = "ID";
            dataGridView1.Columns[1].Name = "Posicion Inicial X";
            dataGridView1.Columns[2].Name = "Posicion Inicial Y";
            dataGridView1.Columns[3].Name = "Posicion Final X";
            dataGridView1.Columns[4].Name = "Posicion Final Y";
            dataGridView1.Columns[5].Name = "Velocidad";

            for (int i = 0; i<miLista.GetNum(); i++)
            {
                FlightPlan vuelo = miLista.GetFlightPlan(i);
                string id = vuelo.GetId();
                double posix = vuelo.GetInitialPosition().GetX();
                double posiy = vuelo.GetInitialPosition().GetY();
                double posfx = vuelo.GetFinalPosition().GetX();
                double posfy = vuelo.GetFinalPosition().GetY();
                double velocidad = vuelo.GetVelocidad();
                dataGridView1.Rows.Add(id, posix, posiy, posfx, posfy, velocidad);
            }

        }

        private void ListaVuelos_Load(object sender, EventArgs e)
        {
            MostrarDatosVuelos();
        }
    }
}
