﻿using FlightLib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterfazGrafica
{
    public partial class DistanciasCompletas : Form
    {
        private FlightPlanList miLista;
        public DistanciasCompletas(FlightPlanList lista)
        {
            InitializeComponent();
            this.miLista = lista;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(20, 25, 35); // Fondo muy oscuro
            this.dataGridView1.GridColor = System.Drawing.Color.FromArgb(60, 65, 75); // Líneas de cuadrícula sutiles
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.EnableHeadersVisualStyles = false; // ¡Importante para aplicar estilos personalizados!

            // 2. Estilo de Encabezados (Columnas)
            DataGridViewCellStyle headerStyle = new DataGridViewCellStyle();
            headerStyle.BackColor = System.Drawing.Color.FromArgb(45, 50, 60); // Fondo oscuro
            headerStyle.ForeColor = System.Drawing.Color.Cyan; // Texto de acento
            this.dataGridView1.ColumnHeadersDefaultCellStyle = headerStyle;

            // 3. Estilo de Celdas
            DataGridViewCellStyle cellStyle = new DataGridViewCellStyle();
            cellStyle.BackColor = System.Drawing.Color.FromArgb(28, 32, 42); // Fondo de celda
            cellStyle.ForeColor = System.Drawing.Color.WhiteSmoke; // Texto de celda
            this.dataGridView1.DefaultCellStyle = cellStyle;

            // Opcional: AlternatingRowsDefaultCellStyle para mejorar la lectura (Zebra-striping)
            DataGridViewCellStyle altCellStyle = new DataGridViewCellStyle();
            altCellStyle.BackColor = System.Drawing.Color.FromArgb(35, 40, 50); // Ligeramente diferente
            altCellStyle.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = altCellStyle;
        }
        private void MostrarDistancias()
        {
            dataGridView1.Rows.Clear();
            dataGridView1.ColumnCount = miLista.GetNum() + 1;


            dataGridView1.Columns[0].Name = "Vuelo";

            for (int i = 0; i < miLista.GetNum(); i++)
            {
                dataGridView1.Columns[i + 1].Name = miLista.GetFlightPlan(i).GetId();
            }


            for (int i = 0; i < miLista.GetNum(); i++)
            {
                string[] fila = new string[miLista.GetNum() + 1];
                FlightPlan vuelo1 = miLista.GetFlightPlan(i);

                fila[0] = vuelo1.GetId();

                for (int j = 0; j < miLista.GetNum(); j++)
                {
                    if (i == j)
                    {
                        fila[j + 1] = "0";
                    }
                    else
                    {
                        FlightPlan vuelo2 = miLista.GetFlightPlan(j);
                        double distancia = vuelo1.Distancia(
                            vuelo2.GetCurrentPosition().GetX(),
                            vuelo2.GetCurrentPosition().GetY()
                        );
                        fila[j + 1] = $"{distancia:F2}";
                    }
                }

                dataGridView1.Rows.Add(fila);
            }
        }

        private void DistanciasCompletas_Load(object sender, EventArgs e)
        {
            MostrarDistancias();
        }
    }


}
