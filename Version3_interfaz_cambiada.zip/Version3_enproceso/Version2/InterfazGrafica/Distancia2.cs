﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterfazGrafica
{
    public partial class Distancia2 : Form
    {
        public double Distancia1;
        public int Ciclo;
        public Distancia2()
        {
            InitializeComponent();
        }
        public void btnAceptar_Click(object sender, EventArgs e)
        {
            try
            {
                Distancia1 = Convert.ToDouble(txtDistancia.Text);
                Ciclo = Convert.ToInt32(txtCiclo.Text);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch
            {
                MessageBox.Show("Por favor introduce un número válido");
            }
        }

        private void btnEjemplo_Click(object sender, EventArgs e)
        {
            txtDistancia.Text = Convert.ToString(50);
            txtCiclo.Text = Convert.ToString(10);
        }
    }
}
