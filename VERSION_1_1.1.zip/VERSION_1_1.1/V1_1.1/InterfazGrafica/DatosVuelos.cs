﻿using System;
using System.Security.Cryptography.Xml;
using System.Windows.Forms;
using FlightLib;

namespace InterfazGrafica
{
    public partial class DatosVuelos : Form
    {
        public FlightPlan Vuelo1;
        public FlightPlan Vuelo2;

        public DatosVuelos()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            try
            {
                
                string[] pi1 = PIVuelo1.Text.Split(',');
                string[] pf1 = PFVuelo1.Text.Split(',');

                  
                string[] pi2 = PIVuelo2.Text.Split(',');
                string[] pf2 = PFVuelo2.Text.Split(',');

                double pi1_0 = Convert.ToDouble(pi1[0]);
                double pi1_1 = Convert.ToDouble(pi1[1]);
                double pf1_0 = Convert.ToDouble(pf1[0]);
                double pf1_1 = Convert.ToDouble(pf1[1]);
                double pi2_0 = Convert.ToDouble(pi2[0]);
                double pi2_1 = Convert.ToDouble(pi2[1]);
                double pf2_0 = Convert.ToDouble(pf2[0]);
                double pf2_1 = Convert.ToDouble(pf2[1]);

                double v1 = Convert.ToDouble(VelocidadVuelo1.Text);
                double v2 = Convert.ToDouble(VelocidadVuelo2.Text);
                bool correcto = true;
                if (v1 <= 0 || v2 <= 0 || pi1_0 <= 0 || pi1_1 <= 0 || pf1_0 <= 0 || pf1_1 <= 0 || pi2_0 <= 0 
                    || pi2_1 <= 0 || pf2_0 <= 0 || pf2_1 <= 0)
                {
                    
                    correcto = false;
                }

                if (correcto == true)
                {
                    Vuelo1 = new FlightPlan(IDVuelo1.Text, pi1_0, pi1_1, pf1_0, pf1_1, v1);

                    Vuelo2 = new FlightPlan(IDVuelo2.Text, pi2_0, pi2_1, pf2_0, pf2_1, v2);

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("No puede introducir valores nulos ni negativos.");
                }
                
            }
            catch (Exception)
            {
                MessageBox.Show("Error en los datos. Formato correcto: x,y");
            }
        }

        private void DatosVuelos_Load(object sender, EventArgs e)
        {
        }

        private void DatosEjemploBtn_Click(object sender, EventArgs e)
        {
            IDVuelo1.Text = "IB123";
            IDVuelo2.Text = "RYN321";
            VelocidadVuelo1.Text = "100";
            VelocidadVuelo2.Text = "100";
            PIVuelo1.Text = "100,100";
            PFVuelo1.Text = "300,300";
            PIVuelo2.Text = "100,300";
            PFVuelo2.Text = "300,100";
        }
    }
}