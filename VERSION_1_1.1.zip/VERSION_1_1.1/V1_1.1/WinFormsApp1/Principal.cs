namespace WinFormsApp1
using FlightLib;

{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }

        private void insertarVuelosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
