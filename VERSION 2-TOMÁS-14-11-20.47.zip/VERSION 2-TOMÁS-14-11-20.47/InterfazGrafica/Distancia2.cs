﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterfazGrafica
{
    public partial class Distancia2 : Form
    {
        public double DistanciaS;

        public Distancia2()
        {
            InitializeComponent();
        }

        private void Dist2(object sender, EventArgs e)
        {

        }

        public void btnAceptar_Click(object sender, EventArgs e)
        {
            try
            {

                DistanciaS = Convert.ToDouble(txtDistancia.Text);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch
            {
                MessageBox.Show("Por favor introduce un número válido");
            }
        }
    }
}
