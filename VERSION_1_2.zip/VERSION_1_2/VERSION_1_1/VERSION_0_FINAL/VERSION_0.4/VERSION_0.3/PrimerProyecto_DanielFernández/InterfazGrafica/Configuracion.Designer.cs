﻿namespace InterfazGrafica
{
    partial class Configuracion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DistanciaSeguridad = new TextBox();
            TiempoCiclo = new TextBox();
            label1 = new Label();
            label2 = new Label();
            btnAceptar = new Button();
            DatosEjemploBtn = new Button();
            SuspendLayout();
            // 
            // DistanciaSeguridad
            // 
            DistanciaSeguridad.Location = new Point(84, 122);
            DistanciaSeguridad.Margin = new Padding(2);
            DistanciaSeguridad.Name = "DistanciaSeguridad";
            DistanciaSeguridad.Size = new Size(121, 27);
            DistanciaSeguridad.TabIndex = 0;
            // 
            // TiempoCiclo
            // 
            TiempoCiclo.Location = new Point(432, 122);
            TiempoCiclo.Margin = new Padding(2);
            TiempoCiclo.Name = "TiempoCiclo";
            TiempoCiclo.Size = new Size(121, 27);
            TiempoCiclo.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(76, 82);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(161, 20);
            label1.TabIndex = 2;
            label1.Text = "Distancia de seguridad";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(444, 82);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(95, 20);
            label2.TabIndex = 3;
            label2.Text = "Tiempo ciclo";
            // 
            // btnAceptar
            // 
            btnAceptar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAceptar.Location = new Point(274, 206);
            btnAceptar.Margin = new Padding(2);
            btnAceptar.Name = "btnAceptar";
            btnAceptar.Size = new Size(90, 27);
            btnAceptar.TabIndex = 4;
            btnAceptar.Text = "Aceptar";
            btnAceptar.UseVisualStyleBackColor = true;
            btnAceptar.Click += btnAceptar_Click;
            // 
            // DatosEjemploBtn
            // 
            DatosEjemploBtn.Location = new Point(212, 284);
            DatosEjemploBtn.Name = "DatosEjemploBtn";
            DatosEjemploBtn.Size = new Size(221, 29);
            DatosEjemploBtn.TabIndex = 5;
            DatosEjemploBtn.Text = "Datos de ejemplo";
            DatosEjemploBtn.UseVisualStyleBackColor = true;
            DatosEjemploBtn.Click += DatosEjemploBtn_Click;
            // 
            // Configuracion
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(640, 360);
            Controls.Add(DatosEjemploBtn);
            Controls.Add(btnAceptar);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(TiempoCiclo);
            Controls.Add(DistanciaSeguridad);
            Margin = new Padding(2);
            Name = "Configuracion";
            Text = "Configuración";
            Load += Configuracion_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox DistanciaSeguridad;
        private TextBox TiempoCiclo;
        private Label label1;
        private Label label2;
        private Button btnAceptar;
        private Button DatosEjemploBtn;
    }
}