﻿using FlightLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterfazGrafica
{
    public partial class FormSimulacion : Form
    {
        private bool conflictoActivo = false;
        private FlightPlanList miLista;
        int tiempoCiclo;
        private List<PictureBox> iconosAviones = new List<PictureBox>();
        private Stack<Point[]> posiciones = new Stack<Point[]>();
        bool tienenEstadoAnterior = false;

        private double distanciaSeguridad;
        private int diametroSeguridad;
        private bool mensajeListaVaciaMostrado = false;

        public void SetPlanes(FlightPlanList lista)
        {
            miLista = lista;
        }

        public FormSimulacion(int tiempo, double distSeguridad)
        {
            InitializeComponent();

            tiempoCiclo = tiempo;


            distanciaSeguridad = distSeguridad;
            diametroSeguridad = Convert.ToInt32((distanciaSeguridad * 2));


            miPanel.Paint += new PaintEventHandler(DibujarLineasRuta);
            miPanel.Paint += new PaintEventHandler(DibujarElementos);
        }
        private void FormSimulacion_Load(object sender, EventArgs e)
        {
            if (!mensajeListaVaciaMostrado && (miLista == null || miLista.GetNum() == 0))
            {
                MessageBox.Show("No hay vuelos cargados en la simulación.", "Lista vacía", MessageBoxButtons.OK, MessageBoxIcon.Information);

                mensajeListaVaciaMostrado = true;
                return;
            }

            InicializarIconos();

        }

        private void InicializarIconos()
        {
            iconosAviones.Clear();
            miPanel.Controls.Clear();

            for (int i = 0; i < miLista.GetNum(); i++)
            {
                PictureBox avion = new PictureBox();
                avion.Width = 20;
                avion.Height = 20;
                avion.BackColor = Color.LightBlue;
                avion.BorderStyle = BorderStyle.FixedSingle;
                avion.Tag = i;

                int x = Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetX());
                int y = Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetY());
                avion.Location = new Point(x, y);

                System.Windows.Forms.Label lbl = new System.Windows.Forms.Label();
                lbl.Text = miLista.GetFlightPlan(i).GetId().ToString();
                lbl.AutoSize = true;
                lbl.BackColor = Color.Transparent;
                lbl.ForeColor = Color.Black;
                lbl.Font = new Font("Arial", 7);

                lbl.Location = new Point(x, y - 15);

                miPanel.Controls.Add(avion);
                miPanel.Controls.Add(lbl);
                iconosAviones.Add(avion);
                avion.Click += Avion_Click;
            }

            miPanel.Invalidate();
        }

        private void DibujarLineasRuta(object sender, PaintEventArgs e)
        {
            if (!mensajeListaVaciaMostrado && (miLista == null || miLista.GetNum() == 0))
            {
                MessageBox.Show("No hay vuelos cargados en la simulación.", "Lista vacía", MessageBoxButtons.OK, MessageBoxIcon.Information);

                mensajeListaVaciaMostrado = true;
                return;
            }

            for (int i = 0; i < miLista.GetNum(); i++)
            {
                Point origen = new Point(
                    Convert.ToInt32(miLista.GetFlightPlan(i).GetInitialPosition().GetX()), Convert.ToInt32(miLista.GetFlightPlan(i).GetInitialPosition().GetY()));

                Point destino = new Point(Convert.ToInt32(miLista.GetFlightPlan(i).GetFinalPosition().GetX()), Convert.ToInt32(miLista.GetFlightPlan(i).GetFinalPosition().GetY()));

                using (Pen pen = new Pen(Color.FromArgb(255, 128, 128), 2))
                {
                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                    e.Graphics.DrawLine(pen, origen, destino);
                }
            }

        }
        private void DibujarElementos(object sender, PaintEventArgs e)
        {
            if (!mensajeListaVaciaMostrado && (miLista == null || miLista.GetNum() == 0))
            {
                MessageBox.Show("No hay vuelos cargados en la simulación.", "Lista vacía", MessageBoxButtons.OK, MessageBoxIcon.Information);

                mensajeListaVaciaMostrado = true;
                return;
            }
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                int x = Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetX());
                int y = Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetY());

                Rectangle elipse = new Rectangle(x - Convert.ToInt32(distanciaSeguridad), y - Convert.ToInt32(distanciaSeguridad), diametroSeguridad, diametroSeguridad);

                using (Brush brush = new SolidBrush(Color.FromArgb(50, 255, 0, 0)))
                {
                    e.Graphics.FillEllipse(brush, elipse);
                }

                using (Pen pen = new Pen(Color.Red, 1))
                {
                    e.Graphics.DrawEllipse(pen, elipse);
                }
            }
        }
        private void GuardarEstadoActual()
        {
            Point[] listaPosiciones = new Point[miLista.GetNum()];
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                listaPosiciones[i] = new Point(Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetX()), Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetY()));
            }
            posiciones.Push(listaPosiciones);
            tienenEstadoAnterior = true;
        }

        private void btnMoverCiclo_Click(object sender, EventArgs e)
        {
            if (!mensajeListaVaciaMostrado && (miLista == null || miLista.GetNum() == 0))
            {
                MessageBox.Show("No hay vuelos cargados en la simulación.", "Lista vacía", MessageBoxButtons.OK, MessageBoxIcon.Information);

                mensajeListaVaciaMostrado = true;
                return;
            }
            miLista.Mover(tiempoCiclo);

            GuardarEstadoActual();
            

            ActualizarIconos();
            VerificarConflictoTiempoReal();
            miPanel.Invalidate();
        }


        public void SetDistanciaSeguridad(double distancia)
        {
            distanciaSeguridad = distancia;
            diametroSeguridad = Convert.ToInt32((distancia * 2));
            miPanel.Invalidate();
        }


        
        private void Avion_Click(object sender, EventArgs e)
        {
            if (!mensajeListaVaciaMostrado && (miLista == null || miLista.GetNum() == 0))
            {
                MessageBox.Show("No hay vuelos cargados en la simulación.", "Lista vacía", MessageBoxButtons.OK, MessageBoxIcon.Information);

                mensajeListaVaciaMostrado = true;
                return;
            }
            PictureBox pb = (PictureBox)sender;
            int index = Convert.ToInt32(pb.Tag);

            InfoAvion info = new InfoAvion(miLista.GetFlightPlan(index));
            info.Show();
        }



        int i = 0;
        bool inicio = false;
        bool final = false;

        private void Inicio_Click(object sender, EventArgs e)
        {
            inicio = true;
            final = false;
            i = 0;

            timer1.Enabled = true;
        }


        private void Final_Click(object sender, EventArgs e)
        {
            inicio = false;
            final = true;

            timer1.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!inicio || final)
            {
                timer1.Enabled = false;
                return;
            }
            else
            {
                timer1.Interval = 1000;
                miLista.Mover(tiempoCiclo);
                GuardarEstadoActual();
                
                ActualizarIconos();

                VerificarConflictoTiempoReal();

                miPanel.Invalidate();

                if (miLista.hanLlegadoTodos())
                {
                    inicio = false;
                    final = true;
                    timer1.Enabled = false;
                }
            }

        }
        private void ActualizarIconos()
        {
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                iconosAviones[i].Location = new Point( Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetX()),Convert.ToInt32(miLista.GetFlightPlan(i).GetCurrentPosition().GetY()));
            }
        }

        private void MostrarDatosActuales_Click(object sender, EventArgs e)
        {

            timer1.Enabled = false;

            DatosActuales datosActuales = new DatosActuales(miLista);
            datosActuales.PonerDatos();
            datosActuales.ShowDialog();

            timer1.Enabled = true;

        }
        private void VerificarConflictoTiempoReal()
        {
            int n = miLista.GetNum();
            if (n < 2) return;

            conflictoActivo = false;
            List<string> vuelosEnConflicto = new List<string>();

            for (int i = 0; i < n; i++)
            {
                FlightPlan vueloA = miLista.GetFlightPlan(i);

                for (int j = i + 1; j < n; j++)
                {
                    FlightPlan vueloB = miLista.GetFlightPlan(j);
                    double distanciaCentros = vueloA.Distancia(vueloB.GetCurrentPosition().GetX(), vueloB.GetCurrentPosition().GetY());

                    if (distanciaCentros < 2 * distanciaSeguridad)
                    {
                        conflictoActivo = true;
                        vuelosEnConflicto.Add($"⚠️ {vueloA.GetId()} ↔ {vueloB.GetId()} (Distancia: {distanciaCentros:F2})");

                        iconosAviones[i].BackColor = Color.Red;
                        iconosAviones[j].BackColor = Color.Red;
                    }
                }
            }

            
            if (conflictoActivo)
            {
                textBoxConflictos.Text = string.Join("\r\n", vuelosEnConflicto);
            }
            else
            {
                textBoxConflictos.Text = "No hay conflictos.";
                foreach (var avion in iconosAviones)
                    avion.BackColor = Color.LightBlue;
            }
        }

        public void SetVelocidad(FlightPlan plan, double v)
        {
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                if (plan.GetId() == miLista.GetFlightPlan(i).GetId())
                {
                    miLista.GetFlightPlan(i).SetVelocidad(v);
                    break;
                }
            }
        }
        private void btnCambiarVelocidadesDeLosVuelos_Click(object sender, EventArgs e)
        {
            FlightPlanList velocidadescambiadas;
            CambiarVelocidades Cambiar = new CambiarVelocidades(miLista);
            Cambiar.ShowDialog();
            velocidadescambiadas = Cambiar.cambioVelocidad;
            for (int i = 0; i < velocidadescambiadas.GetNum(); i++)
            {
                if (velocidadescambiadas.GetFlightPlan(i).GetId() == miLista.GetFlightPlan(i).GetId())
                {
                    miLista.GetFlightPlan(i).SetVelocidad(velocidadescambiadas.GetFlightPlan(i).GetVelocidad());
                }
            }

        }

        private void btnReiniciar_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < miLista.GetNum(); i++)
            {
                miLista.GetFlightPlan(i).SetPosition(miLista.GetFlightPlan(i).GetInitialPosition().GetX(), miLista.GetFlightPlan(i).GetInitialPosition().GetY());
            }

            inicio = false;
            final = false;
            conflictoActivo = false;

            for (int i = 0; i < miLista.GetNum(); i++)
            {
                iconosAviones[i].BackColor = Color.LightGreen;
            }

            miPanel.Invalidate();

        }

        private void deshacerBtn_Click(object sender, EventArgs e)
        {
            if (tienenEstadoAnterior)
            {
                int num = posiciones.Count;
                Point[] ultimaPosicion = posiciones.Pop();
                for (int i = 0; i < miLista.GetNum(); i++)
                {
                    miLista.GetFlightPlan(i).SetPosition(ultimaPosicion[i].X, ultimaPosicion[i].Y);
                    iconosAviones[i].Location = new Point(ultimaPosicion[i].X, ultimaPosicion[i].Y);
                }

                miPanel.Invalidate();
                MessageBox.Show("Último movimiento deshecho");

            }
            else
            {
                MessageBox.Show("No hay movimientos anteriores para deshacer.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void mostrarDistanciasTxt_Click(object sender, EventArgs e)
        {
            DistanciasCompletas formDistancias = new DistanciasCompletas(miLista);
            formDistancias.ShowDialog();
        }
    }
}