﻿namespace InterfazGrafica
{
    partial class FormSimulacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            miPanel = new Panel();
            Avion2 = new Label();
            Avion1 = new Label();
            btnMoverCiclo = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            Inicio = new Button();
            Final = new Button();
            MostrarDatosActuales = new Button();
            btnVerificarConflicto = new Button();
            btnCambiarVelocidadesDeLosVuelos = new Button();
            btnReiniciar = new Button();
            button1 = new Button();
            MostrarDistancias = new Button();
            miPanel.SuspendLayout();
            SuspendLayout();
            // 
            // miPanel
            // 
            miPanel.BackColor = SystemColors.GradientInactiveCaption;
            miPanel.Controls.Add(Avion2);
            miPanel.Controls.Add(Avion1);
            miPanel.Location = new Point(16, 15);
            miPanel.Name = "miPanel";
            miPanel.Size = new Size(1035, 781);
            miPanel.TabIndex = 0;
            // 
            // Avion2
            // 
            Avion2.AutoSize = true;
            Avion2.BackColor = Color.FromArgb(192, 255, 192);
            Avion2.Location = new Point(361, 257);
            Avion2.Name = "Avion2";
            Avion2.Size = new Size(42, 32);
            Avion2.TabIndex = 1;
            Avion2.Text = "A2";
            Avion2.Click += Avion2_Click;
            // 
            // Avion1
            // 
            Avion1.AutoSize = true;
            Avion1.BackColor = Color.FromArgb(255, 192, 192);
            Avion1.Location = new Point(289, 195);
            Avion1.Name = "Avion1";
            Avion1.Size = new Size(42, 32);
            Avion1.TabIndex = 0;
            Avion1.Text = "A1";
            Avion1.Click += Avion1_Click_1;
            // 
            // btnMoverCiclo
            // 
            btnMoverCiclo.Location = new Point(2071, 15);
            btnMoverCiclo.Name = "btnMoverCiclo";
            btnMoverCiclo.Size = new Size(176, 49);
            btnMoverCiclo.TabIndex = 1;
            btnMoverCiclo.Text = "Mover Ciclo";
            btnMoverCiclo.UseVisualStyleBackColor = true;
            btnMoverCiclo.Click += btnMoverCiclo_Click;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // Inicio
            // 
            Inicio.Location = new Point(2071, 72);
            Inicio.Margin = new Padding(5);
            Inicio.Name = "Inicio";
            Inicio.Size = new Size(176, 113);
            Inicio.TabIndex = 2;
            Inicio.Text = "Empezar simulación automática";
            Inicio.UseVisualStyleBackColor = true;
            Inicio.Click += Inicio_Click;
            // 
            // Final
            // 
            Final.Location = new Point(2071, 197);
            Final.Margin = new Padding(5);
            Final.Name = "Final";
            Final.Size = new Size(176, 113);
            Final.TabIndex = 3;
            Final.Text = "Finalizar simulación automática";
            Final.UseVisualStyleBackColor = true;
            Final.Click += Final_Click;
            // 
            // MostrarDatosActuales
            // 
            MostrarDatosActuales.Location = new Point(2071, 320);
            MostrarDatosActuales.Margin = new Padding(5);
            MostrarDatosActuales.Name = "MostrarDatosActuales";
            MostrarDatosActuales.Size = new Size(176, 109);
            MostrarDatosActuales.TabIndex = 4;
            MostrarDatosActuales.Text = "Mostrar datos actuales";
            MostrarDatosActuales.UseVisualStyleBackColor = true;
            MostrarDatosActuales.Click += MostrarDatosActuales_Click;
            // 
            // btnVerificarConflicto
            // 
            btnVerificarConflicto.Location = new Point(2071, 438);
            btnVerificarConflicto.Margin = new Padding(5);
            btnVerificarConflicto.Name = "btnVerificarConflicto";
            btnVerificarConflicto.Size = new Size(176, 100);
            btnVerificarConflicto.TabIndex = 5;
            btnVerificarConflicto.Text = "Verificar Conflicto";
            btnVerificarConflicto.UseVisualStyleBackColor = true;
            btnVerificarConflicto.Click += btnVerificarConflicto_Click;
            // 
            // btnCambiarVelocidadesDeLosVuelos
            // 
            btnCambiarVelocidadesDeLosVuelos.Location = new Point(2071, 559);
            btnCambiarVelocidadesDeLosVuelos.Margin = new Padding(4);
            btnCambiarVelocidadesDeLosVuelos.Name = "btnCambiarVelocidadesDeLosVuelos";
            btnCambiarVelocidadesDeLosVuelos.Size = new Size(176, 138);
            btnCambiarVelocidadesDeLosVuelos.TabIndex = 6;
            btnCambiarVelocidadesDeLosVuelos.Text = "Cambiar velocidades de los vuelos";
            btnCambiarVelocidadesDeLosVuelos.UseVisualStyleBackColor = true;
            btnCambiarVelocidadesDeLosVuelos.Click += btnCambiarVelocidadesDeLosVuelos_Click;
            // 
            // btnReiniciar
            // 
            btnReiniciar.Location = new Point(2071, 717);
            btnReiniciar.Margin = new Padding(4);
            btnReiniciar.Name = "btnReiniciar";
            btnReiniciar.Size = new Size(176, 44);
            btnReiniciar.TabIndex = 7;
            btnReiniciar.Text = "Reiniciar";
            btnReiniciar.UseVisualStyleBackColor = true;
            btnReiniciar.Click += btnReiniciar_Click;
            // 
            // button1
            // 
            button1.Location = new Point(2071, 786);
            button1.Name = "button1";
            button1.Size = new Size(176, 39);
            button1.TabIndex = 8;
            button1.Text = "Deshacer";
            button1.UseVisualStyleBackColor = true;
            button1.Click += Deshacer_Click;
            // 
            // MostrarDistancias
            // 
            MostrarDistancias.Location = new Point(2071, 845);
            MostrarDistancias.Name = "MostrarDistancias";
            MostrarDistancias.Size = new Size(176, 83);
            MostrarDistancias.TabIndex = 9;
            MostrarDistancias.Text = "Mostrar Distancias";
            MostrarDistancias.UseVisualStyleBackColor = true;
            MostrarDistancias.Click += MostrarDistancias_Click;
            // 
            // FormSimulacion
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(2266, 940);
            Controls.Add(MostrarDistancias);
            Controls.Add(button1);
            Controls.Add(btnReiniciar);
            Controls.Add(btnCambiarVelocidadesDeLosVuelos);
            Controls.Add(btnVerificarConflicto);
            Controls.Add(MostrarDatosActuales);
            Controls.Add(Final);
            Controls.Add(Inicio);
            Controls.Add(btnMoverCiclo);
            Controls.Add(miPanel);
            Name = "FormSimulacion";
            Text = "Simulación";
            Load += FormSimulacion_Load;
            miPanel.ResumeLayout(false);
            miPanel.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel miPanel;
        private Button btnMoverCiclo;
        private Label Avion2;
        private Label Avion1;
        private System.Windows.Forms.Timer timer1;
        private Button Inicio;
        private Button Final;
        private Button MostrarDatosActuales;
        private Button btnVerificarConflicto;
        private Button btnCambiarVelocidadesDeLosVuelos;
        private Button btnReiniciar;
        private Button button1;
        private Button MostrarDistancias;
    }
}