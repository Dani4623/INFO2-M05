﻿
using FlightLib;

namespace InterfazGrafica
{
    partial class DistanciasCompletas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(0, 0);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 82;
            dataGridView1.Size = new Size(480, 300);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellContentClick += this.dataGridView1_CellContentClick;
            // 
            // DistanciasCompletas
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dataGridView1);
            Name = "DistanciasCompletas";
            Text = "DistanciasCompletas";
            Load += DistanciasCompletas_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                // Verificar que el click no fue en el encabezado
                if (e.RowIndex < 0 || e.RowIndex >= dataGridView1.Rows.Count)
                {
                    return;
                }

                // Verificar que la fila tiene datos
                if (dataGridView1.Rows[e.RowIndex].Cells[0].Value == null)
                {
                    return;
                }

                string idSeleccionado = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[0].Value);

                // Buscar el vuelo seleccionado
                FlightPlan planSeleccionado = null;
                for (int i = 0; i < miLista.GetNum(); i++)
                {
                    if (miLista.GetFlightPlan(i).GetId() == idSeleccionado)
                    {
                        planSeleccionado = miLista.GetFlightPlan(i);
                        break;
                    }
                }

                if (planSeleccionado != null)
                {
                    Distancia ventana = new Distancia(planSeleccionado, miLista);
                    ventana.ShowDialog();
                }
                else
                {
                    MessageBox.Show("No se encontró información para el vuelo seleccionado");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al mostrar información: " + ex.Message);
            }
        }

        #endregion

        private DataGridView dataGridView1;
    }
}