﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;
using System.IO;

namespace InterfazGrafica
{
    public partial class InicioSesion : Form
    {
        SQLiteConnection cnx;
        public InicioSesion()
        {
            InitializeComponent();
        }
        private void CrearBaseDatos()
        {
            if (!System.IO.File.Exists("usuarios.db"))
            {
                SQLiteConnection.CreateFile("usuarios.db");
            }
        }
        private void CrearTabla()
        {
            string sql = "CREATE TABLE IF NOT EXISTS usuarios (usuario varchar, contraseña usuario)";
            SQLiteCommand command = new SQLiteCommand(sql, cnx);
            command.ExecuteNonQuery();
        }
        private void IniciarBaseDatos()
        {
            string DataSource = "Data Source=usuarios.db";
            cnx = new SQLiteConnection(DataSource);
            cnx.Open();
        }
        private void CerrarBaseDatos()
        {
            cnx.Close();
        }
        private void InicioSesion_Load(object sender, EventArgs e)
        {
            IniciarBaseDatos();
            CrearBaseDatos();
            CrearTabla();
        }
        public string usuario;
        public string contraseña;
        private (bool contraseñaIncorrecta, bool usuarioNoExiste, int num) BuscarUsuarios(string usuario, string contraseña)
        {
            DataTable usuarios = new DataTable();
            string sql = "SELECT * FROM usuarios WHERE usuario = '"+usuario+"'";
            SQLiteDataAdapter adp = new SQLiteDataAdapter(sql, cnx);
            adp.Fill(usuarios);

            int num = usuarios.Rows.Count;
            bool contraseñaIncorrecta = false;
            bool usuarioNoExiste = false;


            if (num == 0)
            {
                usuarioNoExiste = true;
                return (contraseñaIncorrecta,usuarioNoExiste, num); 
            }

            
            string passBD = Convert.ToString(usuarios.Rows[0][1]);
            if (passBD != contraseña)
            {
                contraseñaIncorrecta = true;
                return (contraseñaIncorrecta, usuarioNoExiste, num);
            }


            return (contraseñaIncorrecta, usuarioNoExiste, num);
        }
        private int RegistrarUsuario(string usuario, string contraseña)
        {
            string registro = "INSERT INTO usuarios VALUES ('"+usuario+"','"+contraseña+"')";
            SQLiteCommand command = new SQLiteCommand(registro, cnx);
            int hecho = command.ExecuteNonQuery();
            if (hecho == 1)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

        private void iniciarSesionBtn_Click(object sender, EventArgs e)
        {
            usuario = usuarioTxt.Text;
            contraseña = contraseñaTxt.Text;
            (bool contraseñaT, bool usuarioT, int num) = BuscarUsuarios(usuario, contraseña);

           
            if (num == 0)
            {
                DialogResult decision = MessageBox.Show("No hay usuarios registrados.\n¿Desea registrar este usuario?","Base de datos vacía", MessageBoxButtons.YesNo,MessageBoxIcon.Question);

                if (decision == DialogResult.Yes)
                {
                    int registrar = RegistrarUsuario(usuario, contraseña);

                    if (registrar == 1)
                    {
                        MessageBox.Show("Usuario registrado con éxito.");
                        this.DialogResult = DialogResult.OK;
                        Principal principal = new Principal();
                        principal.ShowDialog();
                        
                    }
                    else
                    {
                        MessageBox.Show("No se ha podido registrar el usuario.");
                    }
                }

                 
            }

           
            if (contraseñaT == false && usuarioT == false)
            {
               
                MessageBox.Show("Inicio de sesión correcto.");
                this.DialogResult = DialogResult.OK;
                Principal principal = new Principal();
                principal.ShowDialog();
                
            }

           
            if (contraseñaT == true && usuarioT == false)
            {
                MessageBox.Show("Contraseña incorrecta.");
                
            }

           
            if (usuarioT == true && contraseñaT == false)
            {
                MessageBox.Show("Usuario incorrecto.");
                
            }

         
            if (usuarioT == true && contraseñaT == true)
            {
                DialogResult decision = MessageBox.Show(
                    "El usuario no existe.\n¿Desea registrarlo ahora?",
                    "Usuario no registrado",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question
                );

                if (decision == DialogResult.Yes)
                {
                    int registrar = RegistrarUsuario(usuario, contraseña);

                    if (registrar == 1)
                    {
                        MessageBox.Show("Usuario registrado con éxito.");
                        this.DialogResult = DialogResult.OK;
                        Principal principal = new Principal();
                        principal.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("No se ha podido registrar el usuario.");
                    }
                }
            }
            usuarioTxt.Clear();
            contraseñaTxt.Clear();
        }
    }
}
