﻿using FlightLib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterfazGrafica
{
    public partial class ListaVuelos : Form
    {
        FlightPlanList miLista;
        public ListaVuelos(FlightPlanList lista)
        {
            this.miLista = lista;
            InitializeComponent();
        }
        private void MostrarDatosVuelos()
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();

            dataGridView1.ColumnCount = 6;
            dataGridView1.Columns[0].Name = "ID";
            dataGridView1.Columns[1].Name = "Posicion Inicial X";
            dataGridView1.Columns[2].Name = "Posicion Inicial Y";
            dataGridView1.Columns[3].Name = "Posicion Final X";
            dataGridView1.Columns[4].Name = "Posicion Final Y";
            dataGridView1.Columns[5].Name = "Velocidad";

            for (int i = 0; i<miLista.GetNum(); i++)
            {
                FlightPlan vuelo = miLista.GetFlightPlan(i);
                string id = vuelo.GetId();
                double posix = vuelo.GetInitialPosition().GetX();
                double posiy = vuelo.GetInitialPosition().GetY();
                double posfx = vuelo.GetFinalPosition().GetX();
                double posfy = vuelo.GetFinalPosition().GetY();
                double velocidad = vuelo.GetVelocidad();
                dataGridView1.Rows.Add(id, posix, posiy, posfx, posfy, velocidad);
            }

        }

        private void ListaVuelos_Load(object sender, EventArgs e)
        {
            MostrarDatosVuelos();
        }
    }
}
