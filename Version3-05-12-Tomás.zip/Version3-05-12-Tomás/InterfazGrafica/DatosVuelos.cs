﻿using System;
using System.Windows.Forms;
using FlightLib;

namespace InterfazGrafica
{
    public partial class DatosVuelos : Form
    {
        public FlightPlanList listaPlanesVuelo = new FlightPlanList();

        public DatosVuelos()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            try
            {
                string[] pi1 = PIVuelo1.Text.Split(',');
                string[] pf1 = PFVuelo1.Text.Split(',');

                double velocidad = Convert.ToDouble(VelocidadVuelo1.Text);

                // Validar velocidad positiva
                if (velocidad <= 0)
                {
                    MessageBox.Show("La velocidad debe ser un valor positivo mayor que 0", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                FlightPlan vuelo = new FlightPlan(
                    IDVuelo1.Text,
                    companytxt.Text,
                    Convert.ToDouble(pi1[0]),
                    Convert.ToDouble(pi1[1]),
                    Convert.ToDouble(pf1[0]),
                    Convert.ToDouble(pf1[1]),
                    velocidad
                );

                listaPlanesVuelo.AddFlightPlan(vuelo);

                // Limpiar campos
                PIVuelo1.Clear();
                PFVuelo1.Clear();
                IDVuelo1.Clear();
                VelocidadVuelo1.Clear();
                companytxt.Clear();

                MessageBox.Show("Vuelo agregado correctamente", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (FormatException)
            {
                MessageBox.Show("Error de formato en los datos numéricos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DatosVuelos_Load(object sender, EventArgs e)
        {
        }

        private void DatosEjemploBtn_Click(object sender, EventArgs e)
        {
            IDVuelo1.Text = "IB123";
            VelocidadVuelo1.Text = "100";
            PIVuelo1.Text = "100,100";
            PFVuelo1.Text = "300,300";

        }

        private void Volver_Btn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}