﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;
using System.IO;
using FlightLib;

namespace InterfazGrafica
{
    public partial class InicioSesion : Form
    {
        UserDatabase db;
        public string usuario;
        public string contraseña;

        public InicioSesion()
        {
            InitializeComponent();
            db = new UserDatabase();
        }

        private void InicioSesion_Load(object sender, EventArgs e)
        {
            db.InicializarBD();
        }

        private void InicioSesion_FormClosing(object sender, FormClosingEventArgs e)
        {
            db.FinalizarBD();
        }

        private void iniciarSesionBtn_Click(object sender, EventArgs e)
        {
            usuario = usuarioTxt.Text;
            contraseña = contraseñaTxt.Text;
            (bool contraseñaT, bool usuarioT, int num) = db.BuscarUsuarios(usuario, contraseña);

            if (num == 0)
            {
                DialogResult decision = MessageBox.Show("No hay usuarios registrados.\n¿Desea registrar este usuario?", "Base de datos vacía", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (decision == DialogResult.Yes)
                {
                    int registrar = db.RegistrarUsuario(usuario, contraseña);

                    if (registrar == 1)
                    {
                        MessageBox.Show("Usuario registrado con éxito.");
                        this.DialogResult = DialogResult.OK;
                        Principal principal = new Principal();
                        principal.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("No se ha podido registrar el usuario.");
                    }
                }
            }

            if (contraseñaT == false && usuarioT == false)
            {
                MessageBox.Show("Inicio de sesión correcto.");
                this.DialogResult = DialogResult.OK;
                Principal principal = new Principal();
                principal.ShowDialog();
            }

            if (contraseñaT == true && usuarioT == false)
            {
                MessageBox.Show("Contraseña incorrecta.");
            }

            if (usuarioT == true && contraseñaT == false)
            {
                MessageBox.Show("Usuario incorrecto.");
            }

            if (usuarioT == true && contraseñaT == true)
            {
                DialogResult decision = MessageBox.Show(
                    "El usuario no existe.\n¿Desea registrarlo ahora?",
                    "Usuario no registrado",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question
                );

                if (decision == DialogResult.Yes)
                {
                    int registrar = db.RegistrarUsuario(usuario, contraseña);

                    if (registrar == 1)
                    {
                        MessageBox.Show("Usuario registrado con éxito.");
                        this.DialogResult = DialogResult.OK;
                        Principal principal = new Principal();
                        principal.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("No se ha podido registrar el usuario.");
                    }
                }
            }
            usuarioTxt.Clear();
            contraseñaTxt.Clear();
        }

        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void usuarioTxt_TextChanged(object sender, EventArgs e) { }
        private void contraseñaTxt_TextChanged(object sender, EventArgs e) { }
    }
}