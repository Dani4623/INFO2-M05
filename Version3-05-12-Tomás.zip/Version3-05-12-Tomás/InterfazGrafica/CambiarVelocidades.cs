﻿using FlightLib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Intrinsics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace InterfazGrafica
{
    public partial class CambiarVelocidades : Form
    {
        public FlightPlanList cambioVelocidad;

        public CambiarVelocidades(FlightPlanList lista)
        {
            InitializeComponent();
            cambioVelocidad = lista;
        }

        private void CambiarVelocidades_Load(object sender, EventArgs e)
        {
            try
            {
                Velocidad1.Text = Convert.ToString(cambioVelocidad.GetFlightPlan(0).GetVelocidad());
            }
            catch (FormatException)
            {
                MessageBox.Show("Error de datos");
            }
            
        }
        private int i = 0;
        private void btnAceptar_Click(object sender, EventArgs e)
        {
            double velocidadinicial = cambioVelocidad.GetFlightPlan(i).GetVelocidad();
            double velvuelo = Convert.ToDouble(Velocidad1.Text);
            cambioVelocidad.GetFlightPlan(i).SetVelocidad(velvuelo);
            if (velocidadinicial != velvuelo)
            {
                MessageBox.Show("Velocidad modificada con éxito");
            }
            i++;
            if(i == cambioVelocidad.GetNum())
            {
                MessageBox.Show("No hay más vuelos en la lista.");
            }
            else
            {
                Velocidad1.Text = Convert.ToString(cambioVelocidad.GetFlightPlan(i).GetVelocidad());
            }
               
        }

        private void volverBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
