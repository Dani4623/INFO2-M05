﻿namespace InterfazGrafica
{
    partial class Principal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            opcionesToolStripMenuItem = new ToolStripMenuItem();
            cargarListaDeVuelosToolStripMenuItem = new ToolStripMenuItem();
            distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem = new ToolStripMenuItem();
            simulaciónToolStripMenuItem = new ToolStripMenuItem();
            cargarDesdeFicheroToolStripMenuItem = new ToolStripMenuItem();
            informaciónDeFicheroToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(24, 24);
            menuStrip1.Items.AddRange(new ToolStripItem[] { opcionesToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(5, 2, 0, 2);
            menuStrip1.Size = new Size(640, 28);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // opcionesToolStripMenuItem
            // 
            opcionesToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { cargarListaDeVuelosToolStripMenuItem, distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem, simulaciónToolStripMenuItem, cargarDesdeFicheroToolStripMenuItem });
            opcionesToolStripMenuItem.Name = "opcionesToolStripMenuItem";
            opcionesToolStripMenuItem.Size = new Size(85, 24);
            opcionesToolStripMenuItem.Text = "Opciones";
            // 
            // cargarListaDeVuelosToolStripMenuItem
            // 
            cargarListaDeVuelosToolStripMenuItem.Name = "cargarListaDeVuelosToolStripMenuItem";
            cargarListaDeVuelosToolStripMenuItem.Size = new Size(370, 26);
            cargarListaDeVuelosToolStripMenuItem.Text = "Cargar lista de vuelos";
            cargarListaDeVuelosToolStripMenuItem.Click += cargarListaDeVuelosToolStripMenuItem_Click;
            // 
            // distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem
            // 
            distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem.Name = "distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem";
            distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem.Size = new Size(370, 26);
            distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem.Text = "Distancia de Seguridad y Tiempo de Ciclo";
            distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem.Click += distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem_Click;
            // 
            // simulaciónToolStripMenuItem
            // 
            simulaciónToolStripMenuItem.Name = "simulaciónToolStripMenuItem";
            simulaciónToolStripMenuItem.Size = new Size(370, 26);
            simulaciónToolStripMenuItem.Text = "Simulación";
            simulaciónToolStripMenuItem.Click += simulaciónToolStripMenuItem_Click;
            // 
            // cargarDesdeFicheroToolStripMenuItem
            // 
            cargarDesdeFicheroToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { informaciónDeFicheroToolStripMenuItem });
            cargarDesdeFicheroToolStripMenuItem.Name = "cargarDesdeFicheroToolStripMenuItem";
            cargarDesdeFicheroToolStripMenuItem.Size = new Size(370, 26);
            cargarDesdeFicheroToolStripMenuItem.Text = "Cargar desde Fichero";
            cargarDesdeFicheroToolStripMenuItem.Click += cargarDesdeFicheroToolStripMenuItem_Click;
            // 
            // informaciónDeFicheroToolStripMenuItem
            // 
            informaciónDeFicheroToolStripMenuItem.Name = "informaciónDeFicheroToolStripMenuItem";
            informaciónDeFicheroToolStripMenuItem.Size = new Size(243, 26);
            informaciónDeFicheroToolStripMenuItem.Text = "Información de fichero";
            informaciónDeFicheroToolStripMenuItem.Click += informaciónDeFicheroToolStripMenuItem_Click;
            // 
            // Principal
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SlateGray;
            ClientSize = new Size(640, 360);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Margin = new Padding(2);
            Name = "Principal";
            Text = "Principal";
            Load += Principal_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem opcionesToolStripMenuItem;
        private ToolStripMenuItem cargarListaDeVuelosToolStripMenuItem;
        private ToolStripMenuItem distanciaDeSeguridadYTiempoDeCicloToolStripMenuItem;
        private ToolStripMenuItem simulaciónToolStripMenuItem;
        private ToolStripMenuItem cargarDesdeFicheroToolStripMenuItem;
        private ToolStripMenuItem informaciónDeFicheroToolStripMenuItem;
    }
}
