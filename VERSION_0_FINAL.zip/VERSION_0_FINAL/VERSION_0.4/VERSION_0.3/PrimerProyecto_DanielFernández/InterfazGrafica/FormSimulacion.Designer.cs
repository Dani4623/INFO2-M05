﻿namespace InterfazGrafica
{
    partial class FormSimulacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            miPanel = new Panel();
            Avion2 = new Label();
            Avion1 = new Label();
            btnMoverCiclo = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            Inicio = new Button();
            Final = new Button();
            MostrarDatosActuales = new Button();
            btnVerificarConflicto = new Button();
            miPanel.SuspendLayout();
            SuspendLayout();
            // 
            // miPanel
            // 
            miPanel.BackColor = SystemColors.GradientInactiveCaption;
            miPanel.Controls.Add(Avion2);
            miPanel.Controls.Add(Avion1);
            miPanel.Location = new Point(10, 10);
            miPanel.Margin = new Padding(2);
            miPanel.Name = "miPanel";
            miPanel.Size = new Size(637, 488);
            miPanel.TabIndex = 0;
            // 
            // Avion2
            // 
            Avion2.AutoSize = true;
            Avion2.BackColor = Color.FromArgb(192, 255, 192);
            Avion2.Location = new Point(222, 161);
            Avion2.Margin = new Padding(2, 0, 2, 0);
            Avion2.Name = "Avion2";
            Avion2.Size = new Size(27, 20);
            Avion2.TabIndex = 1;
            Avion2.Text = "A2";
            Avion2.Click += Avion2_Click;
            // 
            // Avion1
            // 
            Avion1.AutoSize = true;
            Avion1.BackColor = Color.FromArgb(255, 192, 192);
            Avion1.Location = new Point(178, 122);
            Avion1.Margin = new Padding(2, 0, 2, 0);
            Avion1.Name = "Avion1";
            Avion1.Size = new Size(27, 20);
            Avion1.TabIndex = 0;
            Avion1.Text = "A1";
            Avion1.Click += Avion1_Click_1;
            // 
            // btnMoverCiclo
            // 
            btnMoverCiclo.Location = new Point(672, 32);
            btnMoverCiclo.Margin = new Padding(2);
            btnMoverCiclo.Name = "btnMoverCiclo";
            btnMoverCiclo.Size = new Size(108, 30);
            btnMoverCiclo.TabIndex = 1;
            btnMoverCiclo.Text = "Mover Ciclo";
            btnMoverCiclo.UseVisualStyleBackColor = true;
            btnMoverCiclo.Click += btnMoverCiclo_Click;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // Inicio
            // 
            Inicio.Location = new Point(672, 67);
            Inicio.Name = "Inicio";
            Inicio.Size = new Size(108, 70);
            Inicio.TabIndex = 2;
            Inicio.Text = "Empezar simulación automática";
            Inicio.UseVisualStyleBackColor = true;
            Inicio.Click += Inicio_Click;
            // 
            // Final
            // 
            Final.Location = new Point(672, 146);
            Final.Name = "Final";
            Final.Size = new Size(108, 70);
            Final.TabIndex = 3;
            Final.Text = "Finalizar simulación automática";
            Final.UseVisualStyleBackColor = true;
            Final.Click += Final_Click;
            // 
            // MostrarDatosActuales
            // 
            MostrarDatosActuales.Location = new Point(672, 222);
            MostrarDatosActuales.Name = "MostrarDatosActuales";
            MostrarDatosActuales.Size = new Size(108, 68);
            MostrarDatosActuales.TabIndex = 4;
            MostrarDatosActuales.Text = "Mostrar datos actuales";
            MostrarDatosActuales.UseVisualStyleBackColor = true;
            MostrarDatosActuales.Click += MostrarDatosActuales_Click;
            // 
            // btnVerificarConflicto
            // 
            btnVerificarConflicto.Location = new Point(672, 296);
            btnVerificarConflicto.Name = "btnVerificarConflicto";
            btnVerificarConflicto.Size = new Size(108, 62);
            btnVerificarConflicto.TabIndex = 5;
            btnVerificarConflicto.Text = "Verificar Conflicto";
            btnVerificarConflicto.UseVisualStyleBackColor = true;
            btnVerificarConflicto.Click += btnVerificarConflicto_Click;
            // 
            // FormSimulacion
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(841, 529);
            Controls.Add(btnVerificarConflicto);
            Controls.Add(MostrarDatosActuales);
            Controls.Add(Final);
            Controls.Add(Inicio);
            Controls.Add(btnMoverCiclo);
            Controls.Add(miPanel);
            Margin = new Padding(2);
            Name = "FormSimulacion";
            Text = "Form1";
            Load += FormSimulacion_Load;
            miPanel.ResumeLayout(false);
            miPanel.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel miPanel;
        private Button btnMoverCiclo;
        private Label Avion2;
        private Label Avion1;
        private System.Windows.Forms.Timer timer1;
        private Button Inicio;
        private Button Final;
        private Button MostrarDatosActuales;
        private Button btnVerificarConflicto;
    }
}