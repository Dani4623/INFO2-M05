﻿namespace InterfazGrafica
{
    partial class FormSimulacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            miPanel = new Panel();
            Avion2 = new Label();
            Avion1 = new Label();
            btnMoverCiclo = new Button();
            miPanel.SuspendLayout();
            SuspendLayout();
            // 
            // miPanel
            // 
            miPanel.BackColor = SystemColors.GradientInactiveCaption;
            miPanel.Controls.Add(Avion2);
            miPanel.Controls.Add(Avion1);
            miPanel.Location = new Point(12, 12);
            miPanel.Name = "miPanel";
            miPanel.Size = new Size(615, 426);
            miPanel.TabIndex = 0;
            // 
            // Avion2
            // 
            Avion2.AutoSize = true;
            Avion2.BackColor = Color.FromArgb(192, 255, 192);
            Avion2.Location = new Point(278, 201);
            Avion2.Name = "Avion2";
            Avion2.Size = new Size(34, 25);
            Avion2.TabIndex = 1;
            Avion2.Text = "A2";
            Avion2.Click += Avion2_Click;
            // 
            // Avion1
            // 
            Avion1.AutoSize = true;
            Avion1.BackColor = Color.FromArgb(255, 192, 192);
            Avion1.Location = new Point(222, 152);
            Avion1.Name = "Avion1";
            Avion1.Size = new Size(34, 25);
            Avion1.TabIndex = 0;
            Avion1.Text = "A1";
            Avion1.Click += Avion1_Click_1;
            // 
            // btnMoverCiclo
            // 
            btnMoverCiclo.Location = new Point(644, 59);
            btnMoverCiclo.Name = "btnMoverCiclo";
            btnMoverCiclo.Size = new Size(135, 37);
            btnMoverCiclo.TabIndex = 1;
            btnMoverCiclo.Text = "Mover Ciclo";
            btnMoverCiclo.UseVisualStyleBackColor = true;
            btnMoverCiclo.Click += btnMoverCiclo_Click;
            // 
            // FormSimulacion
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnMoverCiclo);
            Controls.Add(miPanel);
            Name = "FormSimulacion";
            Text = "Form1";
            Load += FormSimulacion_Load;
            miPanel.ResumeLayout(false);
            miPanel.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel miPanel;
        private Button btnMoverCiclo;
        private Label Avion2;
        private Label Avion1;
    }
}