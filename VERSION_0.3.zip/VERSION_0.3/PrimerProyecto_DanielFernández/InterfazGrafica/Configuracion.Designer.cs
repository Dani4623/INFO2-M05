﻿namespace InterfazGrafica
{
    partial class Configuracion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DistanciaSeguridad = new TextBox();
            TiempoCiclo = new TextBox();
            label1 = new Label();
            label2 = new Label();
            btnAceptar = new Button();
            SuspendLayout();
            // 
            // DistanciaSeguridad
            // 
            DistanciaSeguridad.Location = new Point(105, 152);
            DistanciaSeguridad.Name = "DistanciaSeguridad";
            DistanciaSeguridad.Size = new Size(150, 31);
            DistanciaSeguridad.TabIndex = 0;
            // 
            // TiempoCiclo
            // 
            TiempoCiclo.Location = new Point(540, 152);
            TiempoCiclo.Name = "TiempoCiclo";
            TiempoCiclo.Size = new Size(150, 31);
            TiempoCiclo.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(95, 103);
            label1.Name = "label1";
            label1.Size = new Size(192, 25);
            label1.TabIndex = 2;
            label1.Text = "Distancia de seguridad";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(555, 103);
            label2.Name = "label2";
            label2.Size = new Size(112, 25);
            label2.TabIndex = 3;
            label2.Text = "Tiempo ciclo";
            // 
            // btnAceptar
            // 
            btnAceptar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAceptar.Location = new Point(343, 258);
            btnAceptar.Name = "btnAceptar";
            btnAceptar.Size = new Size(112, 34);
            btnAceptar.TabIndex = 4;
            btnAceptar.Text = "Aceptar";
            btnAceptar.UseVisualStyleBackColor = true;
            btnAceptar.Click += btnAceptar_Click;
            // 
            // Configuracion
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnAceptar);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(TiempoCiclo);
            Controls.Add(DistanciaSeguridad);
            Name = "Configuracion";
            Text = "Configuración";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox DistanciaSeguridad;
        private TextBox TiempoCiclo;
        private Label label1;
        private Label label2;
        private Button btnAceptar;
    }
}