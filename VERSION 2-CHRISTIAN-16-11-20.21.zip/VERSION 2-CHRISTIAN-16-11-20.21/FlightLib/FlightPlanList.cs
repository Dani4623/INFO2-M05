﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightLib
{
    public class FlightPlanList
    {
        List<FlightPlan> vuelos = new List<FlightPlan>();




        public int GetNum()
        {
            return vuelos.Count();
        }




        public int AddFlightPlan(FlightPlan p)
        {
            vuelos.Add(p);
            return 0;
        }





        public FlightPlan GetFlightPlan(int i)
        {
            if (i < 0 || i >= vuelos.Count)
            {
                return null;
            }
            else
            {
                return vuelos[i];
            }
        }





        public void Mover(double tiempo)
        {
            for (int i = 0; i < vuelos.Count; i++)
            {
                vuelos[i].Mover(tiempo);
            }
        }






        public void EscribeConsola()
        {
            for (int i = 0; i < vuelos.Count; i++)
            {
                vuelos[i].EscribeConsola();
            }
        }



        public bool hanLlegadoTodos()
        {
            for (int i = 0; i < vuelos.Count; i++)
            {
                if (vuelos[i].HasArrived() == false)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
