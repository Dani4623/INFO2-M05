﻿namespace InterfazGrafica
{
    partial class InfoAvion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblId = new Label();
            lblVelocidad = new Label();
            lblPosActual = new Label();
            lblPosDestino = new Label();
            lblEstado = new Label();
            SuspendLayout();
            // 
            // lblId
            // 
            lblId.AutoSize = true;
            lblId.Location = new Point(70, 50);
            lblId.Margin = new Padding(2, 0, 2, 0);
            lblId.Name = "lblId";
            lblId.Size = new Size(27, 20);
            lblId.TabIndex = 0;
            lblId.Text = "ID:";
            // 
            // lblVelocidad
            // 
            lblVelocidad.AutoSize = true;
            lblVelocidad.Location = new Point(70, 111);
            lblVelocidad.Margin = new Padding(2, 0, 2, 0);
            lblVelocidad.Name = "lblVelocidad";
            lblVelocidad.Size = new Size(78, 20);
            lblVelocidad.TabIndex = 1;
            lblVelocidad.Text = "Velocidad:";
            // 
            // lblPosActual
            // 
            lblPosActual.AutoSize = true;
            lblPosActual.Location = new Point(70, 170);
            lblPosActual.Margin = new Padding(2, 0, 2, 0);
            lblPosActual.Name = "lblPosActual";
            lblPosActual.Size = new Size(112, 20);
            lblPosActual.TabIndex = 2;
            lblPosActual.Text = "Posición Actual:";
            // 
            // lblPosDestino
            // 
            lblPosDestino.AutoSize = true;
            lblPosDestino.Location = new Point(70, 233);
            lblPosDestino.Margin = new Padding(2, 0, 2, 0);
            lblPosDestino.Name = "lblPosDestino";
            lblPosDestino.Size = new Size(121, 20);
            lblPosDestino.TabIndex = 3;
            lblPosDestino.Text = "Posición Destino:";
            // 
            // lblEstado
            // 
            lblEstado.AutoSize = true;
            lblEstado.Location = new Point(70, 291);
            lblEstado.Margin = new Padding(2, 0, 2, 0);
            lblEstado.Name = "lblEstado";
            lblEstado.Size = new Size(57, 20);
            lblEstado.TabIndex = 4;
            lblEstado.Text = "Estado:";
            // 
            // InfoAvion
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(640, 360);
            Controls.Add(lblEstado);
            Controls.Add(lblPosDestino);
            Controls.Add(lblPosActual);
            Controls.Add(lblVelocidad);
            Controls.Add(lblId);
            Margin = new Padding(2, 2, 2, 2);
            Name = "InfoAvion";
            Text = "Información del Avión";
            Load += InfoAvion_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblId;
        private Label lblVelocidad;
        private Label lblPosActual;
        private Label lblPosDestino;
        private Label lblEstado;
    }
}