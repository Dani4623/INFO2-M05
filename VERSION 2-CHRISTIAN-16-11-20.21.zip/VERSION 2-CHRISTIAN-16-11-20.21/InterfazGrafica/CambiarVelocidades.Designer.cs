﻿namespace InterfazGrafica
{
    partial class CambiarVelocidades
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAceptar = new Button();
            label1 = new Label();
            Velocidad1 = new TextBox();
            volverBtn = new Button();
            SuspendLayout();
            // 
            // btnAceptar
            // 
            btnAceptar.Location = new Point(191, 265);
            btnAceptar.Margin = new Padding(2);
            btnAceptar.Name = "btnAceptar";
            btnAceptar.Size = new Size(90, 27);
            btnAceptar.TabIndex = 0;
            btnAceptar.Text = "Aceptar";
            btnAceptar.UseVisualStyleBackColor = true;
            btnAceptar.Click += btnAceptar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(259, 101);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(0, 20);
            label1.TabIndex = 1;
            // 
            // Velocidad1
            // 
            Velocidad1.Location = new Point(259, 142);
            Velocidad1.Margin = new Padding(2);
            Velocidad1.Name = "Velocidad1";
            Velocidad1.Size = new Size(121, 27);
            Velocidad1.TabIndex = 2;
            // 
            // volverBtn
            // 
            volverBtn.Location = new Point(351, 265);
            volverBtn.Margin = new Padding(2);
            volverBtn.Name = "volverBtn";
            volverBtn.Size = new Size(90, 27);
            volverBtn.TabIndex = 3;
            volverBtn.Text = "Volver";
            volverBtn.UseVisualStyleBackColor = true;
            volverBtn.Click += volverBtn_Click;
            // 
            // CambiarVelocidades
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(640, 360);
            Controls.Add(volverBtn);
            Controls.Add(Velocidad1);
            Controls.Add(label1);
            Controls.Add(btnAceptar);
            Margin = new Padding(2);
            Name = "CambiarVelocidades";
            Text = "Form1";
            Load += CambiarVelocidades_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAceptar;
        private Label label1;
        private TextBox Velocidad1;
        private Button volverBtn;
    }
}